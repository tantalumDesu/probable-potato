// Gem table from SRD with examples.

export interface GemTier {
  min: number;
  max: number;
  valueDie: string;
  average: number;
  examples: string[];
}

export const gemTable: GemTier[] = [
  {
    min: 1, max: 25, valueDie: "4d4", average: 10,
    examples: [
      "Banded agate", "Eye agate", "Moss agate", "Azurite", "Blue quartz",
      "Hematite", "Lapis lazuli", "Malachite", "Obsidian", "Rhodochrosite",
      "Tiger eye turquoise", "Freshwater irregular pearl",
    ],
  },
  {
    min: 26, max: 50, valueDie: "2d4x10", average: 50,
    examples: [
      "Bloodstone", "Carnelian", "Chalcedony", "Chrysoprase", "Citrine",
      "Iolite", "Jasper", "Moonstone", "Onyx", "Peridot",
      "Rock crystal (clear quartz)", "Sard", "Sardonyx",
      "Rose quartz", "Smoky quartz", "Star rose quartz", "Zircon",
    ],
  },
  {
    min: 51, max: 70, valueDie: "4d4x10", average: 100,
    examples: [
      "Amber", "Amethyst", "Chrysoberyl", "Coral",
      "Red garnet", "Brown-green garnet", "Jade", "Jet",
      "White pearl", "Golden pearl", "Pink pearl", "Silver pearl",
      "Red spinel", "Red-brown spinel", "Deep green spinel", "Tourmaline",
    ],
  },
  {
    min: 71, max: 90, valueDie: "2d4x100", average: 500,
    examples: [
      "Alexandrite", "Aquamarine", "Violet garnet",
      "Black pearl", "Deep blue spinel", "Golden yellow topaz",
    ],
  },
  {
    min: 91, max: 99, valueDie: "4d4x100", average: 1000,
    examples: [
      "Emerald", "White opal", "Black opal", "Fire opal",
      "Blue sapphire", "Fiery yellow corundum", "Rich purple corundum",
      "Blue star sapphire", "Black star sapphire", "Star ruby",
    ],
  },
  {
    min: 100, max: 100, valueDie: "2d4x1000", average: 5000,
    examples: [
      "Clearest bright green emerald",
      "Blue-white diamond", "Canary diamond", "Pink diamond",
      "Brown diamond", "Blue diamond", "Jacinth",
    ],
  },
];

// Goods (gems/art) quantity table per level.
export interface GoodsEntry {
  min: number;
  max: number;
  kind: "none" | "gems" | "art";
  quantity: string; // die string or "0"
  label: string;
}

export const goodsTableByLevel: Record<number, GoodsEntry[]> = {
  1: [
    { min: 1, max: 90, kind: "none", quantity: "0", label: "—" },
    { min: 91, max: 95, kind: "gems", quantity: "1", label: "1 gem" },
    { min: 96, max: 100, kind: "art", quantity: "1", label: "1 art object" },
  ],
  2: [
    { min: 1, max: 81, kind: "none", quantity: "0", label: "—" },
    { min: 82, max: 95, kind: "gems", quantity: "1d3", label: "1d3 gems" },
    { min: 96, max: 100, kind: "art", quantity: "1d3", label: "1d3 art objects" },
  ],
  3: [
    { min: 1, max: 77, kind: "none", quantity: "0", label: "—" },
    { min: 78, max: 95, kind: "gems", quantity: "1d3", label: "1d3 gems" },
    { min: 96, max: 100, kind: "art", quantity: "1d3", label: "1d3 art objects" },
  ],
  4: [
    { min: 1, max: 70, kind: "none", quantity: "0", label: "—" },
    { min: 71, max: 95, kind: "gems", quantity: "1d4", label: "1d4 gems" },
    { min: 96, max: 100, kind: "art", quantity: "1d3", label: "1d3 art objects" },
  ],
  5: [
    { min: 1, max: 60, kind: "none", quantity: "0", label: "—" },
    { min: 61, max: 95, kind: "gems", quantity: "1d4", label: "1d4 gems" },
    { min: 96, max: 100, kind: "art", quantity: "1d4", label: "1d4 art objects" },
  ],
  6: [
    { min: 1, max: 56, kind: "none", quantity: "0", label: "—" },
    { min: 57, max: 92, kind: "gems", quantity: "1d4", label: "1d4 gems" },
    { min: 93, max: 100, kind: "art", quantity: "1d4", label: "1d4 art objects" },
  ],
  7: [
    { min: 1, max: 48, kind: "none", quantity: "0", label: "—" },
    { min: 49, max: 88, kind: "gems", quantity: "1d4", label: "1d4 gems" },
    { min: 89, max: 100, kind: "art", quantity: "1d4", label: "1d4 art objects" },
  ],
  8: [
    { min: 1, max: 45, kind: "none", quantity: "0", label: "—" },
    { min: 46, max: 85, kind: "gems", quantity: "1d6", label: "1d6 gems" },
    { min: 86, max: 100, kind: "art", quantity: "1d4", label: "1d4 art objects" },
  ],
  9: [
    { min: 1, max: 40, kind: "none", quantity: "0", label: "—" },
    { min: 41, max: 80, kind: "gems", quantity: "1d8", label: "1d8 gems" },
    { min: 81, max: 100, kind: "art", quantity: "1d4", label: "1d4 art objects" },
  ],
  10: [
    { min: 1, max: 35, kind: "none", quantity: "0", label: "—" },
    { min: 36, max: 79, kind: "gems", quantity: "1d8", label: "1d8 gems" },
    { min: 80, max: 100, kind: "art", quantity: "1d6", label: "1d6 art objects" },
  ],
  11: [
    { min: 1, max: 24, kind: "none", quantity: "0", label: "—" },
    { min: 25, max: 74, kind: "gems", quantity: "1d10", label: "1d10 gems" },
    { min: 75, max: 100, kind: "art", quantity: "1d6", label: "1d6 art objects" },
  ],
  12: [
    { min: 1, max: 17, kind: "none", quantity: "0", label: "—" },
    { min: 18, max: 70, kind: "gems", quantity: "1d10", label: "1d10 gems" },
    { min: 71, max: 100, kind: "art", quantity: "1d8", label: "1d8 art objects" },
  ],
  13: [
    { min: 1, max: 11, kind: "none", quantity: "0", label: "—" },
    { min: 12, max: 66, kind: "gems", quantity: "1d12", label: "1d12 gems" },
    { min: 67, max: 100, kind: "art", quantity: "1d10", label: "1d10 art objects" },
  ],
  14: [
    { min: 1, max: 11, kind: "none", quantity: "0", label: "—" },
    { min: 12, max: 66, kind: "gems", quantity: "2d8", label: "2d8 gems" },
    { min: 67, max: 100, kind: "art", quantity: "2d6", label: "2d6 art objects" },
  ],
  15: [
    { min: 1, max: 9, kind: "none", quantity: "0", label: "—" },
    { min: 10, max: 65, kind: "gems", quantity: "2d10", label: "2d10 gems" },
    { min: 66, max: 100, kind: "art", quantity: "2d8", label: "2d8 art objects" },
  ],
  16: [
    { min: 1, max: 7, kind: "none", quantity: "0", label: "—" },
    { min: 8, max: 64, kind: "gems", quantity: "4d6", label: "4d6 gems" },
    { min: 65, max: 100, kind: "art", quantity: "2d10", label: "2d10 art objects" },
  ],
  17: [
    { min: 1, max: 4, kind: "none", quantity: "0", label: "—" },
    { min: 5, max: 63, kind: "gems", quantity: "4d8", label: "4d8 gems" },
    { min: 64, max: 100, kind: "art", quantity: "3d8", label: "3d8 art objects" },
  ],
  18: [
    { min: 1, max: 4, kind: "none", quantity: "0", label: "—" },
    { min: 5, max: 54, kind: "gems", quantity: "3d12", label: "3d12 gems" },
    { min: 55, max: 100, kind: "art", quantity: "3d10", label: "3d10 art objects" },
  ],
  19: [
    { min: 1, max: 3, kind: "none", quantity: "0", label: "—" },
    { min: 4, max: 50, kind: "gems", quantity: "6d6", label: "6d6 gems" },
    { min: 51, max: 100, kind: "art", quantity: "6d6", label: "6d6 art objects" },
  ],
  20: [
    { min: 1, max: 2, kind: "none", quantity: "0", label: "—" },
    { min: 3, max: 38, kind: "gems", quantity: "4d10", label: "4d10 gems" },
    { min: 39, max: 100, kind: "art", quantity: "7d6", label: "7d6 art objects" },
  ],
};
