// Weapon tables for random generation (common melee, uncommon, common ranged).
// Prices in gp (masterwork adds 300 gp); weight in lb; type: S/P/B.

export interface Weapon {
  name: string;
  cost: number;
  damage: string; // e.g. "1d8"
  critical: string; // e.g. "x3"
  range?: string;
  weight: number;
  type: string;
}

// Common melee (from SRD table: one-handed/light weapons)
export const commonMeleeWeapons: Weapon[] = [
  { name: "Dagger", cost: 2, damage: "1d4", critical: "19-20/x2", range: "10 ft.", weight: 1, type: "P" },
  { name: "Heavy mace", cost: 12, damage: "1d8", critical: "x2", weight: 8, type: "B" },
  { name: "Heavy pick", cost: 8, damage: "1d6", critical: "x4", weight: 6, type: "P" },
  { name: "Longspear", cost: 5, damage: "1d8", critical: "x3", weight: 9, type: "P" },
  { name: "Longsword", cost: 15, damage: "1d8", critical: "19-20/x2", weight: 4, type: "S" },
  { name: "Morningstar", cost: 8, damage: "1d8", critical: "x2", weight: 6, type: "B/P" },
  { name: "Quarterstaff", cost: 0, damage: "1d6", critical: "x2", weight: 4, type: "B" },
  { name: "Rapier", cost: 20, damage: "1d6", critical: "18-20/x2", weight: 2, type: "P" },
  { name: "Scimitar", cost: 15, damage: "1d6", critical: "18-20/x2", weight: 4, type: "S" },
  { name: "Short sword", cost: 10, damage: "1d6", critical: "19-20/x2", weight: 2, type: "P" },
  { name: "Spear", cost: 2, damage: "1d8", critical: "x3", range: "20 ft.", weight: 6, type: "P" },
  { name: "Warhammer", cost: 12, damage: "1d8", critical: "x3", weight: 5, type: "B" },
  { name: "Battleaxe", cost: 10, damage: "1d8", critical: "x3", weight: 6, type: "S" },
  { name: "Club", cost: 0, damage: "1d6", critical: "x2", weight: 3, type: "B" },
  { name: "Greataxe", cost: 20, damage: "1d12", critical: "x3", weight: 12, type: "S" },
  { name: "Greatclub", cost: 5, damage: "1d10", critical: "x2", weight: 8, type: "B" },
  { name: "Greatsword", cost: 50, damage: "2d6", critical: "19-20/x2", weight: 8, type: "S" },
  { name: "Halberd", cost: 10, damage: "1d10", critical: "x3", weight: 12, type: "P/S" },
];

// Uncommon/exotic weapons
export const uncommonWeapons: Weapon[] = [
  { name: "Bastard sword", cost: 35, damage: "1d10", critical: "19-20/x2", weight: 6, type: "S" },
  { name: "Dwarven waraxe", cost: 30, damage: "1d10", critical: "x3", weight: 8, type: "S" },
  { name: "Whip", cost: 1, damage: "1d2", critical: "x2", weight: 2, type: "S" },
  { name: "Spiked chain", cost: 25, damage: "2d4", critical: "x2", weight: 10, type: "P" },
  { name: "Flail (heavy)", cost: 15, damage: "1d10", critical: "19-20/x2", weight: 10, type: "B" },
  { name: "Flail (light)", cost: 8, damage: "1d8", critical: "x2", weight: 5, type: "B" },
  { name: "Waraxe, dwarven", cost: 30, damage: "1d10", critical: "x3", weight: 8, type: "S" },
  { name: "Handaxe", cost: 6, damage: "1d6", critical: "x3", range: "10 ft.", weight: 3, type: "S" },
  { name: "Kama", cost: 2, damage: "1d6", critical: "x2", weight: 2, type: "S" },
  { name: "Kukri", cost: 8, damage: "1d4", critical: "18-20/x2", weight: 2, type: "S" },
  { name: "Nunchaku", cost: 2, damage: "1d6", critical: "x2", weight: 2, type: "B" },
  { name: "Sai", cost: 1, damage: "1d4", critical: "x2", weight: 1, type: "B" },
  { name: "Siangham", cost: 3, damage: "1d6", critical: "x2", weight: 1, type: "P" },
  { name: "Light hammer", cost: 1, damage: "1d4", critical: "x2", range: "20 ft.", weight: 2, type: "B" },
  { name: "Sickle", cost: 6, damage: "1d6", critical: "x2", weight: 2, type: "S" },
];

// Common ranged weapons
export const commonRangedWeapons: Weapon[] = [
  { name: "Shortbow", cost: 30, damage: "1d6", critical: "x3", range: "60 ft.", weight: 2, type: "P" },
  { name: "Longbow", cost: 75, damage: "1d8", critical: "x3", range: "100 ft.", weight: 3, type: "P" },
  { name: "Composite shortbow", cost: 75, damage: "1d6", critical: "x3", range: "70 ft.", weight: 2, type: "P" },
  { name: "Composite longbow", cost: 100, damage: "1d8", critical: "x3", range: "110 ft.", weight: 3, type: "P" },
  { name: "Light crossbow", cost: 35, damage: "1d8", critical: "19-20/x2", range: "80 ft.", weight: 4, type: "P" },
  { name: "Heavy crossbow", cost: 50, damage: "1d10", critical: "19-20/x2", range: "120 ft.", weight: 8, type: "P" },
  { name: "Dart", cost: 0.5, damage: "1d4", critical: "x2", range: "20 ft.", weight: 0.5, type: "P" },
  { name: "Javelin", cost: 1, damage: "1d6", critical: "x2", range: "30 ft.", weight: 2, type: "P" },
  { name: "Sling", cost: 0, damage: "1d4", critical: "x2", range: "50 ft.", weight: 0, type: "B" },
  { name: "Throwing axe", cost: 8, damage: "1d6", critical: "x2", range: "10 ft.", weight: 2, type: "S" },
  { name: "Light hammer (thrown)", cost: 1, damage: "1d4", critical: "x2", range: "20 ft.", weight: 2, type: "B" },
];

// Masterwork adds 300 gp to cost, +1 enhancement bonus to hit (not damage)
export const MASTERWORK_COST_BONUS = 300;

// Armor list
export interface Armor {
  name: string;
  cost: number;
  acBonus: number;
  maxDex: number;
  checkPenalty: number;
  arcaneSpellFailure: number;
  speed30: number;
  speed20: number;
  weight: number;
  category: "light" | "medium" | "heavy" | "shield";
}

export const armorList: Armor[] = [
  { name: "Padded", cost: 5, acBonus: 1, maxDex: 8, checkPenalty: 0, arcaneSpellFailure: 5, speed30: 30, speed20: 20, weight: 10, category: "light" },
  { name: "Leather", cost: 10, acBonus: 2, maxDex: 6, checkPenalty: 0, arcaneSpellFailure: 10, speed30: 30, speed20: 20, weight: 15, category: "light" },
  { name: "Studded leather", cost: 25, acBonus: 3, maxDex: 5, checkPenalty: -1, arcaneSpellFailure: 15, speed30: 30, speed20: 20, weight: 20, category: "light" },
  { name: "Chain shirt", cost: 100, acBonus: 4, maxDex: 4, checkPenalty: -2, arcaneSpellFailure: 20, speed30: 30, speed20: 20, weight: 25, category: "light" },
  { name: "Hide", cost: 15, acBonus: 3, maxDex: 4, checkPenalty: -3, arcaneSpellFailure: 20, speed30: 20, speed20: 15, weight: 25, category: "medium" },
  { name: "Scale mail", cost: 50, acBonus: 4, maxDex: 3, checkPenalty: -4, arcaneSpellFailure: 25, speed30: 20, speed20: 15, weight: 30, category: "medium" },
  { name: "Chainmail", cost: 150, acBonus: 5, maxDex: 2, checkPenalty: -5, arcaneSpellFailure: 30, speed30: 20, speed20: 15, weight: 40, category: "medium" },
  { name: "Breastplate", cost: 200, acBonus: 5, maxDex: 3, checkPenalty: -4, arcaneSpellFailure: 25, speed30: 20, speed20: 15, weight: 30, category: "medium" },
  { name: "Splint mail", cost: 200, acBonus: 6, maxDex: 0, checkPenalty: -7, arcaneSpellFailure: 40, speed30: 20, speed20: 15, weight: 45, category: "heavy" },
  { name: "Banded mail", cost: 250, acBonus: 6, maxDex: 1, checkPenalty: -6, arcaneSpellFailure: 35, speed30: 20, speed20: 15, weight: 35, category: "heavy" },
  { name: "Half-plate", cost: 600, acBonus: 7, maxDex: 0, checkPenalty: -7, arcaneSpellFailure: 40, speed30: 20, speed20: 15, weight: 50, category: "heavy" },
  { name: "Full plate", cost: 1500, acBonus: 8, maxDex: 1, checkPenalty: -6, arcaneSpellFailure: 35, speed30: 20, speed20: 15, weight: 50, category: "heavy" },
  { name: "Buckler", cost: 15, acBonus: 1, maxDex: 99, checkPenalty: -1, arcaneSpellFailure: 5, speed30: 0, speed20: 0, weight: 5, category: "shield" },
  { name: "Light wooden shield", cost: 3, acBonus: 1, maxDex: 99, checkPenalty: -1, arcaneSpellFailure: 5, speed30: 0, speed20: 0, weight: 5, category: "shield" },
  { name: "Light steel shield", cost: 9, acBonus: 1, maxDex: 99, checkPenalty: -1, arcaneSpellFailure: 5, speed30: 0, speed20: 0, weight: 6, category: "shield" },
  { name: "Heavy wooden shield", cost: 7, acBonus: 2, maxDex: 99, checkPenalty: -2, arcaneSpellFailure: 15, speed30: 0, speed20: 0, weight: 10, category: "shield" },
  { name: "Heavy steel shield", cost: 20, acBonus: 2, maxDex: 99, checkPenalty: -2, arcaneSpellFailure: 15, speed30: 0, speed20: 0, weight: 15, category: "shield" },
  { name: "Tower shield", cost: 30, acBonus: 4, maxDex: 2, checkPenalty: -10, arcaneSpellFailure: 50, speed30: 0, speed20: 0, weight: 45, category: "shield" },
];

// Armor price/weight multipliers by size for humanoid-shaped creatures (SRD table)
export const armorSizeMultipliers: Record<string, { costMult: number; weightMult: number; label: string }> = {
  Fine: { costMult: 0.5, weightMult: 0.1, label: "Fine" },
  Diminutive: { costMult: 0.5, weightMult: 0.1, label: "Diminutive" },
  Tiny: { costMult: 0.5, weightMult: 0.1, label: "Tiny" },
  Small: { costMult: 1, weightMult: 0.5, label: "Small" },
  Medium: { costMult: 1, weightMult: 1, label: "Medium" },
  Large: { costMult: 2, weightMult: 2, label: "Large" },
  Huge: { costMult: 4, weightMult: 5, label: "Huge" },
  Gargantuan: { costMult: 8, weightMult: 8, label: "Gargantuan" },
  Colossal: { costMult: 16, weightMult: 12, label: "Colossal" },
};

// Weapon cost/weight multipliers: SRD "This cost is the same for a Small or Medium version of the weapon. A Large version costs twice the listed price."
// "Halve this number for Small weapons and double it for Large weapons."
export const weaponSizeMultipliers: Record<string, { costMult: number; weightMult: number; label: string }> = {
  Fine: { costMult: 0.25, weightMult: 0.1, label: "Fine" },
  Diminutive: { costMult: 0.5, weightMult: 0.25, label: "Diminutive" },
  Tiny: { costMult: 0.5, weightMult: 0.5, label: "Tiny" },
  Small: { costMult: 1, weightMult: 0.5, label: "Small" },
  Medium: { costMult: 1, weightMult: 1, label: "Medium" },
  Large: { costMult: 2, weightMult: 2, label: "Large" },
  Huge: { costMult: 4, weightMult: 4, label: "Huge" },
  Gargantuan: { costMult: 8, weightMult: 8, label: "Gargantuan" },
  Colossal: { costMult: 16, weightMult: 16, label: "Colossal" },
};

// Weapon damage for non-medium sizes: per SRD "Larger and Smaller Weapon Damage" table
// We include a general step up/down for generic weapons when possible.

export const shieldList: Armor[] = armorList.filter(a => /shield|buckler|tower/i.test(a.name));
export const armorOnlyList: Armor[] = armorList.filter(a => !/shield|buckler|tower/i.test(a.name));
