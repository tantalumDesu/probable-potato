// Magic weapon tables: special abilities and specific weapons.

export interface WeaponAbility {
  name: string;
  bonus: number;
  minor?: [number, number];
  medium?: [number, number];
  major?: [number, number];
  aura: string;
  cl: number;
  description: string;
  restriction?: string;
}

export const weaponSpecialAbilities: WeaponAbility[] = [
  { name: "Bane", bonus: 1, minor: [1,10], medium: [1,6], major: [1,3], aura: "Conjuration", cl: 8,
    description: "A bane weapon excels against certain foes. Against its designated foe, its enhancement bonus is +2 better than its normal bonus, and it deals an extra 2d6 points of damage. The bane quality is assigned when the weapon is created; choose a creature type (and subtype if needed).",
    restriction: "Roll 1d4: 1-aberration, 2-animal, 3-magical beast, 4-undead for minor; broader for major." },
  { name: "Defending", bonus: 1, minor: [11,17], medium: [7,12], aura: "Abjuration", cl: 8,
    description: "A defending weapon allows the wielder to transfer some or all of its enhancement bonus to her AC as a bonus that stacks with all others. As a free action at the beginning of her turn, she chooses how much bonus to allocate to attacks and how much to AC." },
  { name: "Flaming", bonus: 1, minor: [18,27], medium: [13,19], major: [4,6], aura: "Evocation", cl: 10,
    description: "Upon command, a flaming weapon is sheathed in fire. The flames do not harm the weapon or wielder. The flames deal an extra 1d6 points of fire damage on a successful hit." },
  { name: "Frost", bonus: 1, minor: [28,37], medium: [20,26], major: [7,9], aura: "Evocation", cl: 8,
    description: "Upon command, a frost weapon is sheathed in icy cold. It deals an extra 1d6 points of cold damage on a successful hit." },
  { name: "Shock", bonus: 1, minor: [38,47], medium: [27,33], major: [10,12], aura: "Evocation", cl: 8,
    description: "Upon command, a shock weapon is sheathed in crackling electricity. It deals an extra 1d6 points of electricity damage on a successful hit." },
  { name: "Ghost touch", bonus: 1, minor: [48,56], medium: [34,38], major: [13,15], aura: "Conjuration", cl: 15,
    description: "A ghost touch weapon deals damage normally against incorporeal creatures, regardless of any miss chance. It can be picked up and moved by incorporeal creatures at any time. It counts as a corporeal or incorporeal weapon, whichever is more beneficial to the wielder." },
  { name: "Keen", bonus: 1, minor: [57,67], medium: [39,44], aura: "Transmutation", cl: 10,
    description: "This property doubles the threat range of a slashing or piercing weapon. For example, a keen longsword (threat range 19-20) has a threat range of 17-20. Multiple effects that increase a weapon's threat range don't stack.",
    restriction: "Piercing or slashing weapons only. Reroll if bludgeoning." },
  { name: "Ki focus", bonus: 1, minor: [68,71], medium: [45,48], major: [16,19], aura: "Transmutation", cl: 6,
    description: "This weapon allows a monk to use her unarmed strike damage with the weapon and to use her special unarmed-related feats with the weapon as if she were unarmed. It also serves as a divine focus for monks." },
  { name: "Merciful", bonus: 1, minor: [72,75], medium: [49,50], aura: "Enchantment", cl: 5,
    description: "The weapon deals an extra 1d6 points of nonlethal damage, and all damage it deals is nonlethal damage. On command, it suppresses this ability and deals lethal damage." },
  { name: "Mighty cleaving", bonus: 1, minor: [76,82], medium: [51,54], major: [20,21], aura: "Evocation", cl: 8,
    description: "A mighty cleaving weapon allows the wielder to use the Cleave feat. If the wielder already has Cleave (or Great Cleave), she can make one additional cleave per round (stacking with Great Cleave)." },
  { name: "Spell storing", bonus: 1, minor: [83,87], medium: [55,59], major: [22,24], aura: "Evocation", cl: 12,
    description: "A spell storing weapon allows a spellcaster to store a single targeted spell of up to 3rd level in the weapon. Any time the weapon strikes a creature and the creature takes damage, the spell immediately targets that creature. The wielder can choose to deliver the spell or keep it. Only one spell can be stored at a time." },
  { name: "Throwing", bonus: 1, minor: [88,91], medium: [60,63], major: [25,28], aura: "Transmutation", cl: 5,
    description: "This weapon can be thrown as if it had a range increment of 10 feet (melee weapons only). If it already has a range increment, that increment doubles. The weapon returns to the thrower's hand just before the wielder's next turn regardless of whether it hits." },
  { name: "Thundering", bonus: 1, minor: [92,95], medium: [64,65], major: [29,32], aura: "Necromancy", cl: 5,
    description: "A thundering weapon produces a cacophonous roar when it strikes a successful critical hit. In addition to normal critical damage, the target must make a DC 14 Fortitude save or be permanently deafened." },
  { name: "Vicious", bonus: 1, minor: [96,99], medium: [66,69], major: [33,36], aura: "Necromancy", cl: 9,
    description: "When a vicious weapon strikes an opponent, it creates a flash of disruptive energy that deals an extra 2d6 points of damage to the opponent, but also deals 1d6 points of damage to the wielder." },
  { name: "Anarchic", bonus: 2, medium: [70,72], major: [37,41], aura: "Evocation", cl: 7,
    description: "An anarchic weapon is infused with the power of Chaos. It deals an extra 2d6 points of damage against lawful foes. A lawful character carrying or wielding one gains 1 negative level (never permanent, but lost while held)." },
  { name: "Axiomatic", bonus: 2, medium: [73,75], major: [42,46], aura: "Evocation", cl: 7,
    description: "An axiomatic weapon is infused with Law. It deals an extra 2d6 points of damage against chaotic foes. A chaotic character wielding one gains 1 negative level." },
  { name: "Disruption", bonus: 2, medium: [76,78], major: [47,49], aura: "Conjuration", cl: 14,
    description: "When a disruption weapon strikes an undead creature on a successful critical hit, the undead must make a DC 14 Will save or be destroyed outright. Against non-undead, no extra effect.",
    restriction: "Bludgeoning weapons only." },
  { name: "Flaming burst", bonus: 2, medium: [79,81], major: [50,54], aura: "Evocation", cl: 12,
    description: "Works like a flaming weapon, but a flaming burst weapon also explodes with flame upon a critical hit, dealing an extra 1d10 points of fire damage (plus 1d10 per damage die on the crit; e.g. x3 adds 2d10, x4 adds 3d10)." },
  { name: "Icy burst", bonus: 2, medium: [82,84], major: [55,59], aura: "Evocation", cl: 10,
    description: "Works like a frost weapon, but on a critical hit it explodes with cold, dealing an extra 1d10 cold damage (plus 1d10 per crit multiplier beyond x2)." },
  { name: "Holy", bonus: 2, medium: [85,87], major: [60,64], aura: "Evocation", cl: 7,
    description: "A holy weapon is infused with the power of Good. It deals an extra 2d6 points of damage against evil foes. An evil creature wielding one gains 2 negative levels." },
  { name: "Shocking burst", bonus: 2, medium: [88,90], major: [65,69], aura: "Evocation", cl: 10,
    description: "Works like a shock weapon, but on a critical hit the wielder also deals 1d10 extra electricity damage (plus 1d10 per crit multiplier beyond x2)." },
  { name: "Unholy", bonus: 2, medium: [91,93], major: [70,74], aura: "Evocation", cl: 7,
    description: "An unholy weapon is infused with Evil. It deals an extra 2d6 damage against good foes. A good creature wielding one gains 2 negative levels." },
  { name: "Wounding", bonus: 2, medium: [94,95], major: [75,78], aura: "Necromancy", cl: 10,
    description: "A wounding weapon deals 1 point of Constitution damage from blood loss when it hits a creature (creatures immune to critical hits immune). Multiple hits stack (though each hit deals only 1 Con damage)." },
  { name: "Speed", bonus: 3, major: [79,83], aura: "Transmutation", cl: 7,
    description: "When making a full attack action, the wielder of a speed weapon may make one extra attack with it. The attack uses her full base attack bonus plus other modifiers. This benefit is not cumulative with the haste spell or similar effects." },
  { name: "Brilliant energy", bonus: 4, major: [84,86], aura: "Transmutation", cl: 16,
    description: "A brilliant energy weapon has no physical substance, composed entirely of light. It ignores non-living matter (armor, shield, natural armor bonuses from non-living materials like stone constructs, etc.). It does not harm undead or constructs." },
  { name: "Dancing", bonus: 4, major: [87,88], aura: "Transmutation", cl: 15,
    description: "As a standard action, a dancing weapon can be loosed in the air. It fights independently for 4 rounds, attacking the nearest opponent each round, using the wielder's base attack bonus and attack modifiers. It returns to the wielder after 4 rounds." },
  { name: "Vorpal", bonus: 5, major: [89,90], aura: "Transmutation", cl: 18,
    description: "A vorpal weapon severs the head of an opponent on a natural 20 (that confirms as a critical hit), killing the creature instantly (if it has a head, is not immune to critical hits, etc.).",
    restriction: "Slashing weapons only." },
  // 100 on minor, 96-100 on medium, 91-100 on major: "Roll again twice"
  { name: "Roll twice", bonus: 0, minor: [100,100], medium: [96,100], major: [91,100], aura: "Varies", cl: 0,
    description: "Roll twice more on this table, adding two more special abilities to the weapon (ignoring duplicate results). Reroll any further 'roll twice' results." },
];

// Specific magic weapons (a selection)
export interface SpecificWeapon {
  name: string;
  bonus: number;
  price: number;
  aura: string;
  cl: number;
  description: string;
}

export const specificWeapons: SpecificWeapon[] = [
  { name: "Slammer +1", bonus: 1, price: 2305, aura: "no aura", cl: 0,
    description: "+1 club of darkwood. Masterwork and magically enhanced. Price: 2,305 gp." },
  { name: "Trident of warning +1", bonus: 1, price: 2615, aura: "Divination", cl: 3,
    description: "This +1 trident glows when it comes within 30 feet of traps. Price: 2,615 gp." },
  { name: "Trident of fish command +1", bonus: 1, price: 18650, aura: "Enchantment", cl: 6,
    description: "This +1 trident acts as a weapon of warning and allows the wielder to cast summon nature's ally III (summons 1d3 Medium sharks only) three times per day. Price: 18,650 gp." },
  { name: "Javelin of lightning +1", bonus: 1, price: 1500, aura: "Evocation", cl: 5,
    description: "This +1 javelin deals normal damage and then becomes a lightning bolt (5d6 points of electricity damage in a 100-foot line, Reflex DC 14 half). It is destroyed when cast. Price: 1,500 gp." },
  { name: "Slaying arrow (greater)", bonus: 1, price: 2282, aura: "Necromancy", cl: 13,
    description: "This +1 arrow forces a particular type of creature struck to make a DC 23 Fortitude save or die instantly. Arrow is consumed. Price: 2,282 gp (greater); normal slaying arrow 1,400 gp DC 20." },
  { name: "Dagger of venom +1", bonus: 1, price: 8302, aura: "Necromancy", cl: 5,
    description: "Once per day, this +1 dagger can envenom its blade (use-activated). A foe struck must succeed on a DC 14 Fortitude save or suffer from black adder venom (1d6 Con/1d6 Con, secondary). Price: 8,302 gp." },
  { name: "Nine lives stealer +2", bonus: 2, price: 23007, aura: "Necromancy", cl: 9,
    description: "This +2 longsword will steal the life force of any enemy reduced to -1 hit points or below, absorbing a 'life'. It can hold 9 lives, and the wielder can use a stored life to avoid being killed by a death effect or negative level, or to reroll a natural 1 on a save. Price: 23,007 gp." },
  { name: "Oathbow +2", bonus: 2, price: 25600, aura: "Evocation", cl: 15,
    description: "Of elven make, this +2 composite longbow (+2 Str bonus) whispers, 'Swift defeat to my enemies' in Elven when nocked. As a swift action, you can swear to eliminate one enemy. Against that enemy it gains +5 enhancement and +3d6 damage. Price: 25,600 gp." },
  { name: "Sword of subtlety +1", bonus: 1, price: 22310, aura: "Illusion", cl: 7,
    description: "This +1 short sword (or +1 rapier) grants a +4 competence bonus on Sneak Attack damage and +2 on Bluff checks to feint in combat. Price: 22,310 gp." },
  { name: "Sword of the planes +1", bonus: 1, price: 22315, aura: "Transmutation", cl: 10,
    description: "This +1 longsword has different enhancement bonuses on different planes: +2 on the Astral, +3 on the Ethereal, +4 on the Plane of Shadow, +5 on an Outer Plane aligned with its bearer. Price: 22,315 gp." },
  { name: "Mace of blood +2", bonus: 2, price: 23012, aura: "Necromancy", cl: 6,
    description: "This +2 heavy mace is sacred to a deity of slaughter. If the wielder is a worshipper of that deity, the mace does +1d6 damage on the first hit in a round against a living foe. Price: 23,012 gp." },
  { name: "Mace of smiting +1", bonus: 1, price: 25312, aura: "Transmutation", cl: 7,
    description: "This +1 heavy mace is bane against constructs (+2 extra enhancement, +2d6 damage). On a critical hit against a construct, it deals x3 damage and sends the construct back 10 feet. Price: 25,312 gp." },
  { name: "Sword of life stealing +2", bonus: 2, price: 25715, aura: "Necromancy", cl: 17,
    description: "This +2 longsword deals an extra 1d6 negative energy damage on a hit. The wielder gains 1d6 temporary hit points each time she deals damage in this way (lasts 10 minutes). Price: 25,715 gp." },
  { name: "Rapier of puncturing +2", bonus: 2, price: 50230, aura: "Transmutation", cl: 10,
    description: "This +2 wounding rapier deals 1 Con damage per hit as the wounding property. Price: 50,230 gp." },
  { name: "Flame tongue +1", bonus: 1, price: 20715, aura: "Evocation", cl: 12,
    description: "This +1 flaming burst longsword blazes with fire, glows red when within 60 feet of fiery creatures, and can be used to cast fireball once per day (10d6 damage, DC 14 Reflex half). Price: 20,715 gp." },
  { name: "Frost brand +3", bonus: 3, price: 54475, aura: "Evocation", cl: 14,
    description: "This +3 frost greatsword sheds light as a torch, grants fire resistance 30 to the wielder, and can extinguish all non-magical fire within 10 feet when drawn. Price: 54,475 gp." },
  { name: "Holy avenger +2", bonus: 2, price: 120630, aura: "Abjuration", cl: 20,
    description: "In the hands of a paladin, this +2 holy cold iron longsword becomes a +5 holy cold iron longsword that provides spell resistance 30 to the wielder and a 30-foot magic circle against evil. Price: 120,630 gp." },
  { name: "Luck blade +2", bonus: 2, price: 22060, aura: "Enchantment", cl: 10,
    description: "This +2 short sword (or longsword) grants the wielder a +1 luck bonus on all saving throws. It may hold up to 4 wishes (roll 1d4-1 for wishes remaining when found; subtract charges rolled from the value). Price: 22,060 gp (with 0 wishes left; add 20,000 gp per wish charge up to 100,060 gp)." },
  { name: "Sword of sharpness +2", bonus: 2, price: 100310, aura: "Transmutation", cl: 15,
    description: "This +2 keen brilliant energy longsword has a blade composed of light. On command, light shines from the sword as a light spell. Price: 100,310 gp." },
  { name: "Vorpal sword +3", bonus: 5, price: 72310, aura: "Transmutation", cl: 18,
    description: "A +3 vorpal longsword, fearsomely sharp. On a natural 20 that confirms a critical hit, it severs the head of a corporeal opponent. Price: 72,310 gp." },
];

// Weapon type determination
export const weaponTypeTable: { min: number; max: number; type: string; label: string }[] = [
  { min: 1, max: 70, type: "commonMelee", label: "Common melee weapon" },
  { min: 71, max: 80, type: "uncommon", label: "Uncommon weapon" },
  { min: 81, max: 100, type: "commonRanged", label: "Common ranged weapon" },
];

// Melee weapon bonus table
export const meleeBonusTable: Record<"minor"|"medium"|"major", {min:number;max:number;bonus:number;label:string}[]> = {
  minor: [
    { min: 1, max: 70, bonus: 1, label: "+1 weapon" },
    { min: 71, max: 100, bonus: 0, label: "Specific weapon" },
  ],
  medium: [
    { min: 1, max: 10, bonus: 1, label: "+1 weapon" },
    { min: 11, max: 35, bonus: 2, label: "+2 weapon" },
    { min: 36, max: 100, bonus: 0, label: "Specific weapon" },
  ],
  major: [
    { min: 1, max: 15, bonus: 2, label: "+2 weapon" },
    { min: 16, max: 30, bonus: 3, label: "+3 weapon" },
    { min: 31, max: 55, bonus: 4, label: "+4 weapon" },
    { min: 56, max: 70, bonus: 5, label: "+5 weapon" },
    { min: 71, max: 100, bonus: 0, label: "Specific weapon" },
  ],
};
