// Coin generation for each CR level.
// Each entry is a {min, max, denomination: 'cp'|'sp'|'gp'|'pp', die: string}
// For subtables, roll on coinRollTable for the level.

export type CoinType = "cp" | "sp" | "gp" | "pp";

export interface CoinEntry {
  denomination: CoinType;
  die: string; // e.g. "1d6x1000"
  label: string;
}

// Main table: level -> d% ranges for coins.
// The die strings match SRD text exactly; we parse them as NdX*mult.
export const coinTableByLevel: Record<
  number,
  { min: number; max: number; die: string; label: string }[]
> = {
  1: [
    { min: 1, max: 14, die: "0", label: "—" },
    { min: 15, max: 29, die: "1d6x1000", label: "1d6 × 1,000 cp" },
    { min: 30, max: 52, die: "1d8x100", label: "1d8 × 100 sp" },
    { min: 53, max: 95, die: "2d8x10", label: "2d8 × 10 gp" },
    { min: 96, max: 100, die: "1d4x10", label: "1d4 × 10 pp" },
  ],
  2: [
    { min: 1, max: 13, die: "0", label: "—" },
    { min: 14, max: 23, die: "1d10x1000", label: "1d10 × 1,000 cp" },
    { min: 24, max: 43, die: "2d10x100", label: "2d10 × 100 sp" },
    { min: 44, max: 95, die: "4d10x10", label: "4d10 × 10 gp" },
    { min: 96, max: 100, die: "2d8x10", label: "2d8 × 10 pp" },
  ],
  3: [
    { min: 1, max: 11, die: "0", label: "—" },
    { min: 12, max: 21, die: "2d10x1000", label: "2d10 × 1,000 cp" },
    { min: 22, max: 41, die: "4d8x100", label: "4d8 × 100 sp" },
    { min: 42, max: 95, die: "1d4x100", label: "1d4 × 100 gp" },
    { min: 96, max: 100, die: "1d10x10", label: "1d10 × 10 pp" },
  ],
  4: [
    { min: 1, max: 11, die: "0", label: "—" },
    { min: 12, max: 21, die: "3d10x1000", label: "3d10 × 1,000 cp" },
    { min: 22, max: 41, die: "4d12x1000", label: "4d12 × 1,000 sp" },
    { min: 42, max: 95, die: "1d6x100", label: "1d6 × 100 gp" },
    { min: 96, max: 100, die: "1d8x10", label: "1d8 × 10 pp" },
  ],
  5: [
    { min: 1, max: 10, die: "0", label: "—" },
    { min: 11, max: 19, die: "1d4x10000", label: "1d4 × 10,000 cp" },
    { min: 20, max: 38, die: "1d6x1000", label: "1d6 × 1,000 sp" },
    { min: 39, max: 95, die: "1d8x100", label: "1d8 × 100 gp" },
    { min: 96, max: 100, die: "1d10x10", label: "1d10 × 10 pp" },
  ],
  6: [
    { min: 1, max: 10, die: "0", label: "—" },
    { min: 11, max: 18, die: "1d6x10000", label: "1d6 × 10,000 cp" },
    { min: 19, max: 37, die: "1d8x1000", label: "1d8 × 1,000 sp" },
    { min: 38, max: 95, die: "1d10x100", label: "1d10 × 100 gp" },
    { min: 96, max: 100, die: "1d12x10", label: "1d12 × 10 pp" },
  ],
  7: [
    { min: 1, max: 11, die: "0", label: "—" },
    { min: 12, max: 18, die: "1d10x10000", label: "1d10 × 10,000 cp" },
    { min: 19, max: 35, die: "1d12x1000", label: "1d12 × 1,000 sp" },
    { min: 36, max: 93, die: "2d6x100", label: "2d6 × 100 gp" },
    { min: 94, max: 100, die: "3d4x10", label: "3d4 × 10 pp" },
  ],
  8: [
    { min: 1, max: 10, die: "0", label: "—" },
    { min: 11, max: 15, die: "1d12x10000", label: "1d12 × 10,000 cp" },
    { min: 16, max: 29, die: "2d6x1000", label: "2d6 × 1,000 sp" },
    { min: 30, max: 87, die: "2d8x100", label: "2d8 × 100 gp" },
    { min: 88, max: 100, die: "3d6x10", label: "3d6 × 10 pp" },
  ],
  9: [
    { min: 1, max: 10, die: "0", label: "—" },
    { min: 11, max: 15, die: "2d6x10000", label: "2d6 × 10,000 cp" },
    { min: 16, max: 29, die: "2d8x1000", label: "2d8 × 1,000 sp" },
    { min: 30, max: 85, die: "5d4x100", label: "5d4 × 100 gp" },
    { min: 86, max: 100, die: "2d12x10", label: "2d12 × 10 pp" },
  ],
  10: [
    { min: 1, max: 10, die: "0", label: "—" },
    { min: 11, max: 24, die: "2d10x1000", label: "2d10 × 1,000 sp" },
    { min: 25, max: 79, die: "6d4x100", label: "6d4 × 100 gp" },
    { min: 80, max: 100, die: "5d6x10", label: "5d6 × 10 pp" },
  ],
  11: [
    { min: 1, max: 8, die: "0", label: "—" },
    { min: 9, max: 14, die: "3d10x1000", label: "3d10 × 1,000 sp" },
    { min: 15, max: 75, die: "4d8x100", label: "4d8 × 100 gp" },
    { min: 76, max: 100, die: "4d10x10", label: "4d10 × 10 pp" },
  ],
  12: [
    { min: 1, max: 8, die: "0", label: "—" },
    { min: 9, max: 14, die: "3d12x1000", label: "3d12 × 1,000 sp" },
    { min: 15, max: 75, die: "1d4x1000", label: "1d4 × 1,000 gp" },
    { min: 76, max: 100, die: "1d4x100", label: "1d4 × 100 pp" },
  ],
  13: [
    { min: 1, max: 8, die: "0", label: "—" },
    { min: 9, max: 75, die: "1d4x1000", label: "1d4 × 1,000 gp" },
    { min: 76, max: 100, die: "1d10x100", label: "1d10 × 100 pp" },
  ],
  14: [
    { min: 1, max: 8, die: "0", label: "—" },
    { min: 9, max: 75, die: "1d6x1000", label: "1d6 × 1,000 gp" },
    { min: 76, max: 100, die: "1d12x100", label: "1d12 × 100 pp" },
  ],
  15: [
    { min: 1, max: 3, die: "0", label: "—" },
    { min: 4, max: 74, die: "1d8x1000", label: "1d8 × 1,000 gp" },
    { min: 75, max: 100, die: "3d4x100", label: "3d4 × 100 pp" },
  ],
  16: [
    { min: 1, max: 3, die: "0", label: "—" },
    { min: 4, max: 74, die: "1d12x1000", label: "1d12 × 1,000 gp" },
    { min: 75, max: 100, die: "3d4x100", label: "3d4 × 100 pp" },
  ],
  17: [
    { min: 1, max: 3, die: "0", label: "—" },
    { min: 4, max: 68, die: "3d4x1000", label: "3d4 × 1,000 gp" },
    { min: 69, max: 100, die: "2d10x100", label: "2d10 × 100 pp" },
  ],
  18: [
    { min: 1, max: 2, die: "0", label: "—" },
    { min: 3, max: 65, die: "3d6x1000", label: "3d6 × 1,000 gp" },
    { min: 66, max: 100, die: "5d4x100", label: "5d4 × 100 pp" },
  ],
  19: [
    { min: 1, max: 2, die: "0", label: "—" },
    { min: 3, max: 65, die: "3d8x1000", label: "3d8 × 1,000 gp" },
    { min: 66, max: 100, die: "3d10x100", label: "3d10 × 100 pp" },
  ],
  20: [
    { min: 1, max: 2, die: "0", label: "—" },
    { min: 3, max: 65, die: "4d8x1000", label: "4d8 × 1,000 gp" },
    { min: 66, max: 100, die: "4d10x100", label: "4d10 × 100 pp" },
  ],
};

// Coin denominations and their exchange rates (in cp).
export const coinValueCP: Record<CoinType, number> = {
  cp: 1,
  sp: 10,
  gp: 100,
  pp: 1000,
};

export const coinNames: Record<CoinType, string> = {
  cp: "copper pieces",
  sp: "silver pieces",
  gp: "gold pieces",
  pp: "platinum pieces",
};
