// Mundane items table from SRD.
// Entries may reference further subtables.

export interface MundaneSubentry {
  min: number;
  max: number;
  name: string;
  value?: number;
  valueDie?: string;
  quantity?: string;
  description?: string;
  subtable?: string;
}

export interface MundaneCategory {
  min: number;
  max: number;
  category: string;
  subtable?: MundaneSubentry[];
  note?: string;
}

export const mundaneMasterTable: MundaneCategory[] = [
  {
    min: 1, max: 17, category: "Alchemical item",
    subtable: [
      { min: 1, max: 12, name: "Alchemist's fire", value: 20, quantity: "1d4",
        description: "Alchemist's fire is a mix of volatile fluids that ignites on contact with air. You can throw a flask as a splash weapon. A direct hit deals 1d6 points of fire damage; every creature within 5 feet takes 1 point of fire damage. On the round following a direct hit, the target takes an additional 1d6 points of fire damage unless it spends a full-round action extinguishing the flames." },
      { min: 13, max: 24, name: "Acid", value: 10, quantity: "2d4",
        description: "You can throw a flask of acid as a splash weapon. A direct hit deals 1d6 points of acid damage; every creature within 5 feet takes 1 point of acid damage." },
      { min: 25, max: 36, name: "Smokestick", value: 20, quantity: "1d4",
        description: "This alchemically treated wooden stick creates a cloud of thick smoke when ignited, filling a 10-foot cube for 1 round. The smoke obscures vision, providing concealment." },
      { min: 37, max: 48, name: "Holy water", value: 25, quantity: "1d4",
        description: "Holy water damages undead creatures and evil outsiders almost as acid damages most creatures. A direct hit deals 2d4 points of damage; every such creature within 5 feet takes 1 point of damage." },
      { min: 49, max: 62, name: "Antitoxin", value: 50, quantity: "1d4",
        description: "If you drink antitoxin, you get a +5 alchemical bonus on Fortitude saving throws against poison for 1 hour." },
      { min: 63, max: 74, name: "Everburning torch", value: 110, quantity: "1",
        description: "This torch has a continual flame spell cast on it. It clearly illuminates a 20-foot radius and sheds shadowy illumination out to 40 feet. It does not emit heat or use oxygen." },
      { min: 75, max: 88, name: "Tanglefoot bag", value: 50, quantity: "1d4",
        description: "When thrown at a creature as a ranged touch attack, the bag bursts and entangles the target. A successful DC 15 Reflex save avoids the effect. An entangled creature can break free with a DC 17 Strength check or by dealing 15 points of slashing damage to the goo." },
      { min: 89, max: 100, name: "Thunderstone", value: 30, quantity: "1d4",
        description: "You can throw this stone as a ranged attack. When it strikes a hard surface, it detonates in a loud crack. All creatures within a 10-foot radius must make a DC 15 Fortitude save or be deafened for 1 hour." },
    ],
  },
  {
    min: 18, max: 50, category: "Armor",
    note: "Roll d%: 01-10 Small, 11-100 Medium (we use the standard 30/60/10 size rule from Magic Item Basics: 30% Small, 60% Medium, 10% other).",
    subtable: [
      { min: 1, max: 12, name: "Chain shirt", value: 100, quantity: "1",
        description: "Chain shirt armor: light armor, +4 AC, +4 max Dex, -2 armor check penalty, 20% arcane spell failure, speed 30 ft./20 ft., 25 lb." },
      { min: 13, max: 18, name: "Masterwork studded leather", value: 175, quantity: "1",
        description: "Masterwork studded leather: light armor, +3 AC, +5 max Dex, 0 armor check penalty, 15% arcane spell failure, speed 30 ft./20 ft., 20 lb." },
      { min: 19, max: 26, name: "Breastplate", value: 200, quantity: "1",
        description: "Breastplate: medium armor, +5 AC, +3 max Dex, -4 armor check penalty, 25% arcane spell failure, speed 20 ft./15 ft., 30 lb." },
      { min: 27, max: 34, name: "Banded mail", value: 250, quantity: "1",
        description: "Banded mail: heavy armor, +6 AC, +1 max Dex, -5 armor check penalty, 35% arcane spell failure, speed 20 ft./15 ft., 35 lb." },
      { min: 35, max: 54, name: "Half-plate", value: 600, quantity: "1",
        description: "Half-plate: heavy armor, +7 AC, +0 max Dex, -7 armor check penalty, 40% arcane spell failure, speed 20 ft./15 ft., 50 lb." },
      { min: 55, max: 80, name: "Full plate", value: 1500, quantity: "1",
        description: "Full plate: heavy armor, +8 AC, +1 max Dex, -6 armor check penalty, 35% arcane spell failure, speed 20 ft./15 ft., 50 lb. Masterwork full plate (50 gp extra) has -5 armor check penalty." },
      { min: 81, max: 90, name: "Darkwood armor or shield", subtable: "darkwood" },
      { min: 91, max: 100, name: "Masterwork shield", subtable: "masterworkShield" },
    ],
  },
  {
    min: 51, max: 83, category: "Weapons",
    subtable: [
      { min: 1, max: 50, name: "Masterwork common melee weapon", subtable: "commonMeleeMasterwork" },
      { min: 51, max: 70, name: "Masterwork uncommon weapon", subtable: "uncommonMasterwork" },
      { min: 71, max: 100, name: "Masterwork common ranged weapon", subtable: "commonRangedMasterwork" },
    ],
  },
  {
    min: 84, max: 100, category: "Tools and gear",
    subtable: [
      { min: 1, max: 3, name: "Backpack, empty", value: 2 },
      { min: 4, max: 6, name: "Crowbar", value: 2, description: "A crowbar grants a +2 circumstance bonus on Strength checks made to force open doors or chests." },
      { min: 7, max: 11, name: "Bullseye lantern", value: 12, description: "Illuminates a 60-foot cone and 20 feet of shadowy illumination around the cone; burns for 6 hours per pint of oil." },
      { min: 12, max: 16, name: "Simple lock", value: 20, description: "DC 20 Open Lock check." },
      { min: 17, max: 21, name: "Average lock", value: 40, description: "DC 25 Open Lock check." },
      { min: 22, max: 28, name: "Good lock", value: 80, description: "DC 30 Open Lock check." },
      { min: 29, max: 35, name: "Superior lock", value: 150, description: "DC 40 Open Lock check." },
      { min: 36, max: 40, name: "Masterwork manacles", value: 50, description: "Hardness 10, 10 hp, DC 35 Escape Artist, DC 28 Strength to break." },
      { min: 41, max: 43, name: "Small steel mirror", value: 10, description: "Useful for looking around corners; also reflects gaze attacks." },
      { min: 44, max: 46, name: "Silk rope (50 ft.)", value: 10, description: "2 hp, DC 24 Strength check to break." },
      { min: 47, max: 53, name: "Spyglass", value: 1000, description: "Objects viewed through a spyglass are magnified to twice their size." },
      { min: 54, max: 58, name: "Masterwork artisan's tools", value: 55, description: "These tools grant a +2 circumstance bonus on Craft checks." },
      { min: 59, max: 63, name: "Climber's kit", value: 80, description: "Grants a +2 circumstance bonus on Climb checks; includes pitons, boot tips, gloves, and a harness." },
      { min: 64, max: 68, name: "Disguise kit", value: 50, description: "Grants a +2 circumstance bonus on Disguise checks; contains cosmetics, hair dye, small props, and clothing pieces." },
      { min: 69, max: 73, name: "Healer's kit", value: 50, description: "Grants a +2 circumstance bonus on Heal checks. Includes bandages, salves, and splints; has 10 uses." },
      { min: 74, max: 77, name: "Silver holy symbol", value: 25 },
      { min: 78, max: 81, name: "Hourglass", value: 25, description: "Accurate to within 10% over 1 hour." },
      { min: 82, max: 88, name: "Magnifying glass", value: 100, description: "Grants a +2 circumstance bonus on Appraise checks involving items that are small or highly detailed, and is required to read scrolls with very small writing." },
      { min: 89, max: 95, name: "Masterwork musical instrument", value: 100, description: "Masterwork quality; grants a +2 circumstance bonus on Perform checks with that instrument." },
      { min: 96, max: 100, name: "Masterwork thieves' tools", value: 50, description: "Grants a +2 circumstance bonus on Disable Device and Open Lock checks." },
    ],
  },
];

// Darkwood subtable
export const darkwoodSubtable: MundaneSubentry[] = [
  { min: 1, max: 50, name: "Darkwood buckler", value: 205, quantity: "1",
    description: "Darkwood is a very light, strong dark-colored wood. A darkwood shield weighs half as much as a normal shield; masterwork quality, with -0 armor check penalty. No arcane spell failure." },
  { min: 51, max: 100, name: "Darkwood shield", value: 257, quantity: "1",
    description: "A darkwood heavy shield weighs only 5 lb. Masterwork, -0 armor check penalty, no arcane spell failure chance." },
];

export const masterworkShieldSubtable: MundaneSubentry[] = [
  { min: 1, max: 17, name: "Masterwork buckler", value: 165, quantity: "1", description: "Masterwork buckler: +1 shield bonus, -0 armor check penalty, 5 lb." },
  { min: 18, max: 40, name: "Masterwork light wooden shield", value: 153, quantity: "1", description: "Masterwork light wooden shield: +1 shield bonus, -0 armor check penalty, 5 lb." },
  { min: 41, max: 60, name: "Masterwork light steel shield", value: 159, quantity: "1", description: "Masterwork light steel shield: +1 shield bonus, -0 armor check penalty, 6 lb." },
  { min: 61, max: 83, name: "Masterwork heavy wooden shield", value: 157, quantity: "1", description: "Masterwork heavy wooden shield: +2 shield bonus, -1 armor check penalty, 10 lb." },
  { min: 84, max: 100, name: "Masterwork heavy steel shield", value: 170, quantity: "1", description: "Masterwork heavy steel shield: +2 shield bonus, -1 armor check penalty, 15 lb." },
];
