// Correct SRD generation tables for magic armor, shields, and weapons.
// These replace earlier approximations and are transcribed from
// d20srd.org (Magic Armor / Magic Weapons pages).

export type Tier = "minor" | "medium" | "major";

export interface EnhEntry {
  min: number;
  max: number;
  kind: "enhShield" | "enhArmor" | "specificArmor" | "specificShield" | "abilityRollAgain";
  bonus?: number;
  label: string;
  basePrice?: number; // market price of the enhancement bonus alone
}

// Table: Armor and Shields (Magic Armor page)
export const armorEnhTable: Record<Tier, EnhEntry[]> = {
  minor: [
    { min: 1, max: 60, kind: "enhShield", bonus: 1, label: "+1 shield", basePrice: 1000 },
    { min: 61, max: 80, kind: "enhArmor", bonus: 1, label: "+1 armor", basePrice: 1000 },
    { min: 81, max: 85, kind: "enhShield", bonus: 2, label: "+2 shield", basePrice: 4000 },
    { min: 86, max: 87, kind: "enhArmor", bonus: 2, label: "+2 armor", basePrice: 4000 },
    { min: 88, max: 89, kind: "specificArmor", label: "Specific armor" },
    { min: 90, max: 91, kind: "specificShield", label: "Specific shield" },
    { min: 92, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
  medium: [
    { min: 1, max: 5, kind: "enhShield", bonus: 1, label: "+1 shield", basePrice: 1000 },
    { min: 6, max: 10, kind: "enhArmor", bonus: 1, label: "+1 armor", basePrice: 1000 },
    { min: 11, max: 20, kind: "enhShield", bonus: 2, label: "+2 shield", basePrice: 4000 },
    { min: 21, max: 30, kind: "enhArmor", bonus: 2, label: "+2 armor", basePrice: 4000 },
    { min: 31, max: 40, kind: "enhShield", bonus: 3, label: "+3 shield", basePrice: 9000 },
    { min: 41, max: 50, kind: "enhArmor", bonus: 3, label: "+3 armor", basePrice: 9000 },
    { min: 51, max: 55, kind: "enhShield", bonus: 4, label: "+4 shield", basePrice: 16000 },
    { min: 56, max: 57, kind: "enhArmor", bonus: 4, label: "+4 armor", basePrice: 16000 },
    { min: 58, max: 60, kind: "specificArmor", label: "Specific armor" },
    { min: 61, max: 63, kind: "specificShield", label: "Specific shield" },
    { min: 64, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
  major: [
    { min: 1, max: 8, kind: "enhShield", bonus: 3, label: "+3 shield", basePrice: 9000 },
    { min: 9, max: 16, kind: "enhArmor", bonus: 3, label: "+3 armor", basePrice: 9000 },
    { min: 17, max: 27, kind: "enhShield", bonus: 4, label: "+4 shield", basePrice: 16000 },
    { min: 28, max: 38, kind: "enhArmor", bonus: 4, label: "+4 armor", basePrice: 16000 },
    { min: 39, max: 49, kind: "enhShield", bonus: 5, label: "+5 shield", basePrice: 25000 },
    { min: 50, max: 57, kind: "enhArmor", bonus: 5, label: "+5 armor", basePrice: 25000 },
    { min: 58, max: 60, kind: "specificArmor", label: "Specific armor" },
    { min: 61, max: 63, kind: "specificShield", label: "Specific shield" },
    { min: 64, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
};

// Table: Weapons (Magic Weapons page)
export interface WeaponEnhEntry {
  min: number;
  max: number;
  kind: "enh" | "specific" | "abilityRollAgain";
  bonus?: number;
  label: string;
  basePrice?: number;
}

export const weaponEnhTable: Record<Tier, WeaponEnhEntry[]> = {
  minor: [
    { min: 1, max: 70, kind: "enh", bonus: 1, label: "+1 weapon", basePrice: 2000 },
    { min: 71, max: 85, kind: "enh", bonus: 2, label: "+2 weapon", basePrice: 8000 },
    { min: 86, max: 90, kind: "specific", label: "Specific weapon" },
    { min: 91, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
  medium: [
    { min: 1, max: 10, kind: "enh", bonus: 1, label: "+1 weapon", basePrice: 2000 },
    { min: 11, max: 29, kind: "enh", bonus: 2, label: "+2 weapon", basePrice: 8000 },
    { min: 30, max: 58, kind: "enh", bonus: 3, label: "+3 weapon", basePrice: 18000 },
    { min: 59, max: 62, kind: "enh", bonus: 4, label: "+4 weapon", basePrice: 32000 },
    { min: 63, max: 68, kind: "specific", label: "Specific weapon" },
    { min: 69, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
  major: [
    { min: 1, max: 20, kind: "enh", bonus: 3, label: "+3 weapon", basePrice: 18000 },
    { min: 21, max: 38, kind: "enh", bonus: 4, label: "+4 weapon", basePrice: 32000 },
    { min: 39, max: 49, kind: "enh", bonus: 5, label: "+5 weapon", basePrice: 50000 },
    { min: 50, max: 63, kind: "specific", label: "Specific weapon" },
    { min: 64, max: 100, kind: "abilityRollAgain", label: "Special ability and roll again" },
  ],
};

// Table: Random Armor Type (masterwork cost already included in these figures)
export const randomArmorType: { min: number; max: number; name: string; mwCost: number; category: string }[] = [
  { min: 1, max: 1, name: "Padded", mwCost: 155, category: "light" },
  { min: 2, max: 2, name: "Leather", mwCost: 160, category: "light" },
  { min: 3, max: 17, name: "Studded leather", mwCost: 175, category: "light" },
  { min: 18, max: 32, name: "Chain shirt", mwCost: 250, category: "light" },
  { min: 33, max: 42, name: "Hide", mwCost: 165, category: "medium" },
  { min: 43, max: 43, name: "Scale mail", mwCost: 200, category: "medium" },
  { min: 44, max: 44, name: "Chainmail", mwCost: 300, category: "medium" },
  { min: 45, max: 57, name: "Breastplate", mwCost: 350, category: "medium" },
  { min: 58, max: 58, name: "Splint mail", mwCost: 350, category: "heavy" },
  { min: 59, max: 59, name: "Banded mail", mwCost: 400, category: "heavy" },
  { min: 60, max: 60, name: "Half-plate", mwCost: 750, category: "heavy" },
  { min: 61, max: 100, name: "Full plate", mwCost: 1650, category: "heavy" },
];

// Table: Random Shield Type (masterwork cost already included)
export const randomShieldType: { min: number; max: number; name: string; mwCost: number }[] = [
  { min: 1, max: 10, name: "Buckler", mwCost: 165 },
  { min: 11, max: 15, name: "Light wooden shield", mwCost: 153 },
  { min: 16, max: 20, name: "Light steel shield", mwCost: 159 },
  { min: 21, max: 30, name: "Heavy wooden shield", mwCost: 157 },
  { min: 31, max: 95, name: "Heavy steel shield", mwCost: 170 },
  { min: 96, max: 100, name: "Tower shield", mwCost: 180 },
];

// Table: Specific Armors
export interface SpecificArmorEntry {
  name: string;
  price: number;
  tiers: { minor?: [number, number]; medium?: [number, number]; major?: [number, number] };
  baseArmor?: string; // for size adjustment of the mundane portion
  baseArmorCost?: number;
  description: string;
}

export const specificArmorsSRD: SpecificArmorEntry[] = [
  { name: "Mithral shirt", price: 1100,
    tiers: { minor: [1, 50], medium: [1, 25] },
    baseArmor: "Chain shirt", baseArmorCost: 100,
    description: "This extremely light chain shirt is made of very fine mithral links. Speed while wearing a mithral shirt is 30 feet for Medium creatures, or 20 feet for Small. The armor has an arcane spell failure chance of 10%, a maximum Dexterity bonus of +6, and no armor check penalty. It is considered light armor and weighs 10 pounds.\n\nNo aura (nonmagical); Price 1,100 gp." },
  { name: "Dragonhide plate", price: 3300,
    tiers: { minor: [51, 80], medium: [26, 45] },
    baseArmor: "Full plate", baseArmorCost: 1500,
    description: "This suit of full plate is made of dragonhide, rather than metal, so druids can wear it. It is otherwise identical to masterwork full plate.\n\nNo aura (nonmagical); Price 3,300 gp." },
  { name: "Elven chain", price: 4150,
    tiers: { minor: [81, 100], medium: [46, 57] },
    baseArmor: "Chainmail", baseArmorCost: 150,
    description: "This extremely light chainmail is made of very fine mithral links. Speed while wearing elven chain is 30 feet for Medium creatures, or 20 feet for Small. The armor has an arcane spell failure chance of 20%, a maximum Dexterity bonus of +4, and an armor check penalty of -2. It is considered light armor and weighs 20 pounds.\n\nNo aura (nonmagical); Price 4,150 gp." },
  { name: "Rhino hide", price: 5165,
    tiers: { medium: [58, 67] },
    baseArmor: "Hide", baseArmorCost: 15,
    description: "This +2 hide armor is made from rhinoceros hide. In addition to granting a +2 enhancement bonus to AC, it has a -1 armor check penalty and deals an additional 2d6 points of damage on any successful charge attack made by the wearer, including a mounted charge.\n\nModerate transmutation; CL 9th; Craft Magic Arms and Armor, bull's strength; Price 5,165 gp." },
  { name: "Adamantine breastplate", price: 10200,
    tiers: { medium: [68, 82], major: [1, 10] },
    baseArmor: "Breastplate", baseArmorCost: 200,
    description: "This nonmagical breastplate is made of adamantine, giving its wearer damage reduction 2/-.\n\nNo aura (nonmagical); Price 10,200 gp." },
  { name: "Dwarven plate", price: 16500,
    tiers: { medium: [83, 97], major: [11, 20] },
    baseArmor: "Full plate", baseArmorCost: 1500,
    description: "This full plate is made of adamantine, giving its wearer damage reduction 3/-.\n\nNo aura (nonmagical); Price 16,500 gp." },
  { name: "Banded mail of luck", price: 18900,
    tiers: { medium: [98, 100], major: [21, 32] },
    baseArmor: "Banded mail", baseArmorCost: 250,
    description: "Ten 100-gp gems adorn this +3 banded mail. Once per week, the armor allows its wearer to require that an attack roll made against him be rerolled. He must take whatever consequences come from the second roll. The wearer's player must decide whether to have the attack roll rerolled before damage is rolled.\n\nStrong enchantment; CL 12th; Craft Magic Arms and Armor, bless; Price 18,900 gp." },
  { name: "Celestial armor", price: 22400,
    tiers: { major: [33, 50] },
    baseArmor: "Chainmail", baseArmorCost: 150,
    description: "This bright silver or gold +3 chainmail is so fine and light that it can be worn under normal clothing without betraying its presence. It has a maximum Dexterity bonus of +8, an armor check penalty of -2, and an arcane spell failure chance of 15%. It is considered light armor, weighs 20 pounds, and it allows the wearer to use fly on command (as the spell) once per day.\n\nFaint transmutation [good]; CL 5th; Craft Magic Arms and Armor, creator must be good, fly; Price 22,400 gp." },
  { name: "Plate armor of the deep", price: 24650,
    tiers: { major: [51, 60] },
    baseArmor: "Full plate", baseArmorCost: 1500,
    description: "This +1 full plate is decorated with a wave and fish motif. The wearer of plate armor of the deep is treated as unarmored for purposes of Swim checks. The wearer can breathe underwater and can converse with any creature with a language that breathes water.\n\nModerate abjuration; CL 11th; Craft Magic Arms and Armor, freedom of movement, water breathing, tongues; Price 24,650 gp." },
  { name: "Breastplate of command", price: 25400,
    tiers: { major: [61, 75] },
    baseArmor: "Breastplate", baseArmorCost: 200,
    description: "This finely crafted +2 breastplate radiates a powerful aura of magic. When worn, the armor bestows a dignified and commanding aura upon its owner. The wearer gains a +2 competence bonus on all Charisma checks, including turning checks and Charisma-based skill checks. The wearer also gains a +2 competence bonus to his Leadership score. Friendly troops within 360 feet of the user become braver than normal. Since the effect arises in great part from the distinctiveness of the armor, the wearer cannot hide or conceal herself in any way and still have the effect function.\n\nStrong enchantment; CL 15th; Craft Magic Arms and Armor, mass charm monster; Price 25,400 gp." },
  { name: "Mithral full plate of speed", price: 26500,
    tiers: { major: [76, 90] },
    baseArmor: "Full plate", baseArmorCost: 1500,
    description: "As a free action, the wearer of this fine set of +1 mithral full plate can activate it, enabling her to act as though affected by a haste spell for up to 10 rounds each day. The duration of the haste effect need not be consecutive rounds.\n\nSpeed while wearing a suit of mithral full plate is 20 feet for Medium creatures, or 15 feet for Small. The armor has an arcane spell failure chance of 25%, a maximum Dexterity bonus of +3, and an armor check penalty of -3. It is considered medium armor and weighs 25 pounds.\n\nFaint transmutation; CL 5th; Craft Magic Arms and Armor, haste; Price 26,500 gp." },
  { name: "Demon armor", price: 52260,
    tiers: { major: [91, 100] },
    baseArmor: "Full plate", baseArmorCost: 1500,
    description: "This plate armor is fashioned to make the wearer appear to be a demon. The helmet is shaped to look like a horned demon head, and its wearer looks out of the open, tooth-filled mouth. This +4 full plate allows the wearer to make claw attacks that deal 1d10 points of damage, strike as +1 weapons, and afflict the target as if she had been struck by a contagion spell (Fortitude DC 14 negates). Use of contagion requires a normal melee attack with the claws. The 'claws' are built into the armor's vambraces and gauntlets.\n\nThe armor bestows one negative level on any nonevil creature wearing it. This negative level persists as long as the armor is worn and disappears when the armor is removed. The negative level never results in actual level loss, but it cannot be overcome in any way (including restoration spells) while the armor is worn.\n\nStrong necromancy [evil]; CL 13th; Craft Magic Arms and Armor, contagion; Price 52,260 gp." },
];

// Table: Specific Shields
export interface SpecificShieldEntry {
  name: string;
  price: number;
  tiers: { minor?: [number, number]; medium?: [number, number]; major?: [number, number] };
  baseShieldCost?: number;
  description: string;
}

export const specificShieldsSRD: SpecificShieldEntry[] = [
  { name: "Darkwood buckler", price: 205,
    tiers: { minor: [1, 30], medium: [1, 20] }, baseShieldCost: 15,
    description: "This nonmagical light wooden shield is made out of darkwood. It has no enhancement bonus, but its construction material makes it lighter than a normal wooden shield. It weighs 2½ pounds and has no armor check penalty.\n\nNo aura (nonmagical); Price 205 gp." },
  { name: "Darkwood shield", price: 257,
    tiers: { minor: [31, 80], medium: [21, 45] }, baseShieldCost: 7,
    description: "This nonmagical heavy wooden shield is made out of darkwood. It has no enhancement bonus, but its construction material makes it lighter than a normal wooden shield. It weighs 5 pounds and has no armor check penalty.\n\nNo aura (nonmagical); Price 257 gp." },
  { name: "Mithral heavy shield", price: 1020,
    tiers: { minor: [81, 95], medium: [46, 70] }, baseShieldCost: 20,
    description: "This heavy shield is made of mithral and thus is much lighter than a standard steel shield. It has a 5% arcane spell failure chance and no armor check penalty. It weighs 5 pounds.\n\nNo aura (nonmagical); Price 1,020 gp." },
  { name: "Caster's shield", price: 3153,
    tiers: { minor: [96, 100], medium: [71, 85], major: [1, 20] }, baseShieldCost: 20,
    description: "This +1 light wooden shield has a small leather strip on the back on which a spellcaster can scribe a single spell as on a scroll. A spell so scribed has only half the base raw material cost. Experience point and component costs remain the same. The strip cannot accommodate spells of higher than 3rd level. The strip is reusable.\n\nA random caster's shield has a 50% chance of having a single medium scroll spell on it. The spell is divine (01-80 on d%) or arcane (81-100).\n\nA caster's shield has a 5% arcane spell failure chance.\n\nModerate abjuration; CL 6th; Craft Magic Arms and Armor, Scribe Scroll, creator must be at least 6th level; Price 3,153 gp (plus the value of the scroll spell if one is currently scribed)." },
  { name: "Spined shield", price: 5580,
    tiers: { medium: [86, 90], major: [21, 40] }, baseShieldCost: 20,
    description: "This +1 heavy steel shield is covered in spines. It acts as a normal spiked shield. On command up to three times per day, the shield's wearer can fire one of the shield's spines. A fired spine has a +1 enhancement bonus, a range increment of 120 feet, and deals 1d10 points of damage (19-20/×2). Fired spines regenerate each day.\n\nModerate evocation; CL 6th; Craft Magic Arms and Armor, magic missile; Price 5,580 gp." },
  { name: "Lion's shield", price: 9170,
    tiers: { medium: [91, 95], major: [41, 60] }, baseShieldCost: 20,
    description: "This +2 heavy steel shield is fashioned to appear to be a roaring lion's head. Three times per day as a free action, the lion's head can be commanded to attack (independently of the shield wearer), biting with the wielder's base attack bonus (including multiple attacks, if the wielder has them) and dealing 2d6 points of damage. This attack is in addition to any actions performed by the wielder.\n\nModerate conjuration; CL 10th; Craft Magic Arms and Armor, summon nature's ally IV; Price 9,170 gp." },
  { name: "Winged shield", price: 17257,
    tiers: { medium: [96, 100], major: [61, 90] }, baseShieldCost: 7,
    description: "This round heavy wooden shield has a +3 enhancement bonus. Small, feathered wings encircle the shield.\n\nOnce per day it can be commanded to fly (as the spell), carrying the wielder. The shield can carry up to 133 pounds and move at 60 feet per round, or up to 266 pounds and move at 40 feet per round.\n\nFaint transmutation; CL 5th; Craft Magic Arms and Armor, fly; Price 17,257 gp." },
  { name: "Absorbing shield", price: 50170,
    tiers: { major: [91, 100] }, baseShieldCost: 20,
    description: "This +1 heavy steel shield is flat black and seems to absorb light. Once every two days, on command, it can disintegrate an object that it touches, as the spell but requiring a melee touch attack.\n\nStrong transmutation; CL 17th; Craft Magic Arms and Armor, disintegrate; Price 50,170 gp." },
];

// Special materials for armor/weapons: SRD says roll d%, 01-95 standard, 96-100 special material.
export const specialMaterialTable: { min: number; max: number; material: string | null; note?: string }[] = [
  { min: 1, max: 95, material: null, note: "Standard material" },
  { min: 96, max: 96, material: "Adamantine", note: "Applies to weapons, armor, shields (see specialMaterials)" },
  { min: 97, max: 97, material: "Mithral", note: "Applies to weapons, armor, shields" },
  { min: 98, max: 98, material: "Alchemical silver", note: "Applies to weapons only" },
  { min: 99, max: 99, material: "Cold iron", note: "Applies to weapons only" },
  { min: 100, max: 100, material: "Dragonhide", note: "Applies to armor only" },
];

// Weapon masterwork-inclusive base costs from Table: Common Melee Weapons,
// Table: Uncommon Weapons, Table: Common Ranged Weapons. These figures include
// the masterwork cost (and doubled masterwork cost for double weapons).
export const commonMeleeMW: { min: number; max: number; name: string; mwCost: number }[] = [
  { min: 1, max: 4, name: "Dagger", mwCost: 302 },
  { min: 5, max: 14, name: "Greataxe", mwCost: 320 },
  { min: 15, max: 24, name: "Greatsword", mwCost: 350 },
  { min: 25, max: 28, name: "Kama", mwCost: 302 },
  { min: 29, max: 41, name: "Longsword", mwCost: 315 },
  { min: 42, max: 45, name: "Light mace", mwCost: 305 },
  { min: 46, max: 50, name: "Heavy mace", mwCost: 312 },
  { min: 51, max: 54, name: "Nunchaku", mwCost: 302 },
  { min: 55, max: 57, name: "Quarterstaff", mwCost: 600 },
  { min: 58, max: 61, name: "Rapier", mwCost: 320 },
  { min: 62, max: 66, name: "Scimitar", mwCost: 315 },
  { min: 67, max: 70, name: "Shortspear", mwCost: 302 },
  { min: 71, max: 74, name: "Light shield", mwCost: 303 },
  { min: 75, max: 77, name: "Short sword", mwCost: 310 },
  { min: 78, max: 80, name: "Sickle", mwCost: 306 },
  { min: 81, max: 83, name: "Spear", mwCost: 302 },
  { min: 84, max: 86, name: "Spiked armor", mwCost: 350 },
  { min: 87, max: 89, name: "Spiked gauntlet", mwCost: 302 },
  { min: 90, max: 92, name: "Spiked shield, light", mwCost: 310 },
  { min: 93, max: 95, name: "Spiked shield, heavy", mwCost: 320 },
  { min: 96, max: 100, name: "Longspear", mwCost: 305 },
];

export const uncommonMW: { min: number; max: number; name: string; mwCost: number }[] = [
  { min: 1, max: 8, name: "Battleaxe", mwCost: 310 },
  { min: 9, max: 14, name: "Waraxe, dwarven", mwCost: 330 },
  { min: 15, max: 20, name: "Flail, heavy", mwCost: 315 },
  { min: 21, max: 26, name: "Flail, light", mwCost: 308 },
  { min: 27, max: 32, name: "Glaive", mwCost: 308 },
  { min: 33, max: 39, name: "Hammer, gnome hooked", mwCost: 620 },
  { min: 40, max: 44, name: "Halberd", mwCost: 310 },
  { min: 45, max: 48, name: "Handaxe", mwCost: 306 },
  { min: 49, max: 53, name: "Lance", mwCost: 310 },
  { min: 54, max: 56, name: "Pick, heavy", mwCost: 308 },
  { min: 57, max: 60, name: "Pick, light", mwCost: 304 },
  { min: 61, max: 64, name: "Ranseur", mwCost: 310 },
  { min: 65, max: 69, name: "Scythe", mwCost: 318 },
  { min: 70, max: 75, name: "Longsword (bastard)", mwCost: 335 },
  { min: 76, max: 79, name: "Shortspear (trident)", mwCost: 315 },
  { min: 80, max: 84, name: "Urgrosh, dwarven", mwCost: 650 },
  { min: 85, max: 90, name: "Warhammer", mwCost: 312 },
  { min: 91, max: 94, name: "Whip", mwCost: 301 },
  { min: 95, max: 100, name: "Sword, two-bladed", mwCost: 700 },
];

export const commonRangedMW: { min: number; max: number; name: string; mwCost: number }[] = [
  { min: 1, max: 9, name: "Crossbow, heavy", mwCost: 350 },
  { min: 10, max: 18, name: "Crossbow, light", mwCost: 335 },
  { min: 19, max: 21, name: "Bolts (50)", mwCost: 301 },
  { min: 22, max: 24, name: "Dart", mwCost: 300.5 },
  { min: 25, max: 28, name: "Javelin", mwCost: 301 },
  { min: 29, max: 36, name: "Longbow", mwCost: 375 },
  { min: 37, max: 48, name: "Longbow, composite", mwCost: 400 },
  { min: 49, max: 53, name: "Arrows (50)", mwCost: 301 },
  { min: 54, max: 58, name: "Shortbow", mwCost: 330 },
  { min: 59, max: 70, name: "Shortbow, composite", mwCost: 375 },
  { min: 71, max: 100, name: "Sling", mwCost: 300 },
];

// Table: Specific Weapons (SRD) — prices and tier ranges
export interface SpecificWeaponSRD {
  name: string;
  price: number;
  tiers: { minor?: [number, number]; medium?: [number, number]; major?: [number, number] };
  description: string;
}

export const specificWeaponsSRD: SpecificWeaponSRD[] = [
  { name: "Screaming bolt", price: 267,
    tiers: { minor: [1, 8] },
    description: "One of these +2 bolts screams when fired, forcing all enemies of the wielder within 20 feet of the path of the bolt to succeed on a DC 14 Will save or become shaken. This is a mind-affecting fear effect. (Sold in quantities of 50.)\n\nFaint enchantment; CL 5th; Craft Magic Arms and Armor, doom; Price 267 gp (per 50)." },
  { name: "Sleep arrow", price: 132,
    tiers: { minor: [9, 18] },
    description: "This +1 arrow is painted white and has white fletching. If it strikes a foe so that it would normally deal damage, it instead bursts into magical energy that deals nonlethal damage (in the same amount as would be lethal damage) and forces the target to make a DC 11 Will save or fall asleep.\n\nFaint enchantment; CL 5th; Craft Magic Arms and Armor, sleep; Price 132 gp." },
  { name: "Masterwork silver dagger", price: 322,
    tiers: { minor: [19, 28] },
    description: "This masterwork alchemical silver dagger is nonmagical. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls.\n\nNo aura (nonmagical); Price 322 gp." },
  { name: "Slaying arrow", price: 2282,
    tiers: { minor: [29, 46], medium: [1, 10] },
    description: "This +1 arrow is keyed to a particular type or subtype of creature. If it strikes such a creature, the target must make a DC 20 Fortitude save or die (or, in the case of unliving targets, be destroyed) instantly. Note that even creatures normally exempt from Fortitude saves (undead and constructs) are subject to this attack. When keyed to a living creature, this is a death effect (and thus death ward protects a target).\n\nStrong necromancy; CL 13th; Craft Magic Arms and Armor, finger of death; Price 2,282 gp." },
  { name: "Masterwork cold iron longsword", price: 330,
    tiers: { minor: [47, 56] },
    description: "This nonmagical longsword is crafted out of cold iron. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls.\n\nNo aura (nonmagical); Price 330 gp." },
  { name: "Javelin of lightning", price: 1500,
    tiers: { minor: [57, 72] },
    description: "This javelin becomes a 5d6 lightning bolt when thrown (Reflex DC 14 half). It is expended after one use.\n\nFaint evocation; CL 5th; Craft Magic Arms and Armor, lightning bolt; Price 1,500 gp." },
  { name: "Shatterspike", price: 4315,
    tiers: { minor: [73, 86], medium: [11, 20] },
    description: "Wielders without the Improved Sunder feat use Shatterspike as a +1 longsword only; wielders with the Improved Sunder feat add a +4 bonus (including the sword's +1 enhancement bonus) to the opposed roll when attempting to strike a foe's weapon. If successful, Shatterspike deals 1d8+4 points of damage plus the wielder's Strength modifier to the target weapon (the target weapon's hardness must still be overcome with each hit). Shatterspike can damage weapons with an enhancement bonus of +4 or lower.\n\nStrong evocation; CL 13th; Str 13, Craft Magic Arms and Armor, Power Attack, Improved Sunder, shatter; Price 4,315 gp; Weight 4 lb." },
  { name: "Dagger of venom", price: 8302,
    tiers: { minor: [87, 100], medium: [21, 30] },
    description: "This +1 dagger allows the wielder to use a poison effect once per day on command (black adder venom: injury, Fortitude DC 14, 1d6 Con/1d6 Con).\n\nFaint necromancy; CL 5th; Craft Magic Arms and Armor, poison; Price 8,302 gp." },
  { name: "Trident of warning", price: 10115,
    tiers: { medium: [31, 40] },
    description: "A weapon of this type enables its wielder to determine the location, depth, kind, and number of aquatic predators within 680 feet. A trident of warning must be grasped and pointed in order for the character using it to gain such information, and it requires 1 round to scan a hemisphere with a radius of 680 feet. The weapon is otherwise a +2 trident.\n\nModerate divination; CL 7th; Craft Magic Arms and Armor, locate creature; Price 10,115 gp." },
  { name: "Nine lives stealer", price: 23057,
    tiers: { medium: [41, 50], major: [1, 12] },
    description: "This longsword always performs as a +2 longsword, but it also has the power to draw the life force from an opponent. It can do this nine times before the ability is lost. At that point, the sword becomes a simple +2 longsword (with a hint of evil about it). A critical hit must be dealt for the sword's death-dealing ability to function, and this weapon has no effect on creatures not subject to critical hits. The victim is entitled to a DC 20 Fortitude save to avoid death. If the save is successful, the sword's death-dealing ability does not function, no use of the ability is expended, and normal critical damage is determined. This sword is evil, and any good character attempting to wield it gains two negative levels.\n\nStrong necromancy [evil]; CL 13th; Craft Magic Arms and Armor, finger of death; Price 23,057 gp." },
  { name: "Sword of subtlety", price: 22310,
    tiers: { medium: [51, 60], major: [13, 24] },
    description: "A +1 short sword with a thin, dull gray blade, this weapon provides a +4 bonus on its wielder's attack and damage rolls when he is making a sneak attack with it.\n\nModerate illusion; CL 7th; Craft Magic Arms and Armor, blur; Price 22,310 gp." },
  { name: "Sword of the planes", price: 22315,
    tiers: { medium: [61, 70], major: [25, 36] },
    description: "This longsword has an enhancement bonus of +1 on the Material Plane, but on any Elemental Plane its enhancement bonus increases to +2. (The +2 enhancement bonus also applies on the Material Plane when the weapon is used against elementals.) It operates as a +3 longsword on the Astral Plane or the Ethereal Plane or when used against opponents native to either of those planes. On any other plane, or against any outsider, it functions as a +4 longsword.\n\nStrong evocation; CL 15th; Craft Magic Arms and Armor, plane shift; Price 22,315 gp." },
  { name: "Oathbow", price: 25600,
    tiers: { medium: [71, 80], major: [37, 48] },
    description: "Of elven make, this white +2 composite longbow (+2 Str bonus) whispers \"Swift defeat to my enemies\" in Elven when nocked and pulled. Once per day, if the firer swears aloud to slay her target (a free action), the bow's whisper becomes the low shout \"Swift death to those who have wronged me.\" Against such a sworn enemy, the bow has a +5 enhancement bonus, and arrows launched from it deal an additional 2d6 points of damage (and ×4 on a critical hit instead of the normal ×3). However, the bow is treated as only a masterwork weapon against all foes other than the sworn enemy, and the wielder takes a -1 penalty on attack rolls with any weapon other than the oathbow. These bonuses and penalties last for seven days or until the sworn enemy is slain or destroyed by the wielder of the oathbow, whichever comes first.\n\nStrong evocation; CL 15th; Craft Magic Arms and Armor, creator must be an elf; Price 25,600 gp." },
  { name: "Sword of life stealing", price: 25715,
    tiers: { medium: [81, 90], major: [49, 62] },
    description: "This black iron +2 longsword bestows a negative level when it deals a critical hit. The sword wielder gains 1d6 temporary hit points each time a negative level is bestowed on another. These temporary hit points last for 24 hours. One day after being struck, subjects must make a DC 16 Fortitude save for each negative level or lose a character level.\n\nStrong necromancy; CL 17th; Craft Magic Arms and Armor, enervation; Price 25,715 gp." },
  { name: "Trident of fish command", price: 18650,
    tiers: { medium: [91, 100], major: [63, 70] },
    description: "The magical properties of this +1 trident with a 6-foot-long haft enable its wielder to charm up to 14 HD of aquatic animals (Will DC 16 negates, animals get a +5 bonus if currently under attack by the wielder or his allies), no two of which can be more than 30 feet apart. The wielder can use this effect up to three times per day. The wielder can communicate with the animals as if using a speak with animals spell. Animals making their saving throw are free of control, but they will not approach within 10 feet of the trident.\n\nModerate enchantment; CL 7th; Craft Magic Arms and Armor, speak with animals; Price 18,650 gp." },
  { name: "Sylvan scimitar", price: 47315,
    tiers: { major: [71, 74] },
    description: "This +3 scimitar, when used outdoors in a temperate climate, grants its wielder the use of the Cleave feat and deals an extra 1d6 points of damage.\n\nModerate evocation; CL 11th; Craft Magic Arms and Armor, divine power or creator must be a 7th-level druid; Price 47,315 gp." },
  { name: "Flame tongue", price: 20715,
    tiers: { major: [75, 80] },
    description: "This is a +1 flaming burst longsword. Its red-hot blade deals +1d6 fire damage (and +1d10 on a critical hit). On command, the wielder can also use a fireball effect (CL 12th, 10d6 fire, Reflex DC 14 half) once per day.\n\nModerate evocation; CL 12th; Craft Magic Arms and Armor, flame blade, fireball; Price 20,715 gp." },
  { name: "Mace of terror", price: 38552,
    tiers: { major: [81, 84] },
    description: "On command, this +2 heavy mace causes the wielder's clothes and appearance to transform into an illusion of darkest horror such that living creatures in a 30-foot cone become panicked as if by a fear spell (Will DC 16 partial). They take a -2 morale penalty on saving throws, and they flee from the wielder. The wielder may use this ability up to three times per day.\n\nStrong necromancy; CL 13th; Craft Magic Arms and Armor, fear; Price 38,552 gp." },
  { name: "Frost brand", price: 54475,
    tiers: { major: [85, 88] },
    description: "This +3 frost greatsword sheds light like a torch when its wielder commands. It grants its wielder fire resistance 30, and it can extinguish any nonmagical fire within 10 feet on command.\n\nStrong evocation; CL 14th; Craft Magic Arms and Armor, chill metal, ice storm, wall of ice; Price 54,475 gp." },
  { name: "Sun blade", price: 50335,
    tiers: { major: [89, 92] },
    description: "This sword is the size of a bastard sword. However, a sun blade is wielded as if it were a short sword with respect to weight and ease of use. In normal combat, the glowing golden blade of the weapon is equal to a +2 bastard sword. Against evil creatures, its enhancement bonus is +4. Against Negative Energy Plane creatures or undead creatures, the sword deals double damage (and ×3 on a critical hit instead of the usual ×2). Once per day, the wielder can swing the blade vigorously above her head while speaking a command word to create a globe of bright daylight with a 60-foot radius. All sun blades are of good alignment, and any evil creature attempting to wield one gains one negative level.\n\nModerate evocation; CL 10th; Craft Magic Arms and Armor, daylight, creator must be good; Price 50,335 gp." },
  { name: "Rapier of puncturing", price: 50320,
    tiers: { major: [93, 94] },
    description: "Three times per day, this +2 wounding rapier allows the wielder to make a touch attack with the weapon that deals 1d6 points of Constitution damage by draining blood. Creatures immune to critical hits are immune to the Constitution damage dealt by this weapon.\n\nStrong necromancy; CL 13th; Craft Magic Arms and Armor, harm; Price 50,320 gp." },
  { name: "Mace of smiting", price: 75312,
    tiers: { major: [95, 96] },
    description: "This +2 heavy mace is bane against constructs. It deals an extra 2d6 points of damage against constructs, and on a critical hit against a construct it deals triple damage and can destroy it outright.\n\nStrong evocation; CL 16th; Craft Magic Arms and Armor, holy smite,mtree/disintegrate; Price 75,312 gp." },
  { name: "Holy avenger", price: 120630,
    tiers: { major: [97, 98] },
    description: "Only a person who is good and devout (a paladin, typically) can wield a holy avenger. In the hands of any other wielder, this weapon acts as a +2 longsword. In the hands of a paladin, it is a +5 holy longsword that deals an extra 2d6 points of damage against evil creatures, grants spell resistance 30 to the wielder, and projects a magic circle against evil in a 30-foot radius.\n\nStrong abjuration [good]; CL 20th; Craft Magic Arms and Armor, creator must be good, holy smite; Price 120,630 gp." },
  { name: "Luck blade", price: 22060,
    tiers: { major: [99, 100] },
    description: "A luck blade is a +2 short sword (or other weapon) that grants its wielder a +1 luck bonus on saving throws. Most luck blades also hold 1d4 wishes. Each wish stored reduces the market price by 20,000 gp.\n\nStrong enchantment; CL 17th; Craft Magic Arms and Armor, luck, wish; Price 22,060 gp (plus 20,000 gp per wish it holds)." },
];
