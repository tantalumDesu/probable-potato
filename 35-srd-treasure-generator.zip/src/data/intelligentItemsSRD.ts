// ============================================================================
// VERBATIM transcription of d20srd.org/srd/magicItems/intelligentItems.htm
// ============================================================================

export type Tier = "minor" | "medium" | "major";

// ---------------------------------------------------------------------------
// Table: Intelligent Item Alignment
// ---------------------------------------------------------------------------
export const intelligentAlignmentTable: { min: number; max: number; label: string; note?: string }[] = [
  { min: 1, max: 5, label: "Chaotic good" },
  { min: 6, max: 15, label: "Chaotic neutral", note: "Can also be used by any character whose alignment corresponds to the nonneutral portion (i.e. by any chaotic character)." },
  { min: 16, max: 20, label: "Chaotic evil" },
  { min: 21, max: 25, label: "Neutral evil", note: "Can also be used by any character whose alignment corresponds to the nonneutral portion (i.e. by any evil character)." },
  { min: 26, max: 30, label: "Lawful evil" },
  { min: 31, max: 55, label: "Lawful good" },
  { min: 56, max: 60, label: "Lawful neutral", note: "Can also be used by any character whose alignment corresponds to the nonneutral portion (i.e. by any lawful character)." },
  { min: 61, max: 80, label: "Neutral good", note: "Can also be used by any character whose alignment corresponds to the nonneutral portion (i.e. by any good character)." },
  { min: 81, max: 100, label: "Neutral" },
];

// ---------------------------------------------------------------------------
// Table: Item Intelligence, Wisdom, Charisma, and Capabilities
// ---------------------------------------------------------------------------
export interface IntCapabilities {
  min: number;
  max: number;
  mental: string;
  communication: string;
  capabilities: string;
  senses: string;
  priceMod: number;
  // parsed conveniences
  intBonus: number;
  wisBonus: number;
  chaBonus: number;
  lesserPowers: number;
  greaterPowers: number;
  telepathy: boolean;
  readsLanguages: boolean;
  readsMagic: boolean;
  mayHaveSpecialPurpose: boolean;
}

// Footnote 1: Empathy — the possessor feels urges and sometimes emotions from
//   the item that encourage or discourage certain courses of action.
// Footnote 2: Speech — like a character, the item speaks Common plus one
//   language per point of Intelligence bonus.
// Footnote 3: also read languages.
// Footnote 4: can use either communication mode at will.
// Footnote 5: telepathically with the wielder.
// Footnote 6: the item can have a special purpose (and dedicated power) rather
//   than a greater power, if appropriate.
export const intCapabilitiesTable: IntCapabilities[] = [
  { min: 1, max: 34, mental: "Two at 12, one at 10", communication: "Empathy", capabilities: "One lesser power",
    senses: "30 ft. vision and hearing", priceMod: 1000,
    intBonus: 0, wisBonus: 0, chaBonus: 0, lesserPowers: 1, greaterPowers: 0,
    telepathy: false, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: false },
  { min: 35, max: 59, mental: "Two at 13, one at 10", communication: "Empathy", capabilities: "Two lesser powers",
    senses: "60 ft. vision and hearing", priceMod: 2000,
    intBonus: 1, wisBonus: 1, chaBonus: 1, lesserPowers: 2, greaterPowers: 0,
    telepathy: false, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: false },
  { min: 60, max: 79, mental: "Two at 14, one at 10", communication: "Speech", capabilities: "Two lesser powers",
    senses: "120 ft. vision and hearing", priceMod: 4000,
    intBonus: 2, wisBonus: 2, chaBonus: 2, lesserPowers: 2, greaterPowers: 0,
    telepathy: false, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: false },
  { min: 80, max: 91, mental: "Two at 15, one at 10", communication: "Speech", capabilities: "Three lesser powers",
    senses: "60 ft. darkvision and hearing", priceMod: 5000,
    intBonus: 2, wisBonus: 2, chaBonus: 2, lesserPowers: 3, greaterPowers: 0,
    telepathy: false, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: false },
  { min: 92, max: 97, mental: "Two at 16, one at 10", communication: "Speech, read languages", capabilities: "Three lesser powers",
    senses: "60 ft. darkvision and hearing", priceMod: 6000,
    intBonus: 3, wisBonus: 3, chaBonus: 3, lesserPowers: 3, greaterPowers: 0,
    telepathy: false, readsLanguages: true, readsMagic: false, mayHaveSpecialPurpose: false },
  { min: 98, max: 98, mental: "Two at 17, one at 10", communication: "Speech, telepathy", capabilities: "Three lesser powers and one greater power",
    senses: "120 ft. darkvision and hearing", priceMod: 9000,
    intBonus: 4, wisBonus: 4, chaBonus: 4, lesserPowers: 3, greaterPowers: 1,
    telepathy: true, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: true },
  { min: 99, max: 99, mental: "Two at 18, one at 10", communication: "Speech, telepathy", capabilities: "Three lesser powers and two greater powers",
    senses: "120 ft. darkvision, blindsense, and hearing", priceMod: 12000,
    intBonus: 4, wisBonus: 4, chaBonus: 4, lesserPowers: 3, greaterPowers: 2,
    telepathy: true, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: true },
  { min: 100, max: 100, mental: "Two at 19, one at 10", communication: "Speech, telepathy", capabilities: "Four lesser powers and three greater powers",
    senses: "120 ft. darkvision, blindsense, and hearing", priceMod: 15000,
    intBonus: 4, wisBonus: 4, chaBonus: 4, lesserPowers: 4, greaterPowers: 3,
    telepathy: true, readsLanguages: false, readsMagic: false, mayHaveSpecialPurpose: true },
];

// ---------------------------------------------------------------------------
// Intelligent Item Lesser Powers
// ---------------------------------------------------------------------------
export interface IntPower { min: number; max: number; name: string; price: number; }

export const intLesserPowers: IntPower[] = [
  { min: 1, max: 5, name: "Item can bless its allies 3/day", price: 1000 },
  { min: 6, max: 10, name: "Item can use faerie fire 3/day", price: 1100 },
  { min: 11, max: 13, name: "Item can cast minor image 1/day", price: 2200 },
  { min: 14, max: 20, name: "Item has deathwatch continually active", price: 2700 },
  { min: 21, max: 25, name: "Item can use detect magic at will", price: 3600 },
  { min: 26, max: 31, name: "Item has 10 ranks in Intimidate", price: 5000 },
  { min: 32, max: 33, name: "Item has 10 ranks in Decipher Script", price: 5000 },
  { min: 34, max: 36, name: "Item has 10 ranks in Knowledge (choose category)", price: 5000 },
  { min: 37, max: 40, name: "Item has 10 ranks in Search", price: 5000 },
  { min: 41, max: 45, name: "Item has 10 ranks in Spot", price: 5000 },
  { min: 46, max: 50, name: "Item has 10 ranks in Listen", price: 5000 },
  { min: 51, max: 54, name: "Item has 10 ranks in Spellcraft", price: 5000 },
  { min: 55, max: 60, name: "Item has 10 ranks in Sense Motive", price: 5000 },
  { min: 61, max: 66, name: "Item has 10 ranks in Bluff", price: 5000 },
  { min: 67, max: 72, name: "Item has 10 ranks in Diplomacy", price: 5000 },
  { min: 73, max: 77, name: "Item can cast major image 1/day", price: 5400 },
  { min: 78, max: 80, name: "Item can cast darkness 3/day", price: 6500 },
  { min: 81, max: 83, name: "Item can use hold person on an enemy 3/day", price: 6500 },
  { min: 84, max: 86, name: "Item can activate zone of truth 3/day", price: 6500 },
  { min: 87, max: 89, name: "Item can use daze monster 3/day", price: 6500 },
  { min: 90, max: 95, name: "Item can use locate object 3/day", price: 6500 },
  { min: 96, max: 100, name: "Item can use cure moderate wounds (2d8+3) on wielder 3/day", price: 6500 },
];

// ---------------------------------------------------------------------------
// Intelligent Item Greater Powers
// ---------------------------------------------------------------------------
// NOTE ON THE SOURCE: the SRD prints "86-91 Item can locate creature 3/day"
// followed by "91-97 Item can use fear against foes 3/day". Both bands include
// 91, which is an overlap, and the table's bands sum to 101 rather than 100.
// This is a typesetting error in the SRD. The intended reading is clearly
// 86-90, so that 81-85, 86-90, 91-97 and 98-100 partition d% 81-100 exactly;
// that is what is transcribed here.
export const intGreaterPowers: IntPower[] = [
  { min: 1, max: 6, name: "Item can detect (opposing alignment) at will", price: 7200 },
  { min: 7, max: 10, name: "Item can detect undead at will", price: 7200 },
  { min: 11, max: 13, name: "Item can cause fear in an enemy at will", price: 7200 },
  { min: 14, max: 18, name: "Item can use dimensional anchor on a foe 1/day", price: 10000 },
  { min: 19, max: 23, name: "Item can use dismissal on a foe 1/day", price: 10000 },
  { min: 24, max: 28, name: "Item can use lesser globe of invulnerability 1/day", price: 10000 },
  { min: 29, max: 33, name: "Item can use arcane eye 1/day", price: 10000 },
  { min: 34, max: 37, name: "Item has continuous detect scrying effect", price: 10000 },
  { min: 38, max: 41, name: "Item creates wall of fire in a ring with the wielder at the center 1/day", price: 10000 },
  { min: 42, max: 45, name: "Item can use quench on fires 3/day", price: 16000 },
  { min: 46, max: 50, name: "Item has status effect, usable at will", price: 11000 },
  { min: 51, max: 54, name: "Item can use gust of wind 3/day", price: 11000 },
  { min: 55, max: 59, name: "Item can use clairvoyance 3/day", price: 16000 },
  { min: 60, max: 64, name: "Item can create magic circle against (opposing alignment) at will", price: 16000 },
  { min: 65, max: 68, name: "Item can use haste on its owner 3/day", price: 16000 },
  { min: 69, max: 73, name: "Item can create daylight 3/day", price: 16000 },
  { min: 74, max: 76, name: "Item can create deeper darkness 3/day", price: 16000 },
  { min: 77, max: 80, name: "Item can use invisibility purge (30 ft. range) 3/day", price: 16000 },
  { min: 81, max: 85, name: "Item can use slow on its enemies 3/day", price: 16000 },
  { min: 86, max: 90, name: "Item can locate creature 3/day", price: 30000 },
  { min: 91, max: 97, name: "Item can use fear against foes 3/day", price: 30000 },
  { min: 98, max: 100, name: "Item can use detect thoughts at will", price: 44000 },
];

// ---------------------------------------------------------------------------
// Intelligent Item Purpose
// ---------------------------------------------------------------------------
export const intPurposeTable: { min: number; max: number; label: string; needsChoice?: "baneType" | "race" | "deity" }[] = [
  { min: 1, max: 20, label: "Defeat/slay diametrically opposed alignment" },
  { min: 21, max: 30, label: "Defeat/slay arcane spellcasters (including spellcasting monsters and those that use spell-like abilities)" },
  { min: 31, max: 40, label: "Defeat/slay divine spellcasters (including divine entities and servitors)" },
  { min: 41, max: 50, label: "Defeat/slay nonspellcasters" },
  { min: 51, max: 55, label: "Defeat/slay a particular creature type (see the bane special ability for choices)", needsChoice: "baneType" },
  { min: 56, max: 60, label: "Defeat/slay a particular race or kind of creature", needsChoice: "race" },
  { min: 61, max: 70, label: "Defend a particular race or kind of creature", needsChoice: "race" },
  { min: 71, max: 80, label: "Defeat/slay the servants of a specific deity", needsChoice: "deity" },
  { min: 81, max: 90, label: "Defend the servants and interests of a specific deity", needsChoice: "deity" },
  { min: 91, max: 95, label: "Defeat/slay all (other than the item and the wielder)" },
  { min: 96, max: 100, label: "Choose one" },
];

// ---------------------------------------------------------------------------
// Special Purpose Item Dedicated Powers
// ---------------------------------------------------------------------------
export const intDedicatedPowers: IntPower[] = [
  { min: 1, max: 6, name: "Item can use ice storm", price: 50000 },
  { min: 7, max: 12, name: "Item can use confusion", price: 50000 },
  { min: 13, max: 17, name: "Item can use phantasmal killer", price: 50000 },
  { min: 18, max: 24, name: "Item can use crushing despair", price: 50000 },
  { min: 25, max: 31, name: "Item can use dimension door on itself and wielder", price: 50000 },
  { min: 32, max: 36, name: "Item can use contagion (heightened to 4th level) as touch attack", price: 56000 },
  { min: 37, max: 43, name: "Item can use poison (heightened to 4th level) as touch attack", price: 56000 },
  { min: 44, max: 50, name: "Item can use rusting grasp as touch attack", price: 56000 },
  { min: 51, max: 56, name: "Item can cast 10d6 lightning bolt", price: 60000 },
  { min: 57, max: 62, name: "Item can cast 10d6 fireball", price: 60000 },
  { min: 63, max: 68, name: "Wielder gets +2 luck bonus on attacks, saves, and checks", price: 80000 },
  { min: 69, max: 74, name: "Item can use mass inflict light wounds", price: 81000 },
  { min: 75, max: 81, name: "Item can use song of discord", price: 81000 },
  { min: 82, max: 87, name: "Item can use prying eyes", price: 81000 },
  { min: 88, max: 92, name: "Item can cast 15d6 greater shout 3/day", price: 130000 },
  { min: 93, max: 98, name: "Item can use waves of exhaustion", price: 164000 },
  { min: 99, max: 100, name: "Item can use true resurrection on wielder, once per month", price: 200000 },
];

// ---------------------------------------------------------------------------
// Item Ego
// ---------------------------------------------------------------------------
export const intEgoRules = [
  { attribute: "Each +1 of item's enhancement bonus", ego: 1 },
  { attribute: "Each +1 of bonus for special abilities", ego: 1 },
  { attribute: "Each lesser power", ego: 1 },
  { attribute: "Each greater power", ego: 2 },
  { attribute: "Special purpose (and dedicated power)", ego: 4 },
  { attribute: "Telepathic ability", ego: 1 },
  { attribute: "Read languages ability", ego: 1 },
  { attribute: "Read magic ability", ego: 1 },
  { attribute: "Each +1 of Intelligence bonus", ego: 1 },
  { attribute: "Each +1 of Wisdom bonus", ego: 1 },
  { attribute: "Each +1 of Charisma bonus", ego: 1 },
];

// ---------------------------------------------------------------------------
// SRD prose, reproduced so the generated item is self-describing.
// ---------------------------------------------------------------------------
export const INTELLIGENT_ITEM_RULES = {
  eligibility:
    "Only permanent magic items (as opposed to single-use items or those with charges) can be intelligent. Potions, scrolls and wands, among other items, are never intelligent.",
  frequency:
    "In general, less than 1% of magic items have intelligence.",
  nature:
    "Intelligent items can be considered creatures because they have Intelligence, Wisdom and Charisma scores. Treat them as constructs. They often have the ability to illuminate their surroundings at will (as magic weapons do); many cannot see otherwise.",
  activation:
    "Unlike most magic items, intelligent items can activate their own powers without waiting for a command word from their owner. Intelligent items act during their owner's turn in the initiative order.",
  alignmentPenalty:
    "Any character whose alignment does not correspond to that of the item (except as noted on the alignment table) gains one negative level if he or she so much as picks up the item. This negative level never results in actual level loss, but it remains as long as the item is in hand and cannot be overcome in any way (including restoration spells). It is cumulative with any other penalties the item might already place on inappropriate wielders. Items with Ego scores of 20 to 29 bestow two negative levels; items with Ego of 30 or higher bestow three.",
  languages:
    "Like a character, an intelligent item speaks Common plus one additional language per point of Intelligence bonus. Choose appropriate languages, taking into account the item's origin and purposes.",
  powers:
    "All powers function at the direction of the item, although intelligent items generally follow the wishes of their owner. Activating a power or concentrating on an active one is a standard action the item takes. If the same power is rolled twice, roll again.",
  dedicatedPower:
    "A dedicated power operates only when an intelligent item is in pursuit of its special purpose. This determination is always made by the item. Unlike its other powers, an intelligent item can refuse to use its dedicated power even if the owner is dominant.",
  egoExplanation:
    "Ego is a measure of the total power and force of personality that an item possesses. Only after all aspects of the item have been generated can its Ego score be calculated. An item's Ego score helps determine whether the item or the character is dominant in their relationship.",
  conflict:
    "When a personality conflict occurs, the possessor must make a Will saving throw (DC = item's Ego). If the possessor succeeds, she is dominant. If she fails, the item is dominant. Dominance lasts for one day or until a critical situation occurs. An item with an Ego of 20 or higher always considers itself superior to any character.",
  rivalry:
    "An intelligent item is aware of the presence of any other intelligent item within 60 feet, and most try their best to mislead or distract their host so that she ignores or destroys the rival.",
};

// Choices offered by the purpose table that the SRD leaves to the user.
export const purposeRaces = [
  "dwarves", "elves", "gnomes", "halfings", "half-elves", "half-orcs", "humans",
  "goblinoids", "orcs", "kobolds", "gnolls", "lizardfolk", "giants", "dragons",
  "undead", "aberrations", "fey", "drow",
];
export const purposeDeities = [
  "a deity of war", "a deity of magic", "a deity of nature", "a deity of death",
  "a deity of the sun", "a deity of the sea", "a deity of trickery",
  "a deity of knowledge", "an evil deity of tyranny", "a good deity of healing",
  "the item's creator's forgotten deity", "a long-dead hero's patron",
];
