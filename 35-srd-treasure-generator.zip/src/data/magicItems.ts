// Magic item data - master table, armor/shield abilities, weapon abilities,
// potions, rings, rods, scrolls, staves, wands, wondrous items.
// Where full SRD descriptions are provided they are included verbatim or closely paraphrased.

// -----------------------------
// Master random magic item table
// -----------------------------
export interface MagicCategoryEntry {
  minor?: [number, number];
  medium?: [number, number];
  major?: [number, number];
  category: string;
}

export const magicItemMasterTable: MagicCategoryEntry[] = [
  { minor: [1, 4],   medium: [1, 10],  major: [1, 10],  category: "Armor/shields" },
  { minor: [5, 9],   medium: [11, 20], major: [11, 20], category: "Weapons" },
  { minor: [10, 44], medium: [21, 30], major: [21, 25], category: "Potions" },
  { minor: [45, 46], medium: [31, 40], major: [26, 35], category: "Rings" },
  { minor: undefined, medium: [41, 50], major: [36, 45], category: "Rods" },
  { minor: [47, 81], medium: [51, 65], major: [46, 55], category: "Scrolls" },
  { minor: undefined, medium: [66, 68], major: [56, 75], category: "Staffs" },
  { minor: [82, 91], medium: [69, 83], major: [76, 80], category: "Wands" },
  { minor: [92, 100], medium: [84, 100], major: [81, 100], category: "Wondrous items" },
];

// Items table per level (the d% that determines if you get items)
export interface ItemsEntry {
  min: number;
  max: number;
  kind: "none" | "mundane" | "minor" | "medium" | "major";
  quantity: string;
  label: string;
}

export const itemsTableByLevel: Record<number, ItemsEntry[]> = {
  1: [
    { min: 1, max: 71, kind: "none", quantity: "0", label: "—" },
    { min: 72, max: 95, kind: "mundane", quantity: "1", label: "1 mundane" },
    { min: 96, max: 100, kind: "minor", quantity: "1", label: "1 minor" },
  ],
  2: [
    { min: 1, max: 49, kind: "none", quantity: "0", label: "—" },
    { min: 50, max: 85, kind: "mundane", quantity: "1", label: "1 mundane" },
    { min: 86, max: 100, kind: "minor", quantity: "1", label: "1 minor" },
  ],
  3: [
    { min: 1, max: 49, kind: "none", quantity: "0", label: "—" },
    { min: 50, max: 79, kind: "mundane", quantity: "1d3", label: "1d3 mundane" },
    { min: 80, max: 100, kind: "minor", quantity: "1", label: "1 minor" },
  ],
  4: [
    { min: 1, max: 42, kind: "none", quantity: "0", label: "—" },
    { min: 43, max: 62, kind: "mundane", quantity: "1d4", label: "1d4 mundane" },
    { min: 63, max: 100, kind: "minor", quantity: "1", label: "1 minor" },
  ],
  5: [
    { min: 1, max: 57, kind: "none", quantity: "0", label: "—" },
    { min: 58, max: 67, kind: "mundane", quantity: "1d4", label: "1d4 mundane" },
    { min: 68, max: 100, kind: "minor", quantity: "1d3", label: "1d3 minor" },
  ],
  6: [
    { min: 1, max: 54, kind: "none", quantity: "0", label: "—" },
    { min: 55, max: 59, kind: "mundane", quantity: "1d4", label: "1d4 mundane" },
    { min: 60, max: 99, kind: "minor", quantity: "1d3", label: "1d3 minor" },
    { min: 100, max: 100, kind: "medium", quantity: "1", label: "1 medium" },
  ],
  7: [
    { min: 1, max: 51, kind: "none", quantity: "0", label: "—" },
    { min: 52, max: 97, kind: "minor", quantity: "1d3", label: "1d3 minor" },
    { min: 98, max: 100, kind: "medium", quantity: "1", label: "1 medium" },
  ],
  8: [
    { min: 1, max: 48, kind: "none", quantity: "0", label: "—" },
    { min: 49, max: 96, kind: "minor", quantity: "1d4", label: "1d4 minor" },
    { min: 97, max: 100, kind: "medium", quantity: "1", label: "1 medium" },
  ],
  9: [
    { min: 1, max: 43, kind: "none", quantity: "0", label: "—" },
    { min: 44, max: 91, kind: "minor", quantity: "1d4", label: "1d4 minor" },
    { min: 92, max: 100, kind: "medium", quantity: "1", label: "1 medium" },
  ],
  10: [
    { min: 1, max: 40, kind: "none", quantity: "0", label: "—" },
    { min: 41, max: 88, kind: "minor", quantity: "1d4", label: "1d4 minor" },
    { min: 89, max: 99, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 100, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  11: [
    { min: 1, max: 31, kind: "none", quantity: "0", label: "—" },
    { min: 32, max: 84, kind: "minor", quantity: "1d4", label: "1d4 minor" },
    { min: 85, max: 98, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 99, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  12: [
    { min: 1, max: 27, kind: "none", quantity: "0", label: "—" },
    { min: 28, max: 82, kind: "minor", quantity: "1d6", label: "1d6 minor" },
    { min: 83, max: 97, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 98, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  13: [
    { min: 1, max: 19, kind: "none", quantity: "0", label: "—" },
    { min: 20, max: 73, kind: "minor", quantity: "1d6", label: "1d6 minor" },
    { min: 74, max: 95, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 96, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  14: [
    { min: 1, max: 19, kind: "none", quantity: "0", label: "—" },
    { min: 20, max: 58, kind: "minor", quantity: "1d6", label: "1d6 minor" },
    { min: 59, max: 92, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 93, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  15: [
    { min: 1, max: 11, kind: "none", quantity: "0", label: "—" },
    { min: 12, max: 46, kind: "minor", quantity: "1d10", label: "1d10 minor" },
    { min: 47, max: 90, kind: "medium", quantity: "1", label: "1 medium" },
    { min: 91, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  16: [
    { min: 1, max: 40, kind: "none", quantity: "0", label: "—" },
    { min: 41, max: 46, kind: "minor", quantity: "1d10", label: "1d10 minor" },
    { min: 47, max: 90, kind: "medium", quantity: "1d3", label: "1d3 medium" },
    { min: 91, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  17: [
    { min: 1, max: 33, kind: "none", quantity: "0", label: "—" },
    { min: 34, max: 83, kind: "medium", quantity: "1d3", label: "1d3 medium" },
    { min: 84, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  18: [
    { min: 1, max: 24, kind: "none", quantity: "0", label: "—" },
    { min: 25, max: 80, kind: "medium", quantity: "1d4", label: "1d4 medium" },
    { min: 81, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  19: [
    { min: 1, max: 4, kind: "none", quantity: "0", label: "—" },
    { min: 5, max: 70, kind: "medium", quantity: "1d4", label: "1d4 medium" },
    { min: 71, max: 100, kind: "major", quantity: "1", label: "1 major" },
  ],
  20: [
    { min: 1, max: 25, kind: "none", quantity: "0", label: "—" },
    { min: 26, max: 65, kind: "medium", quantity: "1d4", label: "1d4 medium" },
    { min: 66, max: 100, kind: "major", quantity: "1d3", label: "1d3 major" },
  ],
};

// Epic (above 20) bonus major items
export const epicBonusMajorItems: Record<number, number> = {
  21: 1, 22: 2, 23: 4, 24: 6,
  25: 9, 26: 12, 27: 17,
  28: 23, 29: 31, 30: 42,
};

// -----------------------------
// Armor and Shields
// -----------------------------
// Type determination for armor/shields category
export const armorShieldTypeTable: { min: number; max: number; type: "armor" | "shield"; label: string }[] = [
  { min: 1, max: 80, type: "armor", label: "Armor" },
  { min: 81, max: 100, type: "shield", label: "Shield" },
];

// Enhancement bonus + specific armor/shield for each tier
// SRD: Minor -> +0 or +1 armor; Medium -> +1 to +3; Major -> +4 to +5
// We also roll for special abilities.
export const armorBonusTable: Record<"minor" | "medium" | "major", { min: number; max: number; bonus: number; label: string }[]> = {
  minor: [
    { min: 1, max: 60, bonus: 1, label: "+1 armor/shield" },
    { min: 61, max: 100, bonus: 0, label: "Specific armor/shield" },
  ],
  medium: [
    { min: 1, max: 20, bonus: 1, label: "+1 armor/shield" },
    { min: 21, max: 55, bonus: 2, label: "+2 armor/shield" },
    { min: 56, max: 100, bonus: 0, label: "Specific armor/shield" },
  ],
  major: [
    { min: 1, max: 10, bonus: 2, label: "+2 armor/shield" },
    { min: 11, max: 25, bonus: 3, label: "+3 armor/shield" },
    { min: 26, max: 45, bonus: 4, label: "+4 armor/shield" },
    { min: 46, max: 60, bonus: 5, label: "+5 armor/shield" },
    { min: 61, max: 100, bonus: 0, label: "Specific armor/shield" },
  ],
};

export const shieldBonusTable: Record<"minor" | "medium" | "major", { min: number; max: number; bonus: number; label: string }[]> = {
  minor: [
    { min: 1, max: 80, bonus: 1, label: "+1 shield" },
    { min: 81, max: 100, bonus: 0, label: "Specific shield" },
  ],
  medium: [
    { min: 1, max: 30, bonus: 1, label: "+1 shield" },
    { min: 31, max: 65, bonus: 2, label: "+2 shield" },
    { min: 66, max: 100, bonus: 0, label: "Specific shield" },
  ],
  major: [
    { min: 1, max: 15, bonus: 2, label: "+2 shield" },
    { min: 16, max: 30, bonus: 3, label: "+3 shield" },
    { min: 31, max: 50, bonus: 4, label: "+4 shield" },
    { min: 51, max: 60, bonus: 5, label: "+5 shield" },
    { min: 61, max: 100, bonus: 0, label: "Specific shield" },
  ],
};

// Special ability bonus equivalents for armor/shields (both tables combined per SRD)
export interface SpecialAbility {
  name: string;
  bonus: number; // +eq (0 if fixed price)
  priceGP?: number; // fixed price in gp when it does not follow bonus^2 ×1000 formula
  bonusMinor?: [number, number];
  bonusMedium?: [number, number];
  bonusMajor?: [number, number];
  aura: string;
  cl: number;
  description: string;
  restriction?: string; // e.g. shields only
  appliesTo?: "armor" | "shield" | "both";
}

export const armorSpecialAbilities: SpecialAbility[] = [
  { name: "Shadow", bonus: 1, bonusMinor: [1,17], bonusMedium: [1,11], aura: "Illusion", cl: 5,
    description: "This armor blurs the wearer, granting a +5 competence bonus on Hide checks. Even affects the wearer's equipment. Price modifier: +3,750 gp." },
  { name: "Silent moves", bonus: 1, bonusMinor: [18,33], bonusMedium: [12,22], aura: "Transmutation", cl: 5,
    description: "This armor is padded with silencing material, granting a +5 competence bonus on Move Silently checks. Price modifier: +3,750 gp." },
  { name: "Slick", bonus: 1, bonusMinor: [34,50], bonusMedium: [23,33], aura: "Conjuration", cl: 5,
    description: "Slick armor seems coated at all times with a slightly greasy oil, granting a +5 competence bonus on Escape Artist checks. Price modifier: +3,750 gp." },
  { name: "Acid resistance", bonus: 1, bonusMinor: [51,58], bonusMedium: [34,37], aura: "Abjuration", cl: 3,
    description: "This armor absorbs the first 10 points of acid damage per attack the wearer takes. Price modifier: +18,000 gp." },
  { name: "Cold resistance", bonus: 1, bonusMinor: [59,66], bonusMedium: [38,41], aura: "Abjuration", cl: 3,
    description: "This armor absorbs the first 10 points of cold damage per attack the wearer takes. Price modifier: +18,000 gp." },
  { name: "Electricity resistance", bonus: 1, bonusMinor: [67,74], bonusMedium: [42,45], aura: "Abjuration", cl: 3,
    description: "This armor absorbs the first 10 points of electricity damage per attack. Price modifier: +18,000 gp." },
  { name: "Fire resistance", bonus: 1, bonusMinor: [75,82], bonusMedium: [46,49], aura: "Abjuration", cl: 3,
    description: "This armor absorbs the first 10 points of fire damage per attack. Price modifier: +18,000 gp." },
  { name: "Sonic resistance", bonus: 1, bonusMinor: [83,90], bonusMedium: [50,53], aura: "Abjuration", cl: 3,
    description: "This armor absorbs the first 10 points of sonic damage per attack. Price modifier: +18,000 gp." },
  { name: "Ghost touch", bonus: 1, bonusMinor: [91,96], bonusMedium: [54,58], bonusMajor: [1,6], aura: "Conjuration", cl: 15,
    description: "This armor is treated as if made of force, allowing it to be worn by incorporeal creatures and granting the wearer's armor bonus against incorporeal touch attacks. Price modifier: +3 bonus equivalent." },
  { name: "Invulnerability", bonus: 1, bonusMinor: [97,100], bonusMedium: [59,64], bonusMajor: [7,12], aura: "Abjuration", cl: 15,
    description: "This armor grants the wearer damage reduction 5/magic. Price modifier: +3 bonus equivalent." },
  { name: "Fortification (light)", bonus: 1, bonusMedium: [65,73], bonusMajor: [13,20], aura: "Abjuration", cl: 13,
    description: "When a critical hit or sneak attack is scored on the wearer, there is a 25% chance the critical is negated and damage is instead rolled normally. Price modifier: +1 bonus equivalent." },
  { name: "Spell resistance (13)", bonus: 2, bonusMedium: [74,77], bonusMajor: [21,27], aura: "Abjuration", cl: 15,
    description: "This armor grants spell resistance 13. Price modifier: +2 bonus equivalent." },
  { name: "Wild", bonus: 2, bonusMedium: [78,82], bonusMajor: [28,34], aura: "Transmutation", cl: 9,
    description: "The wearer of wild armor can change into a wild shape and retain the armor's armor bonus, non-weight properties, and enhancement bonus. Price modifier: +3 bonus equivalent." },
  { name: "Death ward", bonus: 2, bonusMedium: [83,87], bonusMajor: [35,41], aura: "Necromancy", cl: 9,
    description: "This armor grants the wearer immunity to death effects and energy drain. Price modifier: +1 bonus equivalent." },
  { name: "Cold resistance (improved)", bonus: 2, bonusMedium: [88,90], bonusMajor: [42,45], aura: "Abjuration", cl: 7,
    description: "This armor absorbs the first 20 points of cold damage per attack. Price modifier: +42,000 gp." },
  { name: "Acid resistance (improved)", bonus: 2, bonusMedium: [91,92], bonusMajor: [46,48], aura: "Abjuration", cl: 7,
    description: "Absorbs the first 20 points of acid damage per attack. Price modifier: +42,000 gp." },
  { name: "Electricity resistance (improved)", bonus: 2, bonusMedium: [93,94], bonusMajor: [49,51], aura: "Abjuration", cl: 7,
    description: "Absorbs the first 20 points of electricity damage per attack. Price modifier: +42,000 gp." },
  { name: "Fire resistance (improved)", bonus: 2, bonusMedium: [95,96], bonusMajor: [52,54], aura: "Abjuration", cl: 7,
    description: "Absorbs the first 20 points of fire damage per attack. Price modifier: +42,000 gp." },
  { name: "Sonic resistance (improved)", bonus: 2, bonusMedium: [97,98], bonusMajor: [55,57], aura: "Abjuration", cl: 7,
    description: "Absorbs the first 20 points of sonic damage per attack. Price modifier: +42,000 gp." },
  { name: "Silent moves (improved)", bonus: 2, bonusMedium: [99,100], bonusMajor: [58,61], aura: "Transmutation", cl: 8,
    description: "Grants a +10 competence bonus on Move Silently checks. Price modifier: +11,250 gp." },
  { name: "Shadow (improved)", bonus: 2, bonusMajor: [62,65], aura: "Illusion", cl: 8,
    description: "Grants a +10 competence bonus on Hide checks. Price modifier: +11,250 gp." },
  { name: "Slick (improved)", bonus: 2, bonusMajor: [66,69], aura: "Conjuration", cl: 8,
    description: "Grants a +10 competence bonus on Escape Artist checks. Price modifier: +11,250 gp." },
  { name: "Fortification (moderate)", bonus: 2, bonusMajor: [70,75], aura: "Abjuration", cl: 13,
    description: "75% chance to negate critical hits and sneak attacks. Price modifier: +3 bonus equivalent." },
  { name: "Spell resistance (15)", bonus: 3, bonusMajor: [76,80], aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 15. Price modifier: +3 bonus equivalent." },
  { name: "Spell resistance (17)", bonus: 4, bonusMajor: [81,87], aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 17. Price modifier: +4 bonus equivalent." },
  { name: "Acid resistance (greater)", bonus: 3, bonusMajor: [88,89], aura: "Abjuration", cl: 11,
    description: "This armor absorbs the first 30 points of acid damage per attack. Price modifier: +66,000 gp." },
  { name: "Cold resistance (greater)", bonus: 3, bonusMajor: [90,91], aura: "Abjuration", cl: 11,
    description: "Absorbs the first 30 points of cold damage per attack. Price modifier: +66,000 gp." },
  { name: "Electricity resistance (greater)", bonus: 3, bonusMajor: [92,93], aura: "Abjuration", cl: 11,
    description: "Absorbs the first 30 points of electricity damage per attack. Price modifier: +66,000 gp." },
  { name: "Fire resistance (greater)", bonus: 3, bonusMajor: [94,95], aura: "Abjuration", cl: 11,
    description: "Absorbs the first 30 points of fire damage per attack. Price modifier: +66,000 gp." },
  { name: "Sonic resistance (greater)", bonus: 3, bonusMajor: [96,97], aura: "Abjuration", cl: 11,
    description: "Absorbs the first 30 points of sonic damage per attack. Price modifier: +66,000 gp." },
  { name: "Shadow (greater)", bonus: 3, bonusMajor: [98,98], aura: "Illusion", cl: 11,
    description: "Grants a +15 competence bonus on Hide checks. Price modifier: +18,750 gp." },
  { name: "Silent moves (greater)", bonus: 3, bonusMajor: [99,99], aura: "Transmutation", cl: 11,
    description: "Grants a +15 competence bonus on Move Silently checks. Price modifier: +18,750 gp." },
  { name: "Slick (greater)", bonus: 3, bonusMajor: [100,100], aura: "Conjuration", cl: 11,
    description: "Grants a +15 competence bonus on Escape Artist checks. Price modifier: +18,750 gp." },
  { name: "Etherealness", bonus: 3, bonusMajor: undefined, aura: "Transmutation", cl: 13,
    description: "On command, this armor allows the wearer to become ethereal (as the ethereal jaunt spell) for up to 10 rounds per day. Price modifier: +49,000 gp." },
  { name: "Fortification (heavy)", bonus: 3, bonusMajor: undefined, aura: "Abjuration", cl: 13,
    description: "100% chance to negate critical hits and sneak attacks. Price modifier: +5 bonus equivalent." },
  { name: "Spell resistance (19)", bonus: 5, bonusMajor: undefined, aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 19. Price modifier: +5 bonus equivalent." },
  { name: "Soulfire", bonus: 4, bonusMajor: undefined, aura: "Abjuration", cl: 15,
    description: "This armor bestows immunity to death effects, energy drain, and negative energy effects. Price modifier: +4 bonus equivalent." },
  { name: "Shadow (superior)", bonus: 5, bonusMajor: undefined, aura: "Illusion", cl: 15,
    description: "Grants a +20 competence bonus on Hide checks. Price modifier: +33,750 gp." },
  { name: "Silent moves (superior)", bonus: 5, bonusMajor: undefined, aura: "Transmutation", cl: 15,
    description: "Grants a +20 competence bonus on Move Silently checks. Price modifier: +33,750 gp." },
];

// Shield-only special abilities
export const shieldSpecialAbilities: SpecialAbility[] = [
  { name: "Arrow catching", bonus: 1, bonusMinor: [1,10], bonusMedium: [1,7], bonusMajor: [1,4], aura: "Abjuration", cl: 5,
    description: "This shield attracts ranged weapons; the wielder gains a +1 deflection bonus to AC against ranged weapons, but ranged attacks within 5 feet of the wielder target her instead of their intended target. Price modifier: +1 bonus equivalent." },
  { name: "Bashing", bonus: 1, bonusMinor: [11,20], bonusMedium: [8,14], bonusMajor: [5,8], aura: "Evocation", cl: 5,
    description: "A bashing shield functions as a +1 weapon when used to bash. Price modifier: +1 bonus equivalent." },
  { name: "Blinding", bonus: 1, bonusMinor: [21,27], bonusMedium: [15,22], bonusMajor: [9,13], aura: "Necromancy", cl: 7,
    description: "Twice per day, a blinding shield can flash as a bright light. All enemies within 20 feet must make a DC 15 Fortitude save or be blinded for 1d4 rounds. Price modifier: +1 bonus equivalent." },
  { name: "Fortification (light)", bonus: 1, bonusMinor: [28,37], bonusMedium: [23,31], bonusMajor: [14,20], aura: "Abjuration", cl: 13,
    description: "25% chance to negate critical hits/sneak attacks on the wielder. Price modifier: +1 bonus equivalent." },
  { name: "Arrow deflection", bonus: 2, bonusMinor: [38,40], bonusMedium: [32,39], bonusMajor: [21,27], aura: "Transmutation", cl: 5,
    description: "Once per round when you would normally be hit with a ranged weapon, you may deflect it as if you had the Deflect Arrows feat. Price modifier: +2 bonus equivalent." },
  { name: "Animated", bonus: 2, bonusMinor: [41,50], bonusMedium: [40,48], bonusMajor: [28,36], aura: "Transmutation", cl: 5,
    description: "An animated shield floats around its owner on command, defending her as if she were wielding it even when her hands are full. It can be animated for up to 4 rounds per day, used in 1-round increments. Price modifier: +2 bonus equivalent." },
  { name: "Acid resistance", bonus: 1, bonusMinor: [51,58], bonusMedium: [49,53], aura: "Abjuration", cl: 3,
    description: "Absorbs first 10 points of acid damage per attack. Price modifier: +18,000 gp." },
  { name: "Cold resistance", bonus: 1, bonusMinor: [59,66], bonusMedium: [54,58], aura: "Abjuration", cl: 3,
    description: "Absorbs first 10 points of cold damage per attack. Price modifier: +18,000 gp." },
  { name: "Electricity resistance", bonus: 1, bonusMinor: [67,74], bonusMedium: [59,63], aura: "Abjuration", cl: 3,
    description: "Absorbs first 10 points of electricity damage per attack. Price modifier: +18,000 gp." },
  { name: "Fire resistance", bonus: 1, bonusMinor: [75,82], bonusMedium: [64,68], aura: "Abjuration", cl: 3,
    description: "Absorbs first 10 points of fire damage per attack. Price modifier: +18,000 gp." },
  { name: "Sonic resistance", bonus: 1, bonusMinor: [83,90], bonusMedium: [69,73], aura: "Abjuration", cl: 3,
    description: "Absorbs first 10 points of sonic damage per attack. Price modifier: +18,000 gp." },
  { name: "Ghost touch", bonus: 1, bonusMinor: [91,96], bonusMedium: [74,79], bonusMajor: [37,44], aura: "Conjuration", cl: 15,
    description: "Counts as a force effect; armor bonus applies to incorporeal touch attacks. Price modifier: +3 bonus equivalent." },
  { name: "Fortification (moderate)", bonus: 2, bonusMinor: [97,100], bonusMedium: [80,88], bonusMajor: [45,52], aura: "Abjuration", cl: 13,
    description: "75% chance to negate critical hits/sneak attacks. Price modifier: +3 bonus equivalent." },
  { name: "Spell resistance (13)", bonus: 2, bonusMedium: [89,92], bonusMajor: [53,58], aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 13. Price modifier: +2 bonus equivalent." },
  { name: "Wild", bonus: 2, bonusMedium: [93,96], bonusMajor: [59,65], aura: "Transmutation", cl: 9,
    description: "Retains armor bonus in wild shape. Price modifier: +3 bonus equivalent." },
  { name: "Death ward", bonus: 2, bonusMedium: [97,99], bonusMajor: [66,72], aura: "Necromancy", cl: 9,
    description: "Grants immunity to death effects and energy drain. Price modifier: +1 bonus equivalent." },
  { name: "Fortification (heavy)", bonus: 3, bonusMajor: [73,80], aura: "Abjuration", cl: 13,
    description: "100% chance to negate critical hits/sneak attacks. Price modifier: +5 bonus equivalent." },
  { name: "Spell resistance (15)", bonus: 3, bonusMajor: [81,85], aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 15. Price modifier: +3 bonus equivalent." },
  { name: "Reflecting", bonus: 4, bonusMajor: [86,92], aura: "Abjuration", cl: 15,
    description: "This shield reflects spells back at their caster as if under the effect of spell turning, up to 9 levels of spells per day. Price modifier: +4 bonus equivalent." },
  { name: "Spell resistance (17)", bonus: 4, bonusMajor: [93,97], aura: "Abjuration", cl: 15,
    description: "Grants spell resistance 17. Price modifier: +4 bonus equivalent." },
  { name: "Absorption", bonus: 5, bonusMajor: [98,100], aura: "Abjuration", cl: 15,
    description: "This shield absorbs spells up to 77 levels total, as rod of absorption. It can also retributively strike once per day. Price modifier: +5 bonus equivalent." },
];

// Specific armors - a selection of the iconic ones
export interface SpecificArmor {
  name: string;
  baseArmor: string;
  bonus: number;
  price: number;
  aura: string;
  cl: number;
  description: string;
}

export const specificArmors: SpecificArmor[] = [
  { name: "Mithral shirt", baseArmor: "Chain shirt", bonus: 1, price: 1100, aura: "no aura", cl: 0,
    description: "This +1 mithral chain shirt is so light it can be worn under clothing without attracting notice. Armor check penalty 0, arcane spell failure 10%, max Dex +6. 10 lb. Price: 1,100 gp." },
  { name: "Elven chain", baseArmor: "Chainmail", bonus: 1, price: 5150, aura: "no aura", cl: 0,
    description: "Elven chain is +1 mithral chainmail made by elven smiths. It is so light it can be worn as if it were light armor, and does not violate wizards' prohibited armor restrictions. Arcane spell failure 20%, max Dex +4. 20 lb. Price: 5,150 gp." },
  { name: "Rhino hide", baseArmor: "Hide armor", bonus: 2, price: 5165, aura: "Transmutation", cl: 9,
    description: "This +2 hide armor gives the wearer the impression of being a rampaging rhino. Once per day, on a charge, the wearer deals double damage from her weapon (triple with a lance). Price: 5,165 gp." },
  { name: "Breastplate of command", baseArmor: "Breastplate", bonus: 1, price: 7200, aura: "Enchantment", cl: 15,
    description: "This +1 breastplate grants the wearer a +2 competence bonus on Charisma checks and Charisma-based skill checks and a +2 luck bonus to Leadership score. Price: 7,200 gp." },
  { name: "Full plate of speed", baseArmor: "Full plate", bonus: 1, price: 8500, aura: "Transmutation", cl: 6,
    description: "This +1 full plate allows the wearer to act as if affected by a haste spell for up to 10 rounds per day (free action to activate). Price: 8,500 gp." },
  { name: "Dwarven plate", baseArmor: "Full plate", bonus: 2, price: 16500, aura: "Abjuration", cl: 8,
    description: "This +2 full plate is forged from adamantine, granting damage reduction 3/-. It is made for dwarves; non-dwarves who wear it find it heavy and take a -2 armor check penalty. Price: 16,500 gp." },
  { name: "Banded mail of luck", baseArmor: "Banded mail", bonus: 3, price: 18900, aura: "Enchantment", cl: 8,
    description: "Once per day, if the wearer of this +3 banded mail rolls a natural 1 on a saving throw, she can reroll. Price: 18,900 gp." },
  { name: "Plate armor of the deep", baseArmor: "Full plate", bonus: 1, price: 24650, aura: "Abjuration", cl: 17,
    description: "This +1 full plate is made of magically treated coral, grants water breathing, cold resistance 20, and allows the wearer to freely speak with aquatic creatures. Price: 24,650 gp." },
  { name: "Demon armor", baseArmor: "Full plate", bonus: 4, price: 52260, aura: "Conjuration", cl: 13,
    description: "This +4 full plate is made of fiendish black iron. It allows the wearer to make claw attacks (1d10 damage), and once per day can summon a vrock that remains for 1 hour. However, the armor imparts a -4 penalty on Charisma-based interactions with good creatures. Price: 52,260 gp." },
  { name: "Celestial armor", baseArmor: "Chainmail", bonus: 3, price: 59500, aura: "Transmutation", cl: 18,
    description: "This bright silver +3 chainmail is blessed by good celestial powers. It is lightweight (15 lb.), has no arcane spell failure chance, allows flight (60 ft., average maneuverability), and grants the wearer a +5 resistance bonus on all saves against evil creatures' attacks. Price: 59,500 gp." },
  { name: "Plate mail of etherealness", baseArmor: "Full plate", bonus: 1, price: 116500, aura: "Transmutation", cl: 13,
    description: "This +1 full plate looks like normal plate armor. On command the wearer can become ethereal for up to 10 rounds per day (as ethereal jaunt). Price: 116,500 gp." },
];

// Specific shields
export interface SpecificShield {
  name: string;
  baseShield: string;
  bonus: number;
  price: number;
  aura: string;
  cl: number;
  description: string;
}

export const specificShields: SpecificShield[] = [
  { name: "Buckler of the blademaster", baseShield: "Buckler", bonus: 2, price: 3165, aura: "Transmutation", cl: 6,
    description: "This +2 buckler does not penalize the wielder's attack rolls, nor does it prevent the use of a two-handed weapon, though the shield bonus does not apply when using a weapon two-handed. Price: 3,165 gp." },
  { name: "Heavy steel shield of light fortification", baseShield: "Heavy steel shield", bonus: 1, price: 3170, aura: "Abjuration", cl: 13,
    description: "This +1 heavy steel shield has light fortification (25% chance to negate critical hits and sneak attacks). Price: 3,170 gp." },
  { name: "Mithral heavy shield", baseShield: "Heavy steel shield", bonus: 1, price: 4020, aura: "no aura", cl: 0,
    description: "This +1 mithral heavy shield weighs half as much as a normal heavy shield and has no armor check penalty. Price: 4,020 gp." },
  { name: "Spined shield", baseShield: "Heavy steel shield", bonus: 1, price: 5580, aura: "Conjuration", cl: 6,
    description: "This +1 heavy steel shield is covered in spines. The wearer can launch up to 1d4+1 spines as thrown weapons with a 30-foot range increment; each spine that hits deals 1d6 piercing damage plus the wielder's Strength modifier and then vanishes. The shield regrows spines at dawn. Price: 5,580 gp." },
  { name: "Lion's shield", baseShield: "Heavy steel shield", bonus: 2, price: 9190, aura: "Conjuration", cl: 7,
    description: "This +2 heavy steel shield is fashioned to look like a golden lion's head. Three times per day the wearer can command the shield's lion head to bite a target she just struck with a shield bash; the bite deals 2d6 piercing damage. Price: 9,190 gp." },
  { name: "Winged shield", baseShield: "Heavy steel shield", bonus: 2, price: 17250, aura: "Transmutation", cl: 5,
    description: "Once per day, this +2 heavy steel shield can be used to fly (as the fly spell, CL 5) for up to 5 minutes. Price: 17,250 gp." },
  { name: "Shield of the severed hand", baseShield: "Heavy steel shield", bonus: 2, price: 23230, aura: "Evocation", cl: 10,
    description: "This +2 heavy steel shield bears the emblem of a severed hand. Three times per day, upon command, it casts magic missile at the nearest enemy within 30 feet, firing three missiles each time. Price: 23,230 gp." },
  { name: "Absorbing shield", baseShield: "Heavy steel shield", bonus: 4, price: 50170, aura: "Abjuration", cl: 15,
    description: "This +4 heavy steel shield absorbs spells cast at the wearer (as spell resistance 27 against targeted spells; absorbed spells do not grant any benefit). The shield can absorb up to 9 spell levels per day, and the wearer can choose to turn the absorbed energy back as a retributive strike once per day. Price: 50,170 gp." },
];
