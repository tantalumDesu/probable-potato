// Rings, rods, staffs, wands, scroll generation, wondrous items - based on SRD tables.
// We include representative items with full SRD-style descriptions.

// ---------------- RINGS ----------------
export interface Ring {
  name: string;
  cl: number;
  aura: string;
  price: number;
  slot?: string; // ring
  weight?: number;
  description: string;
}

export const rings: Ring[] = [
  { name: "Ring of protection +1", cl: 5, aura: "Abjuration", price: 2000, description: "This ring grants a +1 deflection bonus to Armor Class. This bonus stacks with other deflection bonuses but not with other rings of protection. The deflection bonus increases for higher values (+2 = 8,000 gp; +3 = 18,000; +4 = 32,000; +5 = 50,000)." },
  { name: "Ring of protection +2", cl: 7, aura: "Abjuration", price: 8000, description: "This ring grants a +2 deflection bonus to Armor Class." },
  { name: "Ring of protection +3", cl: 9, aura: "Abjuration", price: 18000, description: "+3 deflection bonus to AC." },
  { name: "Ring of protection +4", cl: 12, aura: "Abjuration", price: 32000, description: "+4 deflection bonus to AC." },
  { name: "Ring of protection +5", cl: 15, aura: "Abjuration", price: 50000, description: "+5 deflection bonus to AC." },
  { name: "Ring of force shield", cl: 9, aura: "Evocation", price: 8500, description: "An iron band that, on command, creates an invisible shield that grants a +2 shield bonus to AC (as if using a heavy shield, no arcane spell failure, no check penalty). The shield can be pushed forward (command) to create a shield bash as a +1 dancing shield-like effect? No: it functions like a heavy shield. Does not stack with an actual shield." },
  { name: "Ring of friend shield", cl: 10, aura: "Abjuration", price: 30000, description: "When worn by two people (each has a paired ring), a wearer can activate the ring as an immediate action to transfer half of any damage dealt to her to the wearer of the other ring. This functions up to once per round; if the other wearer is unwilling, transfer doesn't occur." },
  { name: "Ring of invisibility", cl: 3, aura: "Illusion", price: 20000, description: "By activating this ring, the wearer becomes invisible (as the invisibility spell, ending if she attacks). The invisibility lasts up to 10 rounds per day (usable in 1-round increments)." },
  { name: "Ring of blinking", cl: 7, aura: "Transmutation", price: 27000, description: "On command, the wearer can blink (as the blink spell, 20% miss chance, can attack ethereal, can move through objects with risk) for up to 10 rounds per day, in 1-round increments." },
  { name: "Ring of counterspells", cl: 11, aura: "Universal", price: 4000, description: "This ring is imbued with one specific spell (of up to 5th level). If the wearer is targeted by that spell, the ring automatically counterspells it as if using dispel magic. After one use, it is expended until recharged by having the specific spell cast into it again. Roll d%: a random spell of 0-5 level is stored (use scroll spell list)." },
  { name: "Ring of mind shielding", cl: 3, aura: "Abjuration", price: 8000, description: "The wearer is continually immune to detect thoughts, discern lies, and any attempt to magically discern her alignment. If the wearer dies with the ring on, her soul enters the ring." },
  { name: "Ring of spell storing", cl: 5, aura: "Evocation", price: 50000, description: "This ring can store up to 5 levels of spells (0-3 level spells) cast into it by any spellcaster. The wearer can cast the stored spells as if she had them prepared, using the original caster's level. We generate a random spell set (2-5 spells summing to 5 levels of 0-3 when found)." },
  { name: "Ring of spell storing minor", cl: 5, aura: "Evocation", price: 18000, description: "As ring of spell storing but stores up to 3 levels of spells. Minor magic item version." },
  { name: "Ring of wizardry (I)", cl: 11, aura: "Universal", price: 20000, description: "This ring doubles the number of 1st-level spells a wearer can prepare per day (for arcane spellcasters only). Other wizardry rings work for higher levels (Type II doubles 2nd, 40,000 gp; Type III 3rd, 70,000 gp; Type IV 4th, 100,000 gp)." },
  { name: "Ring of feather falling", cl: 1, aura: "Transmutation", price: 2200, description: "If the wearer falls more than 5 feet, she automatically triggers feather fall as an immediate action, as the spell. This works at any time, even when stunned. The ring can also be activated on command." },
  { name: "Ring of jumping", cl: 2, aura: "Transmutation", price: 2500, description: "Grants a +5 competence bonus on Jump checks. It can also allow the wearer to cast jump on herself (already included in the continuous bonus)." },
  { name: "Ring of sustenance", cl: 5, aura: "Conjuration", price: 2500, description: "This ring continually provides its wearer with life-sustaining nourishment and fresh air (she need not eat or breathe). The wearer need only sleep 2 hours per night to be rested for spell preparation." },
  { name: "Ring of water walking", cl: 7, aura: "Transmutation", price: 15000, description: "The wearer can walk on water or other liquid as the water walk spell, continuously. Activated/deactivated on command." },
  { name: "Ring of swimming", cl: 7, aura: "Transmutation", price: 2500, description: "Grants the wearer a +5 competence bonus on Swim checks and allows her to hold her breath for up to 3 rounds longer than normal before needing air." },
  { name: "Ring of climbing", cl: 5, aura: "Transmutation", price: 2500, description: "Grants a +5 competence bonus on Climb checks. The wearer can climb as a spider (as spider climb, continuous, hands-free)." },
  { name: "Ring of animal friendship", cl: 3, aura: "Enchantment", price: 10800, description: "The wearer can cast charm animal at will (Will DC 11 negates) up to three times per day. It can maintain up to 12 HD worth of charmed animals at a time." },
  { name: "Ring of chameleon power", cl: 3, aura: "Illusion", price: 12700, description: "Grants a +10 competence bonus on Hide checks, and once per day the wearer can change the coloration of herself and her gear to match surroundings (as invisibility while stationary). The Hide bonus is continuous." },
  { name: "Ring of water breathing", cl: 5, aura: "Transmutation", price: 15000, description: "The wearer can breathe water continuously. This is otherwise identical to the water breathing spell; it doesn't make the wearer unable to breathe air." },
  { name: "Ring of freedom of movement", cl: 7, aura: "Abjuration", price: 40000, description: "The wearer is continuously under the effect of freedom of movement: she can move and attack normally even under the influence of paralysis, hold, entanglement, difficult terrain, underwater, etc. This also grants the ability to escape a grapple automatically unless pinned." },
  { name: "Ring of energy resistance minor", cl: 3, aura: "Abjuration", price: 12000, description: "Resistance 10 against a chosen energy type (acid, cold, electricity, fire, sonic). Roll for which type when found." },
  { name: "Ring of energy resistance major", cl: 7, aura: "Abjuration", price: 28000, description: "Resistance 20 against a chosen energy type." },
  { name: "Ring of energy resistance greater", cl: 11, aura: "Abjuration", price: 44000, description: "Resistance 30 against a chosen energy type." },
  { name: "Ring of ram", cl: 9, aura: "Transmutation", price: 8600, description: "The ring can be used as a move-or-standard-action force attack: the wearer makes a ranged touch attack that deals 1d6 force damage, or can charge to knock a target back (like a bull rush with +9 Strength, and it affects objects too). The ring can be used 3 times per day." },
  { name: "Ring of regeneration", cl: 15, aura: "Conjuration", price: 90000, description: "The wearer regenerates 1 hp per round, as if wearing an item of regeneration. Lost or severed body parts regenerate in 10 minutes (fingers/toes 1d6+1 minutes, hands/feet 2d4 minutes, arms/legs 3d4 minutes). The wearer does not actually regrow if killed. The ring cannot be removed by the wearer once put on; it can only be removed by the wearer's death." },
  { name: "Ring of shooting stars", cl: 12, aura: "Evocation", price: 22000, description: "This ring can be used indoors or underground to create dancing lights (at will), or light (1/day); outdoors at night it can fire 1 to 4 lightning-like sparks (1d4 sparks, ranged touch, 2d6 electricity each) or 1-2 balls of light (2d8 fire damage in 10-ft radius, Reflex DC 13 half). It also glows faintly when in shadow." },
  { name: "Ring of djinni calling", cl: 17, aura: "Conjuration", price: 43500, description: "Once per week, the wearer can summon a djinni (genie, 7 HD). If the ring is rubbed, the djinni appears and serves for up to 1 hour per use, as if by summon monster VII. The djinni will serve loyally." },
  { name: "Ring of elemental command (air)", cl: 15, aura: "Varies", price: 200000, description: "Each type (air, earth, fire, water) is a powerful ring that grants the wearer many powers and makes her an elemental ally of that type while worn. Powers: feather fall at will, resist elements 20 (cold/electricity), wind wall 1/day, air walk 1/day, chain lightning 1/week, control winds 1/week, gate (to Plane of Air) 1/week, and +1 deflection bonus to AC per 4 levels vs earth/fire creatures. (Similar rings exist for other elements with appropriate powers.)" },
  { name: "Ring of evasion", cl: 7, aura: "Transmutation", price: 25000, description: "If the wearer makes a Reflex save for half damage, she takes no damage instead (as the rogue evasion ability). If she already has evasion, it grants improved evasion." },
  { name: "Ring of spell turning", cl: 13, aura: "Abjuration", price: 98280, description: "This ring automatically reflects targeted spells back at their caster, up to 1d4+6 spell levels per day. Once per day the wearer can also rebuke a spell. A spell whose levels are not fully absorbed is partially reflected; roll randomly." },
  { name: "Ring of telekinesis", cl: 9, aura: "Transmutation", price: 75000, description: "On command, the wearer can use telekinesis as the spell (CL 9, can move 225 lbs maximum, 20 ft per round, or can hurl objects up to 25 lb at enemies for 5d4 damage, or can target a single creature/object with a violent thrust as per the spell)." },
  { name: "Ring of three wishes", cl: 20, aura: "Universal", price: 97950, description: "This ring holds three charges, each of which can produce a limited wish (more restricted than the full wish spell, but very powerful) or a wish. Once all three charges are used, the ring becomes non-magical and worthless." },
  { name: "Ring of x-ray vision", cl: 6, aura: "Divination", price: 25000, description: "On command, the wearer can see through up to 1 foot of wood/stone, 1 inch of metal (lead blocks it), as if using the x-ray vision effect. Continuous use for more than 10 rounds per day risks exhaustion (1 Con damage)." },
];

// Ring generation table (minor, medium, major ranges)
export const ringRollTable: Record<"minor"|"medium"|"major", {min:number;max:number;name:string}[]> = {
  minor: [
    { min: 1, max: 20, name: "Ring of protection +1" },
    { min: 21, max: 30, name: "Ring of feather falling" },
    { min: 31, max: 40, name: "Ring of jumping" },
    { min: 41, max: 50, name: "Ring of sustenance" },
    { min: 51, max: 60, name: "Ring of climbing" },
    { min: 61, max: 65, name: "Ring of swimming" },
    { min: 66, max: 75, name: "Ring of counterspells" },
    { min: 76, max: 80, name: "Ring of mind shielding" },
    { min: 81, max: 85, name: "Ring of animal friendship" },
    { min: 86, max: 90, name: "Ring of chameleon power" },
    { min: 91, max: 100, name: "Ring of energy resistance minor" },
  ],
  medium: [
    { min: 1, max: 15, name: "Ring of protection +2" },
    { min: 16, max: 20, name: "Ring of water walking" },
    { min: 21, max: 25, name: "Ring of force shield" },
    { min: 26, max: 30, name: "Ring of invisibility" },
    { min: 31, max: 35, name: "Ring of wizardry (I)" },
    { min: 36, max: 40, name: "Ring of evasion" },
    { min: 41, max: 45, name: "Ring of spell storing minor" },
    { min: 46, max: 50, name: "Ring of blinking" },
    { min: 51, max: 55, name: "Ring of friend shield" },
    { min: 56, max: 60, name: "Ring of mind shielding" },
    { min: 61, max: 65, name: "Ring of counterspells (higher level)" },
    { min: 66, max: 70, name: "Ring of water breathing" },
    { min: 71, max: 78, name: "Ring of freedom of movement" },
    { min: 79, max: 85, name: "Ring of energy resistance major" },
    { min: 86, max: 90, name: "Ring of ram" },
    { min: 91, max: 95, name: "Ring of shooting stars" },
    { min: 96, max: 100, name: "Ring of climbing (improved)" },
  ],
  major: [
    { min: 1, max: 10, name: "Ring of protection +3" },
    { min: 11, max: 15, name: "Ring of protection +4" },
    { min: 16, max: 20, name: "Ring of protection +5" },
    { min: 21, max: 25, name: "Ring of spell storing" },
    { min: 26, max: 28, name: "Ring of wizardry (II)" },
    { min: 29, max: 31, name: "Ring of wizardry (III)" },
    { min: 32, max: 34, name: "Ring of wizardry (IV)" },
    { min: 35, max: 40, name: "Ring of regeneration" },
    { min: 41, max: 46, name: "Ring of telekinesis" },
    { min: 47, max: 53, name: "Ring of energy resistance greater" },
    { min: 54, max: 58, name: "Ring of djinni calling" },
    { min: 59, max: 64, name: "Ring of x-ray vision" },
    { min: 65, max: 74, name: "Ring of spell turning" },
    { min: 75, max: 79, name: "Ring of elemental command" },
    { min: 80, max: 84, name: "Ring of friend shield" },
    { min: 85, max: 100, name: "Ring of three wishes" },
  ],
};

// ---------------- RODS ----------------
export interface Rod {
  name: string;
  cl: number;
  aura: string;
  price: number;
  weight?: number;
  description: string;
}

export const rods: Rod[] = [
  { name: "Rod of cancellation", cl: 17, aura: "Abjuration", price: 11000, weight: 5,
    description: "This rod can strike an object or magic item (requires a melee touch attack; if it hits, the item loses all magical properties permanently (it is suppressed). It works on artifacts with great risk (70% chance to destroy artifact, 30% chance to drain all charges and break the rod). Cursed items may require specific handling." },
  { name: "Rod of metamagic (Extend Spell)", cl: 11, aura: "Universal", price: 11000, weight: 5,
    description: "Once per day, the wielder can cast a spell of up to 3rd level (the wielder's spells, not a stored one) with the Extend Spell feat applied without any higher level slot cost. Lesser and greater rods work for spells up to 3rd level and 6th/9th respectively." },
  { name: "Rod of metamagic (Empower Spell)", cl: 11, aura: "Universal", price: 15000, weight: 5,
    description: "Works like extend spell rod but for Empower Spell. Three uses per day for lesser rods; unlimited for greater." },
  { name: "Rod of metamagic (Enlarge Spell)", cl: 11, aura: "Universal", price: 5500, weight: 5,
    description: "As extend rod but for Enlarge Spell." },
  { name: "Rod of metamagic (Maximize Spell)", cl: 17, aura: "Universal", price: 21000, weight: 5,
    description: "As other metamagic rods but for Maximize Spell, three uses per day (up to 3rd level spells for lesser)." },
  { name: "Rod of metamagic (Quicken Spell)", cl: 17, aura: "Universal", price: 43000, weight: 5,
    description: "Three uses per day, can quicken a spell of up to 3rd level. Greater rod works up to 9th level and costs 122,000 gp." },
  { name: "Rod of metamagic (Silent Spell)", cl: 11, aura: "Universal", price: 5500, weight: 5,
    description: "Three uses per day, applies Silent Spell for free to spells up to 3rd level." },
  { name: "Rod of absorbtion", cl: 15, aura: "Abjuration", price: 50000, weight: 5,
    description: "This rod absorbs spells cast directly at the wielder, up to 77 total spell levels (at 1 per spell level). As long as it has absorbed levels, it grants a +5 resistance bonus on spell resistance (yes, resistance, actually it absorbs the spell energy entirely if the wearer has no spell resistance or the SR fails). The wielder can use absorbed levels to cast her own spells, drawing from the pool rather than slots. Once per day it can unleash a retributive strike on touch (melee touch), releasing all stored levels in damage to the target (1d6 per level absorbed; wielder takes 1d4 per 5 levels released as backlash).", },
  { name: "Rod of alertness", cl: 11, aura: "Varies", price: 12500, weight: 4,
    description: "When held, this rod grants a +2 competence bonus on Spot and Listen checks and alertness. When planted firmly and commanded, it creates a 120-foot radius aura that monitors all creatures within (as alarm but mental to the wielder) and creates glowing light. It can also animate (as animated object) to attack nearby foes if planted. When wielded in combat, the head functions as +1 light mace." },
  { name: "Rod of flailing", cl: 9, aura: "Varies", price: 25000, weight: 5,
    description: "This rod's ends are flanged and extend outward to function as a +2/+2 dire flail. On command it extends chains, and three times per day it can be used to make a trip attack without provoking an attack of opportunity, with a +4 bonus. If it hits, the target is stunned for 1 round. It can also separate into two +2 heavy flails (one in each hand)." },
  { name: "Rod of lordly might", cl: 19, aura: "Varies", price: 70000, weight: 10,
    description: "This rod has many different functions: +2 light mace base; can become a +1 longsword or +3 battleaxe or +4 shortspear or a +6 quarterstaff; can climb a ladder of force steps (as climb 1/day); create a 10-foot wide platform of force; hold monsters (as hold monster 1/day); create a 30-foot wall of fire 1/day; drain magic (as rod of cancellation 1/day); deal hammer blows (double damage vs constructs, can shatter doors). It can also extend itself 5-50 feet." },
  { name: "Rod of passage", cl: 17, aura: "Varies", price: 63000, weight: 5,
    description: "This rod can be used to open doors and move through obstacles, or it can be used to pass through a wall of up to 10 ft thick (as passwall 1/day), create a dimension door 1/day, teleport 1/day, or plane shift 1/day. It has 5 charges that power these effects (passwall 1, dimension door 2, teleport 3, plane shift 5). It also functions as a +1 light mace. When found, roll d5 for charges (or d%: if higher than 5, full 5; 0-4 = 1-4)." },
  { name: "Rod of resurgence", cl: 10, aura: "Conjuration", price: 31000, weight: 5,
    description: "Three times per day, the wielder can touch a creature with this rod, which immediately removes fatigue/exhaustion and 1 point of temporary ability damage per die. The target can also immediately make another saving throw against an ongoing effect. The rod itself glows with golden light." },
  { name: "Rod of rulership", cl: 20, aura: "Enchantment", price: 70000, weight: 10,
    description: "On command, the wielder can command up to 200 HD of creatures within 300 feet (Will DC 16 negates). Creatures who fail obey your commands as if dominated for 10 rounds, believing they are your loyal subjects. This is a mind-affecting compulsion effect. It can be used once per day." },
  { name: "Rod of security", cl: 20, aura: "Conjuration", price: 61000, weight: 5,
    description: "Activation of this rod creates a shimmering portal leading to an extradimensional space where up to 150 people can live in complete comfort and safety. The space is furnished, has food and water, and a gentle climate. The rod can sustain the space for up to 200 days total (one activation = one stay, time counted in days). After use, the rod must wait 1 week before it can be activated again." },
  { name: "Rod of splendor", cl: 15, aura: "Conjuration", price: 25000, weight: 10,
    description: "The rod can create a pavilion and rich furnishings (a 30-foot square tent, 10 ft high, with silk, velvet, and food), or it can clothe the wielder in dazzling garments (Charisma +4 enhancement, for one day). It can also create up to 200 gp in gold coins (once per week, non-magical). The pavilion includes an unseen servant, 8 skeletal servants (as unseen servants), and a feast for 100. Value 25,000 gp." },
  { name: "Rod of thunder and lightning", cl: 9, aura: "Varies", price: 27000, weight: 10,
    description: "Once per round, the wielder can make a melee touch attack. If the head touches a creature, it deals 2d6 electricity damage and stuns for 1 round (Fort DC 13 negates stun). If the butt hits, it deals 2d6 sonic damage and knocks the target back as a bull rush (Strength bonus +14). The rod has 50 charges; each strike uses one. When found, roll d% for charges: d%/2 rounded down, min 1." },
  { name: "Rod of withering", cl: 13, aura: "Necromancy", price: 25000, weight: 5,
    description: "This rod functions as a +2 light mace, but on a successful touch (melee touch attack) it deals 1d4 points of Constitution damage, 1d4 Strength damage, and 1d4 Dexterity damage. The target must make a DC 20 Fortitude save or these are ability drain rather than damage. On a critical hit, the target must make a Fortitude save or have a limb wither (be permanently lost until regenerated)." },
  { name: "Rod of wonder", cl: 10, aura: "Varies", price: 12000, weight: 5,
    description: "Each time this rod is activated (standard action), it produces a random effect (roll d% on the Rod of Wonder table). Effects range from growing leaves, to summoning a rhino, to changing a target's color, to turning you to stone for a round, to a slow spell, to stinking cloud, to lightning bolt, to darkness, to making the wielder grow, to making target believe they are a chicken, etc. It is chaotic and unpredictable. 50 charges when created." },
];

// ---------------- STAFFS ----------------
export interface Staff {
  name: string;
  cl: number;
  aura: string;
  price: number;
  description: string;
}

export const staffs: Staff[] = [
  { name: "Staff of charming", cl: 7, aura: "Enchantment", price: 17500,
    description: "This smooth, twisting staff allows use of the following spells: charm person (1 charge), charm monster (2 charges). It holds up to 50 charges when created. When found, roll d% and divide by 2 (min 1)." },
  { name: "Staff of fire", cl: 10, aura: "Evocation", price: 28500,
    description: "Burned at one end. Spells: burning hands (1 charge), fireball (2 charges, CL 10, 10d6), wall of fire (3 charges). 50 charges. Can be used as a +1 quarterstaff." },
  { name: "Staff of swarming insects", cl: 11, aura: "Conjuration", price: 30000,
    description: "Gnarled, covered in crawling insects (illusory). Spells: giant vermin (1 charge), insect plague (2 charges), creeping doom (5 charges). Functions as a +2 quarterstaff. 50 charges." },
  { name: "Staff of healing", cl: 8, aura: "Conjuration", price: 41250,
    description: "A white ash wood staff topped with a bronze hand. Spells: cure serious wounds (1 charge), cure critical wounds (2 charges), heal (5 charges). It can also cast lesser restoration at the cost of 1 charge. 50 charges. It may be used by any divine caster who worships a deity of healing." },
  { name: "Staff of size alteration", cl: 9, aura: "Transmutation", price: 18500,
    description: "A staff carved with human figures. Spells: enlarge person (1 charge), reduce person (1 charge), mass enlarge person (2 charges), mass reduce person (2 charges). 50 charges." },
  { name: "Staff of frost", cl: 10, aura: "Evocation", price: 41250,
    description: "This staff is made of ice-covered birch. Spells: ice storm (2 charges), wall of ice (3 charges), cone of cold (5 charges). It can also cast ray of frost at will (0 level, no charges). 50 charges. Functions as a +2 quarterstaff." },
  { name: "Staff of illumination", cl: 8, aura: "Evocation", price: 51500,
    description: "This staff glows with soft light. Spells: dancing lights (0 charges), flare (1 charge), daylight (2 charges), sunburst (5 charges). The wielder can also trigger a burst of searing light (2 charges). 50 charges. If broken, it releases its power in a 60-ft burst dealing 6d8 damage to all in range (Reflex DC 18 half)." },
  { name: "Staff of divination", cl: 8, aura: "Divination", price: 41250,
    description: "This rune-carved oaken staff allows use of: detect secret doors (1 charge), locate object (2 charges), clairaudience/clairvoyance (2 charges), and divination (4 charges). It also grants true seeing 1/day (5 charges). 50 charges." },
  { name: "Staff of earth and stone", cl: 13, aura: "Varies", price: 85000,
    description: "Carved from granite and capped with a quartz crystal. Spells: magic stone (1 charge), stone shape (2 charges), stoneskin (2 charges), spike stones (3 charges), passwall (3 charges), wall of stone (4 charges), move earth (5 charges), earthquake (10 charges). 50 charges. +2 quarterstaff." },
  { name: "Staff of the woodlands", cl: 13, aura: "Varies", price: 31000,
    description: "A living wooden staff of birch. Spells: barkskin (1 charge), speak with plants (1 charge), wall of thorns (2 charges), animate plants (3 charges), command plants (4 charges), shambler (5 charges). It also allows pass without trace at will. 50 charges. Can be used only by druids/rangers." },
  { name: "Staff of life", cl: 13, aura: "Conjuration", price: 109000,
    description: "A healthy apple-wood staff. Spells: raise dead (5 charges), heal (5 charges). The wielder can also cure light wounds at will (no charges). It grants a +1 competence bonus on Heal checks. 50 charges. Requires good alignment to use." },
  { name: "Staff of passage", cl: 17, aura: "Varies", price: 140000,
    description: "This staff is made of a black metal. Spells: passwall (1 charge), dimension door (2 charges), greater teleport (5 charges), phase door (7 charges), astral projection (10 charges). 50 charges. It is highly prized by wizards." },
  { name: "Staff of power", cl: 15, aura: "Varies", price: 235000,
    description: "This iron-shod staff is highly dangerous. It functions as a +2 quarterstaff and has a wide range of powers: continual flame (0 charges), magic missile (1 charge), ray of enfeeblement (1 charge), levitation (1 charge), lightning bolt (2 charges), fireball (2 charges), globe of invulnerability (3 charges), cone of cold (4 charges), hold monster (4 charges), wall of force (5 charges). It can also be broken in desperation to release a retributive strike (a massive explosion; 50% chance you travel to another plane safely, otherwise you take the damage too)." },
  { name: "Staff of the python", cl: 8, aura: "Transmutation", price: 13000,
    description: "A wooden staff carved like a snake. It can transform into a Large constrictor snake (as if summoned) that obeys commands for 10 minutes (1 charge), or it can become a +1 quarterstaff (no charges). 50 charges. If slain in snake form, the staff returns to staff form and cannot become a snake again for 48 hours." },
  { name: "Staff of thunder and lightning", cl: 13, aura: "Varies", price: 43000,
    description: "An ash staff bound in copper. The user can call down lightning bolts (2 charges, as lightning bolt 10d6) or thunder claps (1 charge, as shout). 50 charges." },
  { name: "Necromantic staff", cl: 10, aura: "Necromancy", price: 37250,
    description: "A black iron staff capped with a skull. Spells: cause fear (1 charge), ghoul touch (2 charges), halt undead (2 charges), enervation (3 charges), waves of fatigue (3 charges), circle of death (5 charges). 50 charges." },
];

// ---------------- WANDS ----------------
// Wands hold spells of up to 4th level. They contain a single spell at a fixed caster level.
// We generate by level: minor = 0-2 level spells, medium = 1-3, major = 2-4.
export interface WandSpell {
  spell: string;
  level: number;
  cl: number;
  price: number;
}

export const wandSpellTable: Record<"minor"|"medium"|"major", {min:number;max:number;spell:string;level:number;cl:number}[]> = {
  minor: [
    // Level 0
    { min: 1, max: 4, spell: "Acid splash", level: 0, cl: 1 },
    { min: 5, max: 8, spell: "Daze", level: 0, cl: 1 },
    { min: 9, max: 12, spell: "Detect magic", level: 0, cl: 1 },
    { min: 13, max: 16, spell: "Disrupt undead", level: 0, cl: 1 },
    { min: 17, max: 20, spell: "Flare", level: 0, cl: 1 },
    { min: 21, max: 24, spell: "Ghost sound", level: 0, cl: 1 },
    { min: 25, max: 28, spell: "Light", level: 0, cl: 1 },
    { min: 29, max: 32, spell: "Mage hand", level: 0, cl: 1 },
    { min: 33, max: 36, spell: "Open/close", level: 0, cl: 1 },
    { min: 37, max: 40, spell: "Ray of frost", level: 0, cl: 1 },
    { min: 41, max: 44, spell: "Read magic", level: 0, cl: 1 },
    { min: 45, max: 48, spell: "Resistance", level: 0, cl: 1 },
    // Level 1
    { min: 49, max: 52, spell: "Burning hands", level: 1, cl: 1 },
    { min: 53, max: 56, spell: "Charm person", level: 1, cl: 1 },
    { min: 57, max: 60, spell: "Color spray", level: 1, cl: 1 },
    { min: 61, max: 64, spell: "Cure light wounds", level: 1, cl: 1 },
    { min: 65, max: 68, spell: "Detect secret doors", level: 1, cl: 1 },
    { min: 69, max: 72, spell: "Entangle", level: 1, cl: 1 },
    { min: 73, max: 76, spell: "Expeditious retreat", level: 1, cl: 1 },
    { min: 77, max: 80, spell: "Faerie fire", level: 1, cl: 1 },
    { min: 81, max: 84, spell: "Grease", level: 1, cl: 1 },
    { min: 85, max: 88, spell: "Hold portal", level: 1, cl: 1 },
    { min: 89, max: 92, spell: "Identify", level: 1, cl: 1 },
    { min: 93, max: 96, spell: "Jump", level: 1, cl: 1 },
    { min: 97, max: 100, spell: "Longstrider", level: 1, cl: 1 },
  ],
  medium: [
    // Level 1
    { min: 1, max: 3, spell: "Mage armor", level: 1, cl: 1 },
    { min: 4, max: 6, spell: "Magic missile", level: 1, cl: 1 },
    { min: 7, max: 9, spell: "Protection from evil", level: 1, cl: 1 },
    { min: 10, max: 12, spell: "Shield", level: 1, cl: 1 },
    { min: 13, max: 15, spell: "Shield of faith", level: 1, cl: 1 },
    { min: 16, max: 18, spell: "Shocking grasp", level: 1, cl: 1 },
    { min: 19, max: 21, spell: "Sleep", level: 1, cl: 1 },
    { min: 22, max: 24, spell: "Summon monster I", level: 1, cl: 1 },
    { min: 25, max: 27, spell: "True strike", level: 1, cl: 1 },
    { min: 28, max: 30, spell: "Bull's strength", level: 2, cl: 3 },
    { min: 31, max: 33, spell: "Cat's grace", level: 2, cl: 3 },
    { min: 34, max: 36, spell: "Bear's endurance", level: 2, cl: 3 },
    { min: 37, max: 39, spell: "Darkness", level: 2, cl: 3 },
    { min: 40, max: 42, spell: "Detect thoughts", level: 2, cl: 3 },
    { min: 43, max: 45, spell: "Eagle's splendor", level: 2, cl: 3 },
    { min: 46, max: 48, spell: "False life", level: 2, cl: 3 },
    { min: 49, max: 51, spell: "Fox's cunning", level: 2, cl: 3 },
    { min: 52, max: 54, spell: "Glitterdust", level: 2, cl: 3 },
    { min: 55, max: 57, spell: "Hold person", level: 2, cl: 3 },
    { min: 58, max: 60, spell: "Invisibility", level: 2, cl: 3 },
    { min: 61, max: 63, spell: "Knock", level: 2, cl: 3 },
    { min: 64, max: 66, spell: "Levitate", level: 2, cl: 3 },
    { min: 67, max: 69, spell: "Mirror image", level: 2, cl: 3 },
    { min: 70, max: 72, spell: "Owl's wisdom", level: 2, cl: 3 },
    { min: 73, max: 75, spell: "Resist energy", level: 2, cl: 3 },
    { min: 76, max: 78, spell: "Scorching ray", level: 2, cl: 3 },
    { min: 79, max: 81, spell: "See invisibility", level: 2, cl: 3 },
    { min: 82, max: 84, spell: "Silence", level: 2, cl: 3 },
    { min: 85, max: 87, spell: "Spider climb", level: 2, cl: 3 },
    { min: 88, max: 90, spell: "Summon monster II", level: 2, cl: 3 },
    { min: 91, max: 93, spell: "Summon swarm", level: 2, cl: 3 },
    { min: 94, max: 96, spell: "Web", level: 2, cl: 3 },
    { min: 97, max: 100, spell: "Magic mouth", level: 2, cl: 3 },
  ],
  major: [
    // Level 2
    { min: 1, max: 3, spell: "Blur", level: 2, cl: 3 },
    { min: 4, max: 6, spell: "Barkskin", level: 2, cl: 3 },
    { min: 7, max: 9, spell: "Melf's acid arrow", level: 2, cl: 3 },
    // Level 3
    { min: 10, max: 12, spell: "Cure serious wounds", level: 3, cl: 5 },
    { min: 13, max: 15, spell: "Dispel magic", level: 3, cl: 5 },
    { min: 16, max: 18, spell: "Displacement", level: 3, cl: 5 },
    { min: 19, max: 21, spell: "Fireball", level: 3, cl: 5 },
    { min: 22, max: 24, spell: "Flame arrow", level: 3, cl: 5 },
    { min: 25, max: 27, spell: "Fly", level: 3, cl: 5 },
    { min: 28, max: 30, spell: "Gaseous form", level: 3, cl: 5 },
    { min: 31, max: 33, spell: "Haste", level: 3, cl: 5 },
    { min: 34, max: 36, spell: "Hold person (mass)", level: 3, cl: 5 },
    { min: 37, max: 39, spell: "Invisibility sphere", level: 3, cl: 5 },
    { min: 40, max: 42, spell: "Keen edge", level: 3, cl: 5 },
    { min: 43, max: 45, spell: "Lightning bolt", level: 3, cl: 5 },
    { min: 46, max: 48, spell: "Magic circle against evil", level: 3, cl: 5 },
    { min: 49, max: 51, spell: "Magic weapon (greater)", level: 3, cl: 5 },
    { min: 52, max: 54, spell: "Slow", level: 3, cl: 5 },
    { min: 55, max: 57, spell: "Stinking cloud", level: 3, cl: 5 },
    { min: 58, max: 60, spell: "Summon monster III", level: 3, cl: 5 },
    { min: 61, max: 63, spell: "Vampiric touch", level: 3, cl: 5 },
    { min: 64, max: 66, spell: "Water breathing", level: 3, cl: 5 },
    // Level 4
    { min: 67, max: 69, spell: "Bestow curse", level: 4, cl: 7 },
    { min: 70, max: 72, spell: "Charm monster", level: 4, cl: 7 },
    { min: 73, max: 75, spell: "Contagion", level: 4, cl: 7 },
    { min: 76, max: 78, spell: "Cure critical wounds", level: 4, cl: 7 },
    { min: 79, max: 81, spell: "Dimension door", level: 4, cl: 7 },
    { min: 82, max: 84, spell: "Enervation", level: 4, cl: 7 },
    { min: 85, max: 87, spell: "Fear", level: 4, cl: 7 },
    { min: 88, max: 90, spell: "Ice storm", level: 4, cl: 7 },
    { min: 91, max: 93, spell: "Minor globe of invulnerability", level: 4, cl: 7 },
    { min: 94, max: 96, spell: "Polymorph", level: 4, cl: 7 },
    { min: 97, max: 99, spell: "Stoneskin", level: 4, cl: 7 },
    { min: 100, max: 100, spell: "Wall of fire", level: 4, cl: 7 },
  ],
};

// ---------------- SCROLLS ----------------
// Scroll generation: type (arcane/divine), level, then spell list.
// Minor: 0-3, Medium: 0-6, Major: 0-9.
export const scrollTypeTable: {min:number;max:number;type:"arcane"|"divine"}[] = [
  { min: 1, max: 70, type: "arcane" },
  { min: 71, max: 100, type: "divine" },
];

// Scroll level per tier.
interface ScrollLevelEntry { min: number; max: number; level: number; spells: number; }
export const scrollLevelTable: Record<"minor"|"medium"|"major", ScrollLevelEntry[]> = {
  minor: [
    { min: 1, max: 5, level: 0, spells: 1 },
    { min: 6, max: 10, level: 0, spells: 2 },
    { min: 11, max: 20, level: 0, spells: 3 },
    { min: 21, max: 40, level: 1, spells: 1 },
    { min: 41, max: 60, level: 1, spells: 2 },
    { min: 61, max: 75, level: 2, spells: 1 },
    { min: 76, max: 100, level: 2, spells: 2 },
  ],
  medium: [
    { min: 1, max: 5, level: 0, spells: 3 },
    { min: 6, max: 20, level: 1, spells: 3 },
    { min: 21, max: 45, level: 2, spells: 3 },
    { min: 46, max: 70, level: 3, spells: 2 },
    { min: 71, max: 85, level: 3, spells: 3 },
    { min: 86, max: 95, level: 4, spells: 2 },
    { min: 96, max: 100, level: 5, spells: 1 },
  ],
  major: [
    { min: 1, max: 5, level: 2, spells: 3 },
    { min: 6, max: 15, level: 3, spells: 3 },
    { min: 16, max: 30, level: 4, spells: 2 },
    { min: 31, max: 40, level: 5, spells: 1 },
    { min: 41, max: 50, level: 5, spells: 2 },
    { min: 51, max: 60, level: 6, spells: 1 },
    { min: 61, max: 70, level: 6, spells: 2 },
    { min: 71, max: 80, level: 7, spells: 1 },
    { min: 81, max: 87, level: 7, spells: 2 },
    { min: 88, max: 92, level: 8, spells: 1 },
    { min: 93, max: 96, level: 8, spells: 2 },
    { min: 97, max: 99, level: 9, spells: 1 },
    { min: 100, max: 100, level: 9, spells: 2 },
  ],
};

// Spell lists by class for random selection
export const arcaneSpellList: Record<number, string[]> = {
  0: ["Acid splash","Arcane mark","Dancing lights","Daze","Detect magic","Detect poison","Disrupt undead","Flare","Ghost sound","Light","Mage hand","Mending","Open/close","Prestidigitation","Ray of frost","Read magic","Resistance"],
  1: ["Alarm","Burning hands","Charm person","Color spray","Comprehend languages","Detect secret doors","Disguise self","Endure elements","Enlarge person","Erase","Expeditious retreat","False life","Feather fall","Floating disk","Grease","Hold portal","Identify","Jump","Mage armor","Magic missile","Magic weapon","Mount","Nystul's magic aura","Obscuring mist","Protection from chaos","Protection from evil","Protection from good","Protection from law","Ray of enfeeblement","Shield","Shocking grasp","Silent image","Sleep","Summon monster I","Tenser's floating disk","True strike","Unseen servant","Ventriloquism"],
  2: ["Acid arrow","Alter self","Arcane lock","Bear's endurance","Blindness/deafness","Blur","Bull's strength","Cat's grace","Cloud of knives","Continual flame","Darkness","Darkvision","Delay poison","Detect thoughts","Displacement? No that's 3","Eagle's splendor","Flaming sphere","Fog cloud","Fox's cunning","Ghoul touch","Glitterdust","Gust of wind","Hideous laughter","Hypnotic pattern","Invisibility","Knock","Levitate","Locate object","Melf's acid arrow","Mirror image","Misdirection","Obscure object","Owl's wisdom","Phantom trap","Resist energy","Rope trick","Scare","Scorching ray","See invisibility","Shatter","Silence","Sound burst","Spectral hand","Spider climb","Suggestion","Summon monster II","Summon swarm","Touch of idiocy","Web","Whispering wind","Arcane lock"],
  3: ["Blink","Clairaudience/clairvoyance","Daylight","Deep slumber","Dispel magic","Displacement","Fireball","Flame arrow","Fly","Gaseous form","Gentle repose","Halt undead","Haste","Heroism","Hold person","Illusory script","Invisibility sphere","Keen edge","Leomund's tiny hut","Lightning bolt","Magic circle against chaos/evil/good/law","Major image","Nondetection","Phantom steed","Protection from energy","Rage","Ray of exhaustion","Sleet storm","Slow","Shrink item","Stinking cloud","Stone shape","Summon monster III","Tongues","Vampiric touch","Water breathing","Wind wall"],
  4: ["Arcane eye","Bestow curse","Black tentacles","Charm monster","Confusion","Contagion","Crushing despair","Dimension door","Dimensional anchor","Enervation","Fear","Fire shield","Ice storm","Illusory wall","Invisibility (greater)","Minor creation","Phantasmal killer","Polymorph","Rainbow pattern","Remove curse","Resilient sphere","Scrying","Shout","Solid fog","Stoneskin","Summon monster IV","Wall of fire","Wall of ice"],
  5: ["Animal growth","Baleful polymorph","Blightsending? No, cloudkill","Cone of cold","Contact other plane","Dismissal","Dominate person","Dream","False vision","Feeblemind","Hold monster","Interposing hand","Invisibility (mass)","Leomund's secret chest","Lesser planar binding","Magic jar","Mirage arcana","Mordenkainen's faithful hound","Mordenkainen's private sanctum","Nightmare","Overland flight","Passwall","Permanent image","Persistent image","Polymorph (mass)","Prying eyes","Rary's telepathic bond","Seeming","Sending","Shadow evocation","Summon monster V","Telekinesis","Teleport","Transmute mud to rock","Transmute rock to mud","Wall of force","Waves of fatigue"],
  6: ["Acid fog","Analyze dweomer","Antimagic field","Chain lightning","Circle of death","Contingency","Control water","Control winds","Disintegrate","Eyebite","Flesh to stone","Freezing sphere","Globe of invulnerability","Greater dispel magic","Guards and wards","Heroes' feast","Legend lore","Mislead","Mordenkainen's lucubration","Move earth","Otiluke's freezing sphere","Overwhelm? Planar binding (lesser)","Repulsion","Shadow walk","Stone to flesh","Suggestion (mass)","Summon monster VI","Symbol of fear","True seeing","Undeath to death","Veil"],
  7: ["Arcane sword","Banishment","Delayed blast fireball","Drawmij's instant summons","Ethereal jaunt","Finger of death","Forcecage","Grasping hand","Insanity","Limited wish","Mage's magnificent mansion","Mage's sword","Mass hold person","Phase door? No that's 9","Plane shift","Power word blind","Prismatic spray","Project image","Reverse gravity","Scrying (greater)","Sequester","Simulacrum","Spell turning","Statue","Summon monster VII","Teleport (greater)","Vision","Waves of exhaustion"],
  8: ["Antipathy","Binding","Charm monster (mass)","Clone","Create greater undead","Demand","Dimensional lock","Discern location","Horrid wilting","Incendiary cloud","Iron body","Irresistible dance","Maze","Mind blank","Moment of prescience","Otiluke's telekinetic sphere","Otto's irresistible dance","Polar ray","Polymorph any object","Power word stun","Prismatic wall","Protection from spells","Scintillating pattern","Screen","Shadow evocation (greater)","Shout (greater)","Summon monster VIII","Sunburst","Symbol of death","Symbol of insanity","Sympathy","Temporal stasis","Trap the soul"],
  9: ["Astral projection","Dominate monster","Energy drain","Etherealness","Foresight","Freedom","Gate","Imprisonment","Mordenkainen's disjunction","Power word kill","Prismatic sphere","Shapechange","Soul bind","Summon monster IX","Teleportation circle","Time stop","True resurrection? No that's cleric","Weird","Wish","Wail of the banshee"],
};

export const divineSpellList: Record<number, string[]> = {
  0: ["Create water","Cure minor wounds","Detect magic","Detect poison","Flare","Guidance","Inflict minor wounds","Know direction","Light","Mending","Purify food and drink","Read magic","Resistance","Virtue"],
  1: ["Bane","Bless","Bless water","Bane water","Cause fear","Command","Comprehend languages","Cure light wounds","Curse water","Deathwatch","Detect chaos/evil/good/law","Detect undead","Divine favor","Doom","Endure elements","Entangle","Entropic shield","Hide from animals/undead","Inflict light wounds","Invisibility to undead","Longstrider","Magic fang","Magic stone","Magic weapon","Obscuring mist","Pass without trace","Protection from chaos/evil/good/law","Produce flame","Remove fear","Sanctuary","Shield of faith","Shillelagh","Summon monster I","Summon nature's ally I"],
  2: ["Aid","Align weapon","Augury","Barkskin","Bear's endurance","Bull's strength","Calm emotions","Cat's grace","Consecrate","Cure moderate wounds","Darkness","Darkvision","Delay poison","Desecrate","Eagle's splendor","Enthrall","Find traps","Flame blade","Fog cloud","Gentle repose","Gust of wind","Hold animal","Hold person","Inflict moderate wounds","Make whole","Owl's wisdom","Remove paralysis","Repel vermin","Resist energy","Restoration (lesser)","Shatter","Shield other","Silence","Sound burst","Spider climb","Spiritual weapon","Status","Summon monster II","Summon nature's ally II","Undetectable alignment","Warp wood","Wood shape","Zone of truth"],
  3: ["Animate dead","Bestow curse","Blindness/deafness","Call lightning","Contagion","Create food and water","Cure serious wounds","Daylight","Deeper darkness","Dispel magic","Dominate animal","Glyph of warding","Helping hand","Inflict serious wounds","Invisibility purge","Locate object","Magic circle against chaos/evil/good/law","Magic vestment","Meld into stone","Neutralize poison","Obscure object","Prayer","Protection from energy","Quench","Remove blindness/deafness","Remove curse","Remove disease","Searing light","Sleet storm","Speak with dead","Speak with plants","Spike growth","Stone shape","Summon monster III","Summon nature's ally III","Tongues","Water breathing","Water walk","Wind wall"],
  4: ["Air walk","Antiplant shell","Blight","Break enchantment","Command plants","Control water","Cure critical wounds","Death ward","Dimensional anchor","Discern lies","Dismissal","Divination","Divine power","Elemental swarm? No that's 9","Flame strike","Freedom of movement","Giant vermin","Holy sword? No that's 4 paladin","Inflict critical wounds","Imbue with spell ability","Greater magic fang","Greater magic weapon","Ice storm","Legend lore","Magic weapon greater? Already there","Nondetection","Planar ally (lesser)","Poison","Polymorph","Repel vermin greater? No there's giant vermin","Reincarnate","Restoration","Righteous might","Sending","Sending? Yes","Slay living","Spell immunity","Spike stones","Summon monster IV","Summon nature's ally IV","Tongues"]
};

// ---------------- WONDROUS ITEMS ----------------
export interface WondrousItem {
  name: string;
  cl: number;
  aura: string;
  price: number;
  slot: string;
  weight?: number;
  description: string;
}

export const wondrousItems: WondrousItem[] = [
  { name: "Amulet of natural armor +1", cl: 5, aura: "Transmutation", price: 2000, slot: "neck",
    description: "Grants a +1 natural armor bonus to AC. Higher bonuses: +2 = 8,000 gp, +3 = 18,000 gp, +4 = 32,000 gp, +5 = 50,000 gp." },
  { name: "Amulet of natural armor +2", cl: 8, aura: "Transmutation", price: 8000, slot: "neck",
    description: "+2 natural armor bonus to AC." },
  { name: "Amulet of natural armor +3", cl: 11, aura: "Transmutation", price: 18000, slot: "neck",
    description: "+3 natural armor bonus to AC." },
  { name: "Amulet of natural armor +4", cl: 14, aura: "Transmutation", price: 32000, slot: "neck",
    description: "+4 natural armor bonus to AC." },
  { name: "Amulet of natural armor +5", cl: 17, aura: "Transmutation", price: 50000, slot: "neck",
    description: "+5 natural armor bonus to AC." },
  { name: "Amulet of health +2", cl: 3, aura: "Transmutation", price: 4000, slot: "neck",
    description: "Grants +2 enhancement bonus to Constitution. +2 = 4,000; +4 = 16,000; +6 = 36,000." },
  { name: "Amulet of health +4", cl: 7, aura: "Transmutation", price: 16000, slot: "neck", description: "+4 enhancement to Con." },
  { name: "Amulet of health +6", cl: 11, aura: "Transmutation", price: 36000, slot: "neck", description: "+6 enhancement to Con." },
  { name: "Amulet of proof against detection and location", cl: 8, aura: "Abjuration", price: 35000, slot: "neck",
    description: "Grants the wearer continuous nondetection, shielding her from divination and scrying (DC 19 caster level check to pierce). Also blocks detect evil/good, locate creature, etc." },
  { name: "Amulet of mighty fists", cl: 5, aura: "Transmutation", price: 6000, slot: "neck",
    description: "Adds +1 enhancement bonus on attack and damage rolls with unarmed strikes and natural weapons. +2 = 24,000, +3 = 54,000 etc." },
  { name: "Boots of striding and springing", cl: 3, aura: "Transmutation", price: 5500, slot: "feet", weight: 1,
    description: "The wearer's base land speed is increased by 10 feet (enhancement bonus), and she gains a +5 competence bonus on Jump checks." },
  { name: "Boots of speed", cl: 10, aura: "Transmutation", price: 48000, slot: "feet", weight: 1,
    description: "As a free action, the wearer can click her heels to gain the effects of haste for up to 10 rounds per day (in 1-round increments). Haste grants +30 ft speed, +1 attack, +1 dodge AC/Reflex, extra attack on full attack." },
  { name: "Boots of teleportation", cl: 9, aura: "Conjuration", price: 49000, slot: "feet", weight: 3,
    description: "Up to three times per day, the wearer can teleport as the greater teleport spell (unlimited range, no chance of mishap). She can carry objects and other touched creatures as per teleport." },
  { name: "Boots of levitation", cl: 3, aura: "Transmutation", price: 7500, slot: "feet", weight: 1,
    description: "On command, the wearer can levitate (as levitate spell, CL 3), moving up or down at will. The effect lasts 30 minutes per use, unlimited uses but you must concentrate to move." },
  { name: "Boots of elvenkind", cl: 4, aura: "Transmutation", price: 2500, slot: "feet", weight: 1,
    description: "These soft boots grant a +5 competence bonus on Move Silently checks." },
  { name: "Bracers of armor +1", cl: 5, aura: "Conjuration", price: 1000, slot: "arms", weight: 1,
    description: "These wrist bands grant an armor bonus to AC. +1 = 1,000 gp; +2 = 4,000; +3 = 9,000; +4 = 16,000; +5 = 25,000; +6 = 36,000; +7 = 49,000; +8 = 64,000." },
  { name: "Bracers of armor +2", cl: 7, aura: "Conjuration", price: 4000, slot: "arms", description: "+2 armor bonus." },
  { name: "Bracers of armor +3", cl: 9, aura: "Conjuration", price: 9000, slot: "arms", description: "+3 armor bonus." },
  { name: "Bracers of armor +4", cl: 11, aura: "Conjuration", price: 16000, slot: "arms", description: "+4 armor bonus." },
  { name: "Bracers of armor +5", cl: 13, aura: "Conjuration", price: 25000, slot: "arms", description: "+5 armor bonus." },
  { name: "Bracers of archery, lesser", cl: 3, aura: "Transmutation", price: 5000, slot: "arms", weight: 1,
    description: "These bracers grant a +2 competence bonus on attack rolls made with any type of bow (shortbow, longbow, composite)." },
  { name: "Bracers of archery, greater", cl: 8, aura: "Transmutation", price: 25000, slot: "arms", weight: 1,
    description: "Grant +2 competence bonus on all ranged attacks with bows, and allow the wearer to use the Manyshot feat even if she doesn't meet the prerequisites. Also grants the Rapid Shot feat for free." },
  { name: "Cloak of resistance +1", cl: 5, aura: "Abjuration", price: 1000, slot: "shoulders", weight: 1,
    description: "Grants +1 resistance bonus on all saving throws. +2 = 4,000; +3 = 9,000; +4 = 16,000; +5 = 25,000." },
  { name: "Cloak of resistance +2", cl: 7, aura: "Abjuration", price: 4000, slot: "shoulders", description: "+2 resistance bonus on saves." },
  { name: "Cloak of resistance +3", cl: 9, aura: "Abjuration", price: 9000, slot: "shoulders", description: "+3 resistance bonus on saves." },
  { name: "Cloak of resistance +4", cl: 11, aura: "Abjuration", price: 16000, slot: "shoulders", description: "+4 resistance bonus on saves." },
  { name: "Cloak of resistance +5", cl: 13, aura: "Abjuration", price: 25000, slot: "shoulders", description: "+5 resistance bonus on saves." },
  { name: "Cloak of charisma +2", cl: 3, aura: "Transmutation", price: 4000, slot: "shoulders", weight: 1,
    description: "Grants +2 enhancement to Charisma. +4 = 16,000; +6 = 36,000." },
  { name: "Cloak of charisma +4", cl: 7, aura: "Transmutation", price: 16000, slot: "shoulders", description: "+4 enhancement to Cha." },
  { name: "Cloak of charisma +6", cl: 11, aura: "Transmutation", price: 36000, slot: "shoulders", description: "+6 enhancement to Cha." },
  { name: "Cloak of displacement, minor", cl: 7, aura: "Illusion", price: 24000, slot: "shoulders", weight: 1,
    description: "The wearer appears to be 2 feet from her actual location, granting a 20% miss chance (as the blur spell)." },
  { name: "Cloak of displacement, major", cl: 11, aura: "Illusion", price: 50000, slot: "shoulders", weight: 1,
    description: "Grants a 50% miss chance (as displacement spell).", },
  { name: "Cloak of elvenkind", cl: 3, aura: "Transmutation", price: 2500, slot: "shoulders", weight: 1,
    description: "This gray cloak grants the wearer a +5 competence bonus on Hide checks. Its color shifts slightly with the surroundings." },
  { name: "Cloak of the manta ray", cl: 9, aura: "Transmutation", price: 32000, slot: "shoulders", weight: 1,
    description: "Worn, it gives the wearer a swim speed of 60 ft, +8 natural armor in water, and allows her to breathe water (gills form). It also can be used to fly at a speed of 30 ft. for 10 minutes per day. On command it transforms into a manta ray shape." },
  { name: "Cloak of the bat", cl: 6, aura: "Transmutation", price: 26000, slot: "shoulders", weight: 1,
    description: "At night, the wearer can transform into a bat (as beast shape II) for up to 70 minutes per day (in 10-minute increments). In bat form, she can fly 40 ft. with good maneuverability. She can also hang from ceilings and glide (150 ft., dropping 30 ft per glide)." },
  { name: "Cloak of arachnida", cl: 3, aura: "Conjuration/Transmutation", price: 14000, slot: "shoulders", weight: 1,
    description: "Grants the wearer a +2 resistance bonus on all saves vs poison, the ability to climb as spider climb continuously, and the ability to cast web once per day. It also lets her throw spider webs as a ranged touch (as a tanglefoot bag) 6 times per day, and she is unaffected by her own webs." },
  { name: "Gloves of dexterity +2", cl: 3, aura: "Transmutation", price: 4000, slot: "hands", weight: 0,
    description: "+2 enhancement to Dexterity. +4 = 16,000; +6 = 36,000." },
  { name: "Gloves of dexterity +4", cl: 7, aura: "Transmutation", price: 16000, slot: "hands", description: "+4 to Dex." },
  { name: "Gloves of dexterity +6", cl: 11, aura: "Transmutation", price: 36000, slot: "hands", description: "+6 to Dex." },
  { name: "Gauntlets of ogre power", cl: 3, aura: "Transmutation", price: 4000, slot: "hands", weight: 4,
    description: "Grants +2 enhancement bonus to Strength. +4 = 16,000 gp; +6 = 36,000 gp." },
  { name: "Gauntlets of strength +2", cl: 3, aura: "Transmutation", price: 4000, slot: "hands", weight: 4,
    description: "+2 Strength (as ogre power)." },
  { name: "Gauntlets of strength +4", cl: 7, aura: "Transmutation", price: 16000, slot: "hands", weight: 4, description: "+4 Strength." },
  { name: "Gloves of arrow snaring", cl: 3, aura: "Transmutation", price: 4000, slot: "hands", weight: 0,
    description: "Once per round, when you would normally be hit by a ranged weapon, you may catch it (if you have a free hand, or can transfer the weapon to an occupied hand on the next round). You must be aware of the attack and not flat-footed. Magical weapons require a DC 20 Dex check to catch, otherwise they still hit (but your gauntlet is not damaged). You cannot catch bullets or siege weapons." },
  { name: "Gloves of swimming and climbing", cl: 5, aura: "Transmutation", price: 6250, slot: "hands", weight: 0,
    description: "Grants the wearer a +5 competence bonus on Climb and Swim checks. The wearer's hands become slightly sticky." },
  { name: "Goggles of minute seeing", cl: 3, aura: "Divination", price: 2500, slot: "eyes", weight: 0,
    description: "When worn, the goggles grant a +5 competence bonus on Appraise checks for inspecting small items. They also allow the wearer to see minute details (fine print, hidden seams, etc.) and can be used to read scrolls with tiny writing." },
  { name: "Goggles of night", cl: 3, aura: "Transmutation", price: 12000, slot: "eyes", weight: 0,
    description: "These goggles grant the wearer darkvision out to 60 feet." },
  { name: "Belt of giant strength +2", cl: 3, aura: "Transmutation", price: 4000, slot: "waist", weight: 1,
    description: "Grants +2 enhancement to Strength. +4 = 16,000; +6 = 36,000; +8 (fire giant) = 64,000; +8 stone? 64k; frost giant +8? Also fire giant +4 = 16k? Standard: +2 (hill giant), +4 (stone/frost), +6 (fire), +8 (cloud)." },
  { name: "Belt of giant strength +4", cl: 7, aura: "Transmutation", price: 16000, slot: "waist", weight: 1, description: "+4 Strength." },
  { name: "Belt of giant strength +6", cl: 11, aura: "Transmutation", price: 36000, slot: "waist", weight: 1, description: "+6 Strength." },
  { name: "Belt of dwarvenkind", cl: 12, aura: "Divination", price: 14900, slot: "waist", weight: 1,
    description: "This belt grants dwarven traits to a wearer: darkvision 60 ft., +2 Constitution, +2 resistance bonus vs poison and spells/spell-like effects, +2 dodge bonus to AC vs giants, +1 racial bonus on attacks vs orcs and goblinoids, +2 racial bonus on Appraise checks involving stone or metal, +2 racial bonus on Craft checks involving stone or metal, and stonecunning (as a dwarf, +2 on Search checks for unusual stonework). Non-dwarves who put it on may feel a strong sense of dwarven identity; mechanical benefits apply regardless of race. Weight: 10 lb heavier clothing/armor? No." },
  { name: "Bag of holding (type I)", cl: 9, aura: "Conjuration", price: 2500, slot: "none", weight: 15,
    description: "This appears to be a common cloth sack (about 2 ft. by 4 ft.) but opens into an extradimensional space (30 cu. ft. / 250 lb. capacity). If it is turned inside out, its contents spill forth. If a bag of holding is placed within a portable hole, a rift to the Astral Plane is created that sucks both away; same if a portable hole is placed within a bag of holding. Type II (2500 gp, 70 cu ft, 500 lb), Type III (7400, 150 cu ft, 1000 lb), Type IV (10000, 250 cu ft, 1500 lb)." },
  { name: "Broom of flying", cl: 9, aura: "Transmutation", price: 17000, slot: "none", weight: 3,
    description: "This broom can be ridden (as if on horseback, but flying). It flies at 50 ft. with a single rider (carrying 169 lb max), or 40 ft with two (338 lb max), or 30 ft with three (507 lb max). It can also be commanded to sweep on its own (10 ft radius, cleans all dust/sand/refuse)." },
  { name: "Candle of truth", cl: 5, aura: "Enchantment", price: 5000, slot: "none", weight: 0.5,
    description: "When lit, all creatures within a 30-foot radius are subject to a zone of truth (Will DC 13 negates) as long as they remain in the area. Each candle burns for 1 hour; there are 1d4 candles when found." },
  { name: "Carpet of flying (4 ft. by 6 ft.)", cl: 10, aura: "Transmutation", price: 20000, slot: "none", weight: 10,
    description: "This carpet can fly at 40 ft (average maneuverability) and can carry up to 200 lb; if weight doubles, speed drops to 30 ft; triple to 20 ft. Larger carpets exist: 5x10 ft = 35,000 gp (400 lb), 6x9 = 60,000 (800 lb), 8x10 = 75,000 (1600 lb)." },
  { name: "Cloak of etherealness", cl: 15, aura: "Conjuration", price: 168000, slot: "shoulders", weight: 1,
    description: "The wearer can become ethereal (as ethereal jaunt, CL 15) for up to 10 rounds per day (in 1-round increments). While ethereal, she is on the Ethereal Plane and can move through solid objects on the Material Plane." },
  { name: "Crystal ball", cl: 10, aura: "Divination", price: 42000, slot: "none", weight: 7,
    description: "This crystal sphere allows the user to scry as the scrying spell (Will DC 16 negates). It works for up to 10 minutes per day (in 1-minute increments). Crystal balls with see invisibility cost an additional 24,000 gp; with true seeing add 80,000 gp; with telepathy add 36,000 gp." },
  { name: "Daern's instant fortress", cl: 13, aura: "Conjuration", price: 55000, slot: "none", weight: 0.5,
    description: "When activated by tossing it and speaking a command word, this small metal cube grows into a 20 ft by 20 ft tower 30 ft tall, made of adamantine (hardness 20, 100 hp per section). The door is an iron door (hardness 10, 60 hp). 100 archers can stand on the battlements. It can be collapsed back to cube size with another command. If creatures are inside when it collapses, they are shunted outside. 90,000 gp? No, 55,000 gp per SRD." },
  { name: "Decanter of endless water", cl: 9, aura: "Transmutation", price: 9000, slot: "none", weight: 4,
    description: "This decanter can be commanded to produce fresh or salt water: stream (1 gallon per round), fountain (5 gallons per round), or geyser (30 gallons per round, 20 ft long stream that can knock creatures over with a ranged touch attack (Str check DC 12 to avoid bull rush)). If stoppered, it does not leak." },
  { name: "Deck of illusions", cl: 6, aura: "Illusion", price: 7000, slot: "none", weight: 0.5,
    description: "This pack contains 34 cards. When any card is drawn and tossed down (within 30 ft), it creates an illusion of the creature shown (Major Image, CL 6). The illusion attacks, behaves as programmed, and lasts until dispelled, touched (Will disbelief), or until another card is drawn from the same deck. There are 1d20+14 cards when found, with duplicates possible." },
  { name: "Dimensional shackles", cl: 11, aura: "Abjuration", price: 28000, slot: "none", weight: 5,
    description: "These shackles have a single command word to open/close. Any creature bound in them is affected by dimensional anchor (cannot teleport, plane shift, astral project, etc.). They can also be locked with a superior lock (DC 30 to open). They adjust to fit any size from Tiny to Large." },
  { name: "Drums of panic", cl: 7, aura: "Necromancy", price: 30000, slot: "none", weight: 5,
    description: "These kettle drums produce a thunderous rumble that causes creatures in a 20-ft radius to become panicked (Will DC 16 negates). They can be played once per day for up to 6 rounds. Creatures that make their save cannot be affected by the same drums for 24 hours." },
  { name: "Eversmoking bottle", cl: 3, aura: "Conjuration", price: 5400, slot: "none", weight: 1,
    description: "On command, this bottle produces a thick cloud of smoke (as fog cloud) filling 100 cubic feet per round (stopping when commanded, or stopped by reversing to suck it back). The smoke can fill a 100 ft x 20 ft spread after 10 rounds. Strong winds disperse it." },
  { name: "Eyes of charm", cl: 7, aura: "Enchantment", price: 48000, slot: "eyes", weight: 0,
    description: "These crystal lenses fit over the eyes. The wearer can cast charm monster (Will DC 19 negates) on a single creature within 30 feet three times per day." },
  { name: "Eyes of doom", cl: 11, aura: "Necromancy", price: 25000, slot: "eyes", weight: 0,
    description: "When worn, the wearer can use fear (Will DC 16 negates) once per day, and can cast death watch at will. Two uses per day can cause a target to become panicked (same as fear, single target within 30 ft)." },
  { name: "Eyes of the eagle", cl: 10, aura: "Divination", price: 2500, slot: "eyes", weight: 0,
    description: "These lenses grant a +5 competence bonus on Spot checks and allow the wearer to see as if she were five feet closer when peering through narrow openings (she can see things 10 ft away as if within 5 ft)." },
  { name: "Figurine of wondrous power (obsidian steed)", cl: 11, aura: "Conjuration", price: 28500, slot: "none", weight: 1,
    description: "When commanded, this 6-inch long figurine becomes a heavy warhorse with a nightmare-like appearance (no fly, but black coat with flame-colored hooves). It serves for up to 24 hours per week total. It is a heavy horse with +6 natural armor and Int 6, and it understands Common." },
  { name: "Figurine of wondrous power (serpentine owl)", cl: 11, aura: "Conjuration", price: 8100, slot: "none", weight: 0.5,
    description: "Becomes a Large owl that carries messages (flies 60 ft, average maneuverability). It can serve up to 24 hours per week and can transport tiny objects or notes tied to its leg." },
  { name: "Gem of brightness", cl: 9, aura: "Evocation", price: 13000, slot: "none", weight: 0,
    description: "This gem has 50 charges. It can glow with a bright light (1 charge, as daylight, 30 min), release a blinding ray (5 charges, as searing light? No, it casts a ray at one target within 30 ft: 5d4 damage if unarmored and 5d4 if wearing armor? No per SRD: it can flare brightly, blinding all creatures within 30 ft for 1d4 rounds (Fort DC 14 negates), uses 1 charge. Also can shoot a 120-ft ray of light dealing 1d8 damage per charge spent (up to 5d8 per ray)." },
  { name: "Hand of glory", cl: 5, aura: "Varies", price: 8000, slot: "neck", weight: 2,
    description: "This is a mummified human hand hung around the neck. It allows the wearer to use a ring on each of its digits (two additional ring slots beyond her normal two hands), and the wearer can also cast daylight once per day from its index finger. If the wearer is evil, it may allow other effects." },
  { name: "Hand of the mage", cl: 2, aura: "Transmutation", price: 900, slot: "none", weight: 2,
    description: "This mummified elf hand (on a chain) allows the wearer to cast mage hand at will (CL 2)." },
  { name: "Hat of disguise", cl: 3, aura: "Illusion", price: 1800, slot: "head", weight: 0,
    description: "This hat allows the wearer to use disguise self at will (CL 3), changing her appearance (same type, up to 10% lighter/heavier, etc.)." },
  { name: "Headband of intellect +2", cl: 3, aura: "Transmutation", price: 4000, slot: "head", weight: 0,
    description: "Grants +2 enhancement to Intelligence. +4 = 16,000; +6 = 36,000." },
  { name: "Headband of intellect +4", cl: 7, aura: "Transmutation", price: 16000, slot: "head", description: "+4 Int." },
  { name: "Headband of intellect +6", cl: 11, aura: "Transmutation", price: 36000, slot: "head", description: "+6 Int." },
  { name: "Helm of comprehend languages", cl: 5, aura: "Divination", price: 10500, slot: "head", weight: 1,
    description: "This helmet allows the wearer to understand any language (as comprehend languages) spoken around her, and to read any written language she can see (including magical writing, though she does not necessarily understand the magic itself). It does not allow her to speak languages she does not know." },
  { name: "Helm of telepathy", cl: 10, aura: "Divination/Enchantment", price: 27000, slot: "head", weight: 3,
    description: "The wearer can detect thoughts (Will DC 15 negates) at will and can send a telepathic message to any creature within 100 feet, or establish telepathic contact with one creature for as long as she concentrates. She can also plant a suggestion (Will DC 15 negates) once per day." },
  { name: "Helm of teleportation", cl: 9, aura: "Conjuration", price: 73500, slot: "head", weight: 3,
    description: "This helmet functions exactly like boots of teleportation: three uses per day of greater teleport." },
  { name: "Heward's handy haversack", cl: 9, aura: "Conjuration", price: 2000, slot: "none", weight: 5,
    description: "This backpack has several pouches that connect to extradimensional spaces. The central pouch holds up to 80 lb / 8 cu ft, the two side pouches hold up to 20 lb / 2 cu ft each. The wearer can retrieve any item from it as a move action without digging around. It always weighs 5 pounds regardless of contents." },
  { name: "Horn of blasting", cl: 7, aura: "Evocation", price: 20000, slot: "none", weight: 1,
    description: "This brass horn produces a loud note audible out to 1 mile. When used as an attack, it generates a 100-ft cone of sonic energy: creatures within take 5d6 sonic damage (Reflex DC 19 halves); crystalline objects/lithic creatures take double damage. If a second blast is sounded within 10 minutes, there is a 20% chance the horn explodes dealing 10d6 damage to the holder." },
  { name: "Horn of fog", cl: 3, aura: "Conjuration", price: 2000, slot: "none", weight: 1,
    description: "This small fog-horn allows the wielder to create a bank of fog as the fog cloud spell once per day." },
  { name: "Horn of good/evil/chaos/law", cl: 6, aura: "Varies", price: 6500, slot: "none", weight: 1,
    description: "When sounded, this horn dispels magic aligned opposite to the horn's alignment in a 20-ft radius (as dispel magic vs spells with that alignment descriptor). In addition, it summons a group of celestial or fiendish creatures (1d3 of the appropriate type for the alignment) once per week." },
  { name: "Horseshoes of speed", cl: 3, aura: "Transmutation", price: 3000, slot: "none", weight: 2,
    description: "These iron horseshoes increase the creature's base land speed by 30 ft (enhancement bonus, as expeditious retreat for horses). They also allow the mount to travel at double overland speed. All four shoes must be worn." },
  { name: "Horseshoes of a zephyr", cl: 3, aura: "Transmutation", price: 6000, slot: "none", weight: 0,
    description: "These horseshoes allow the mount ridden to ride across sand, mud, snow, ice, or even water as if it were solid ground, and the mount can even ride across open air for up to 10 rounds at a time (up to 80 ft high) before descending." },
  { name: "Instant summons", cl: 9, aura: "Conjuration", price: 1000, slot: "none", weight: 0,
    description: "You prepare this sapphire talisman by crushing it and speaking a creature's name. You may then summon the creature from anywhere on the same plane (if it is alive and willing) to appear before you immediately. This is often used to summon a bonded mount or familiar." },
  { name: "Ioun stone", cl: 12, aura: "Varies", price: 0, slot: "none", weight: 0,
    description: "These small gemstones orbit the head at a distance of 1d3 inches, providing continuous benefits: 1) dusty rose prism (+1 insight AC, 5,000 gp); 2) deep red sphere (+2 Str, 8,000); 3) incandescent blue sphere (+2 Wis, 8,000); 4) pale blue rhomboid (+2 Con, 8,000); 5) pink and green sphere (+2 Cha, 8,000); 6) pink rhomboid (+2 Con? Actually pink rhomboid is vitality: +1 to all ability scores? No, pink rhomboid regenerates 1 hp per 10 minutes? Let's use standard listing. Price varies by type. Roll d% for type when found." },
  { name: "Iron bands of Bilarro", cl: 13, aura: "Evocation", price: 26000, slot: "none", weight: 1,
    description: "This small iron ball expands into a large set of iron bands (like a tanglefoot but iron) when thrown at a target within 10 ft (ranged touch attack). On a hit, the target is captured and entangled (can't move, can break with DC 30 Strength check; hardness 10, 30 hp, bend bars/lift gates DC 28 to escape). The sphere is reusable (command word to shrink it back)." },
  { name: "Keoghtom's ointment", cl: 11, aura: "Conjuration", price: 4000, slot: "none", weight: 0.5,
    description: "A tiny jar of sticky, green ointment. There are 1d4+1 doses. A single dose cures disease, cures 1d8+11 damage, and neutralizes poison when smeared on a creature. It is highly sought after." },
  { name: "Lantern of revealing", cl: 7, aura: "Divination", price: 30000, slot: "none", weight: 2,
    description: "This bullseye lantern operates as a normal hooded lantern, but on command it reveals invisible creatures and objects within its beam, and can even show ethereal creatures and objects (as if they were visible). It operates for 6 hours on a single pint of oil." },
  { name: "Lens of detection", cl: 3, aura: "Divination", price: 3500, slot: "none", weight: 1,
    description: "This circular prism allows the user to detect secret doors, traps, and concealed objects when held to the eye (as detect secret doors). It grants a +5 competence bonus on Search checks to find traps and secret doors." },
  { name: "Mantle of spell resistance", cl: 9, aura: "Abjuration", price: 90000, slot: "shoulders", weight: 1,
    description: "This silvery garment grants the wearer spell resistance 21. (SR 17 = 50,000 gp, SR 19 = 70,000 gp.)" },
  { name: "Manual of bodily health", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Reading this heavy tome (requires 48 hours over at least six days) grants a +1 inherent bonus to Constitution (and corresponding hit points, Fortitude save benefits etc.). One reading only, then the book crumbles to dust. +2 = 55,000 gp; +3 = 82,500; +4 = 110,000; +5 = 137,500 gp." },
  { name: "Manual of gainful exercise", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Grants +1 inherent bonus to Strength (read over 6 days). +2 = 55,000; +3 = 82,500; etc." },
  { name: "Manual of quickness in action", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Grants +1 inherent bonus to Dexterity." },
  { name: "Mask of the skull", cl: 9, aura: "Necromancy", price: 22000, slot: "head", weight: 1,
    description: "This skull-shaped mask has a 50% chance of being cursed (if cursed, it attracts insects and delivers a death spell to the wearer when she is first hit in combat). If not cursed, once per day the wearer can cause the skull to bite a living creature within 30 feet (melee touch attack; 1d8+4 piercing damage, and the target must make a DC 16 Fortitude save or die instantly; it also has no effect on undead)." },
  { name: "Medallion of thoughts", cl: 7, aura: "Divination", price: 12000, slot: "neck", weight: 0,
    description: "This bronze medallion allows the wearer to detect thoughts (Will DC 14 negates) three times per day, as the spell CL 7." },
  { name: "Mirror of mental prowess", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 10,
    description: "This magical mirror grants +1 inherent bonus to Intelligence and +1 to Charisma to whoever sits before it and reads its command phrase (after studying it at least 10 minutes a day for 3 days). One use only; +2 version costs 55,000 gp." },
  { name: "Mirror of opposition", cl: 15, aura: "Necromancy", price: 92000, slot: "none", weight: 45,
    description: "Any creature that sees its reflection in this mirror summons an exact duplicate of itself (same level, equipment, alignment reversed) that immediately attacks the original. The duplicate persists until it or the original is slain, or 24 hours pass. The mirror can create only one duplicate at a time, and the original cannot use the mirror while the duplicate exists." },
  { name: "Murlynd's spoon", cl: 5, aura: "Conjuration", price: 5400, slot: "none", weight: 0,
    description: "When placed in an empty container and commanded, this spoon produces enough hot, nourishing gruel (flavor like warm oatmeal or porridge) to feed up to four humans per day." },
  { name: "Necklace of adaptation", cl: 7, aura: "Transmutation", price: 9000, slot: "neck", weight: 0,
    description: "This necklace continuously surrounds the wearer with a shell of fresh air, allowing her to breathe in water, in vacuum, in poisonous gas, or in smoke-filled environments. It does not protect against inhaled poisons or magical gas attacks that require a save (it just provides breathable air)." },
  { name: "Necklace of fireballs", cl: 10, aura: "Evocation", price: 5400, slot: "neck", weight: 0,
    description: "This necklace has 1d6+6 gold spheres (beads) strung on it. Each bead can be detached and thrown up to 70 ft (range increment 20 ft), exploding as a fireball. Roll 1d8 for each bead: 1-4 = 3d6 damage, 5-6 = 5d6, 7-8 = 7d6. Reflex DC 14 halves. Throwing a bead is a ranged touch attack that detonates on impact." },
  { name: "Necklace of prayer beads", cl: 9, aura: "Varies", price: 25800, slot: "neck", weight: 0,
    description: "This necklace has 1d4+6 beads strung on a golden chain, of which 2d4+2 are magic when found. Various bead types: blessing (bless on up to twelve allies 1/day), curing (heal 1/day), karma (caster level +4 for 10 min 1/day), summons (summon monster VI 1/day), wind walking (wind walk 1/day), smiting (weapon gains +1 holy and +2d6 evil for 1 hour), etc. Roll randomly for types." },
  { name: "Nolzur's marvelous pigments", cl: 9, aura: "Conjuration", price: 4000, slot: "none", weight: 1,
    description: "These pigments come in a small clay jar (1d4 jars when found). You can use them to paint any non-magical object (including doors, pits, traps, food, water, etc.), making it a real object. You can paint a 10-ft by 10-ft area; items created can be up to 1,000 cubic feet. Objects painted must be simple (cannot create fine art or magical items)." },
  { name: "Orb of storms", cl: 11, aura: "Evocation", price: 48000, slot: "none", weight: 25,
    description: "This glass globe allows the wielder to control the weather in a 1-mile radius (as control weather), or to summon a lightning bolt (10d6 damage), rainstorm, sleet storm, fog cloud, or gust of wind once per day." },
  { name: "Pearl of power (1st)", cl: 17, aura: "Transmutation", price: 1000, slot: "none", weight: 0,
    description: "Once per day on command, this pearl enables the possessor to recall one 1st-level spell she has already cast, as if she had not used the slot. Levels: 1st = 1,000; 2nd = 4,000; 3rd = 9,000; 4th = 16,000; 5th = 25,000; 6th = 36,000; 7th = 49,000; 8th = 64,000; 9th = 81,000." },
  { name: "Pearl of power (2nd)", cl: 17, aura: "Transmutation", price: 4000, slot: "none", description: "Recall a 2nd-level spell slot." },
  { name: "Pearl of the sirines", cl: 11, aura: "Enchantment/Transmutation", price: 15300, slot: "none", weight: 0,
    description: "This pearl grants the wearer the ability to breathe water and a +5 competence bonus on Perform (sing) checks, and Charm Monster once per day (on air-breathing targets within 30 ft, Will DC 19 negates)." },
  { name: "Periapt of wisdom +2", cl: 3, aura: "Transmutation", price: 4000, slot: "neck", weight: 0,
    description: "+2 enhancement to Wisdom. +4 = 16,000; +6 = 36,000." },
  { name: "Periapt of wisdom +4", cl: 7, aura: "Transmutation", price: 16000, slot: "neck", description: "+4 to Wis." },
  { name: "Periapt of wisdom +6", cl: 11, aura: "Transmutation", price: 36000, slot: "neck", description: "+6 to Wis." },
  { name: "Periapt of health", cl: 7, aura: "Conjuration", price: 15000, slot: "neck", weight: 0,
    description: "The wearer is immune to all disease (magical and non-magical)." },
  { name: "Periapt of wound closure", cl: 5, aura: "Conjuration", price: 10000, slot: "neck", weight: 0,
    description: "If the wearer's hit points drop below zero, she automatically stabilizes. Additionally, she heals twice as fast from bed rest (2 hp per full day of rest plus level; or 4 with complete bed rest). It also helps against bleeding wounds." },
  { name: "Phylactery of faithfulness", cl: 1, aura: "Divination", price: 1000, slot: "headband", weight: 0,
    description: "This item is worn on the forehead. It warns the wearer if she is about to do something that would violate the tenets of her alignment/faith (via a sudden mental warning)." },
  { name: "Phylactery of undead turning", cl: 5, aura: "Necromancy", price: 11000, slot: "headband", weight: 0,
    description: "When worn by a divine spellcaster, this phylactery grants a +2 competence bonus on turning checks and turning damage rolls when turning or rebuking undead." },
  { name: "Portable hole", cl: 12, aura: "Conjuration", price: 20000, slot: "none", weight: 0,
    description: "This circular cloth (6 ft diameter) creates an extradimensional hole 10 ft deep when spread out. It holds up to 283 cubic feet (about 2,800 lb capacity). It can be picked up by folding it into a small cloth (1 ft across). If placed in a bag of holding (or vice versa), a rift to the Astral Plane is formed that sucks both away and strands all creatures within 10 ft in the Astral." },
  { name: "Quiver of Ehlonna", cl: 5, aura: "Conjuration", price: 1800, slot: "none", weight: 2,
    description: "This quiver has three compartments that hold 60 items total (20 javelins/arrows in the largest, 30 arrows/bolts in the medium, 60 small items like sling bullets in the smallest). It can produce the desired item on command (as a free action). It always weighs 2 pounds regardless of contents." },
  { name: "Ring gates", cl: 13, aura: "Conjuration", price: 40000, slot: "none", weight: 1,
    description: "A pair of iron rings (each 1 ft diameter). When one ring is tossed through the other, anything that goes through one ring comes out the other at any distance (even across planes). Each ring can bear up to 100 lb per round, and they weigh 1 lb each. If one is destroyed, the other loses all magic." },
  { name: "Robe of the archmagi", cl: 14, aura: "Varies", price: 75000, slot: "body", weight: 1,
    description: "This magical robe grants the wearer (arcane spellcasters only) a +5 armor bonus to AC (as bracers of armor), +2 resistance bonus on all saves, and spell resistance 24. It comes in three colors: white (for good casters, grants +4 enhancement to Charisma), gray (neutral, +2 to Int and Wis), black (evil, +4 to Int). A wearer not of the robe's alignment gains 1 negative level while wearing it." },
  { name: "Robe of blending", cl: 10, aura: "Illusion", price: 30000, slot: "body", weight: 1,
    description: "This chameleon-like robe changes color to match the surroundings, granting a +10 competence bonus on Hide checks. Once per day the wearer can adopt an even more specific disguise (as if using disguise self) to appear as a specific type of creature (human, elf, orc, etc.)." },
  { name: "Robe of eyes", cl: 11, aura: "Divination", price: 54000, slot: "body", weight: 1,
    description: "This light blue robe is covered with small eye patterns. The wearer can see in all directions at once (including 120 ft darkvision, see invisibility, cannot be flanked, +5 competence bonus on Spot and Search checks)." },
  { name: "Robe of scintillating colors", cl: 11, aura: "Illusion", price: 30000, slot: "body", weight: 1,
    description: "Once per day, the robe can erupt into a whirling pattern of colors. Creatures within 20 ft are affected as per color spray and pattern spells: fascinated, confused, or stunned depending on HD (Will DC 16 negates). The effect lasts 1d4+1 rounds." },
  { name: "Robe of the archfiend", cl: 11, aura: "Evocation/Abjuration", price: 30000, slot: "body", weight: 1,
    description: "This black robe, lined with red, grants +4 armor bonus, +2 resistance bonus on all saves, and the wearer can use unholy blight once per day (CL 6). Good wearers gain a negative level while wearing it." },
  { name: "Rope of climbing", cl: 3, aura: "Transmutation", price: 3000, slot: "none", weight: 3,
    description: "A 50-ft length of silk rope that can be commanded to knot, unknot, climb up or down surfaces, wrap around objects, fasten itself, etc. It holds up to 3,000 lb. and can be commanded to tie itself around a post or outcropping." },
  { name: "Rope of entanglement", cl: 3, aura: "Transmutation", price: 4000, slot: "none", weight: 3,
    description: "This rope is 30 feet long, but can wrap itself around a creature or up to 8 feet away from the user (ranged touch attack). It entangles as if by a net (except it can also be used to entangle multiple creatures if enough length). It can stretch to twice its length on command and requires a DC 20 Strength or DC 23 Escape Artist check to slip free." },
  { name: "Salve of slipperiness", cl: 6, aura: "Conjuration", price: 1000, slot: "none", weight: 0.5,
    description: "A single jar has 1d4 doses. When rubbed on a creature, the unguent acts as freedom of movement for 8 hours. It can also be used to oil a lock (DC 30 Open Lock becomes DC 20) or squeeze through a small space. It cannot be used more than once per dose." },
  { name: "Scarab of protection", cl: 12, aura: "Abjuration", price: 38000, slot: "none", weight: 0.5,
    description: "This pin, shaped like a jeweled beetle, absorbs energy drain, level loss, and death effects, up to 12 negative levels before it crumbles. It can also be used to cast protection from evil in a 20-ft radius (3/day)." },
  { name: "Sending stones", cl: 7, aura: "Divination", price: 14000, slot: "none", weight: 0,
    description: "These matched stones (1d2+1 pairs when found) allow the bearer of one to send a 25-word message to the bearer of its mate once per day, as the sending spell (though not limited by distance or plane, as long as the bearer is alive and on the same plane)." },
  { name: "Slippers of spider climbing", cl: 4, aura: "Transmutation", price: 4800, slot: "feet", weight: 0.5,
    description: "The wearer can walk on walls and ceilings as if under the spider climb spell (hands-free, 20 ft climb speed)." },
  { name: "Stone of alarm", cl: 3, aura: "Abjuration", price: 2700, slot: "none", weight: 0.5,
    description: "When you speak a command word and place the stone, it triggers an audible alarm (100 ft radius) when any Tiny or larger creature crosses an invisible boundary within 20 feet of it. It can also be set to trigger a mental alarm. The stone can be activated/deactivated at will." },
  { name: "Stone of controlling earth elementals", cl: 15, aura: "Varies", price: 170000, slot: "none", weight: 5,
    description: "This stone gives its bearer the ability to summon an 8 HD earth elemental once per day (which serves automatically). It also grants +5 competence bonus on Charisma checks against earth creatures, and charm monster (earth creatures only, Will DC 22 negates, one at a time)." },
  { name: "Stone of good luck (luckstone)", cl: 5, aura: "Evocation", price: 20000, slot: "none", weight: 0,
    description: "This small gem gives the possessor a +1 luck bonus on all saving throws, ability checks, and skill checks (it does not grant attack roll bonuses, unlike the spell divine favor)." },
  { name: "Tome of clear thought", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Reading this tome over 48 hours (spread over six days) grants a +1 inherent bonus to Intelligence. +2 = 55,000; etc." },
  { name: "Tome of leadership and influence", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Grants a +1 inherent bonus to Charisma (and aids leadership skill if the reader has it)." },
  { name: "Tome of understanding", cl: 17, aura: "Universal", price: 27500, slot: "none", weight: 5,
    description: "Grants +1 inherent bonus to Wisdom." },
  { name: "Vest of escape", cl: 7, aura: "Transmutation", price: 5200, slot: "torso", weight: 0.5,
    description: "This black silk vest grants a +4 competence bonus on Escape Artist checks. Once per day, the wearer can use knock or a dimension door (self and up to 5 lb gear only).", },
];

// -----------------------------
// Scroll class caster level table per spell level
// -----------------------------
export function scrollCL(level: number): number {
  if (level <= 0) return 1;
  return level * 2 - 1;
}

// Wand cost in gp (fully charged = 50 charges) = spell level * caster level * 750
// (market price is spell level × caster level × 750 gp; half that to create)
export function wandPrice(level: number, cl: number): number {
  if (level === 0) return 375; // 0-level wands are spell level 0.5? Actually 375 gp per SRD.
  return level * cl * 750;
}

// Scroll price: spell level × caster level × 25 gp
export function scrollPrice(level: number, cl: number): number {
  if (level === 0) return 12.5; // 12.5 gp
  return level * cl * 25;
}

// Potion price: spell level × caster level × 50 gp (capped at 3rd level spells)
export function potionPrice(level: number, cl: number): number {
  return level * cl * 50;
}

// ----------------------------
// Cursed item chance: 5%
// ----------------------------
export const CURSED_CHANCE = 0.05;

// Cursed items (for when we roll cursed):
export const cursedItems = [
  "Cursed armor (opposite enhancement bonus or -1/-2/-3/-4/-5)",
  "Cursed weapon (opposite enhancement bonus)",
  "Cursed shield",
  "Armor of rage",
  "Berserking sword",
  "Bracers of defenselessness",
  "Cloak of poisonousness",
  "Gauntlets of fumbling",
  "Medallion of thought projection",
  "Necklace of strangulation",
  "Periapt of foul rotting",
  "Cursed potion",
  "Cursed scroll (effect reversed or dangerous)",
  "Flask of curses",
  "Potion of poison",
  "Ring of clumsiness",
  "Ring of contrariness",
  "Robe of powerlesslessness",
  "Rod of rulership (cursed variant)",
  "Scarab of death",
  "Shield of missile attraction",
  "Spear of curses",
  "Stone of weight (loadstone)",
  "Vacuous grimoire",
];
