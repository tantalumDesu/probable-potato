// VERBATIM transcription of d20srd.org Table: Rings and Table: Rods.
// These supersede the approximations in otherMagicItems.ts.

export type Tier = "minor" | "medium" | "major";

export interface RingEntry {
  min: number;
  max: number;
  name: string;
  price: number;
  charges?: "50" | "special";
  randomRoll?: string; // instruction for a sub-roll on random generation
  description: string;
}

// Table: Rings — the same table serves all three tiers; a dash means the ring
// is not available at that tier. Selection is by rolling d% on the column that
// corresponds to the item's tier.
export const ringTable: Record<Tier, { min: number; max: number; name: string }[]> = {
  minor: [
    { min: 1, max: 18, name: "Protection +1" },
    { min: 19, max: 28, name: "Feather falling" },
    { min: 29, max: 36, name: "Sustenance" },
    { min: 37, max: 44, name: "Climbing" },
    { min: 45, max: 52, name: "Jumping" },
    { min: 53, max: 60, name: "Swimming" },
    { min: 61, max: 70, name: "Counterspells" },
    { min: 71, max: 75, name: "Mind shielding" },
    { min: 76, max: 80, name: "Protection +2" },
    { min: 81, max: 85, name: "Force shield" },
    { min: 86, max: 90, name: "Ram" },
    { min: 91, max: 93, name: "Animal friendship" },
    { min: 94, max: 96, name: "Energy resistance, minor" },
    { min: 97, max: 98, name: "Chameleon power" },
    { min: 99, max: 100, name: "Water walking" },
  ],
  medium: [
    { min: 1, max: 5, name: "Counterspells" },
    { min: 6, max: 8, name: "Mind shielding" },
    { min: 9, max: 18, name: "Protection +2" },
    { min: 19, max: 23, name: "Force shield" },
    { min: 24, max: 28, name: "Ram" },
    { min: 29, max: 34, name: "Climbing, improved" },
    { min: 35, max: 40, name: "Jumping, improved" },
    { min: 41, max: 46, name: "Swimming, improved" },
    { min: 47, max: 51, name: "Animal friendship" },
    { min: 52, max: 56, name: "Energy resistance, minor" },
    { min: 57, max: 61, name: "Chameleon power" },
    { min: 62, max: 66, name: "Water walking" },
    { min: 67, max: 71, name: "Protection +3" },
    { min: 72, max: 76, name: "Spell storing, minor" },
    { min: 77, max: 81, name: "Invisibility" },
    { min: 82, max: 85, name: "Wizardry I" },
    { min: 86, max: 89, name: "Evasion" },
    { min: 90, max: 92, name: "X-ray vision" },
    { min: 93, max: 95, name: "Blinking" },
    { min: 96, max: 98, name: "Meld into stone" },
    { min: 99, max: 100, name: "Energy resistance, major" },
  ],
  major: [
    { min: 1, max: 2, name: "Energy resistance, minor" },
    { min: 3, max: 7, name: "Protection +3" },
    { min: 8, max: 10, name: "Spell storing, minor" },
    { min: 11, max: 15, name: "Invisibility" },
    { min: 16, max: 19, name: "Wizardry I" },
    { min: 20, max: 25, name: "Evasion" },
    { min: 26, max: 28, name: "X-ray vision" },
    { min: 29, max: 32, name: "Blinking" },
    { min: 33, max: 36, name: "Meld into stone" },
    { min: 37, max: 43, name: "Energy resistance, major" },
    { min: 44, max: 50, name: "Protection +4" },
    { min: 51, max: 55, name: "Wizardry II" },
    { min: 56, max: 60, name: "Freedom of movement" },
    { min: 61, max: 63, name: "Energy resistance, greater" },
    { min: 64, max: 65, name: "Friend shield (pair)" },
    { min: 66, max: 70, name: "Protection +5" },
    { min: 71, max: 74, name: "Shooting stars" },
    { min: 75, max: 79, name: "Spell storing" },
    { min: 80, max: 83, name: "Wizardry III" },
    { min: 84, max: 86, name: "Telekinesis" },
    { min: 87, max: 88, name: "Regeneration" },
    { min: 89, max: 89, name: "Three wishes" },
    { min: 90, max: 92, name: "Spell turning" },
    { min: 93, max: 94, name: "Wizardry IV" },
    { min: 95, max: 95, name: "Djinni calling" },
    { min: 96, max: 96, name: "Elemental command (air)" },
    { min: 97, max: 97, name: "Elemental command (earth)" },
    { min: 98, max: 98, name: "Elemental command (fire)" },
    { min: 99, max: 99, name: "Elemental command (water)" },
    { min: 100, max: 100, name: "Spell storing, major" },
  ],
};

// Ring descriptions with correct SRD market prices.
export const ringDetails: Record<string, { price: number; charges?: "50"; randomRoll?: string; description: string }> = {
  "Protection +1": { price: 2000, description: "This ring offers continual magical protection in the form of a +1 deflection bonus to AC.\n\nFaint abjuration; CL 5th; Forge Ring, shield of faith, caster must be of a level at least three times greater than the bonus of the ring; Price 2,000 gp." },
  "Protection +2": { price: 8000, description: "This ring offers continual magical protection in the form of a +2 deflection bonus to AC.\n\nFaint abjuration; CL 5th; Forge Ring, shield of faith, caster must be of a level at least three times greater than the bonus of the ring; Price 8,000 gp." },
  "Protection +3": { price: 18000, description: "This ring offers continual magical protection in the form of a +3 deflection bonus to AC.\n\nFaint abjuration; CL 5th; Forge Ring, shield of faith; Price 18,000 gp." },
  "Protection +4": { price: 32000, description: "This ring offers continual magical protection in the form of a +4 deflection bonus to AC.\n\nFaint abjuration; CL 5th; Forge Ring, shield of faith; Price 32,000 gp." },
  "Protection +5": { price: 50000, description: "This ring offers continual magical protection in the form of a +5 deflection bonus to AC.\n\nFaint abjuration; CL 5th; Forge Ring, shield of faith; Price 50,000 gp." },
  "Feather falling": { price: 2200, description: "This ring is crafted with a feather pattern all around its edge. It acts exactly like a feather fall spell, activated immediately if the wearer falls more than 5 feet.\n\nFaint transmutation; CL 1st; Forge Ring, feather fall; Price 2,200 gp." },
  "Sustenance": { price: 2500, description: "This ring continually provides its wearer with life-sustaining nourishment. The ring also refreshes the body and mind, so that its wearer needs only sleep 2 hours per day to gain the benefit of 8 hours of sleep. The ring must be worn for a full week before it begins to work. If it is removed, the owner must wear it for another week to reattune it to himself.\n\nFaint conjuration; CL 5th; Forge Ring, create food and water; Price 2,500 gp." },
  "Climbing": { price: 2500, description: "This ring is actually a magic leather cord that ties around a finger. It continually grants the wearer a +5 competence bonus on Climb checks.\n\nFaint transmutation; CL 5th; Forge Ring, creator must have 5 ranks in the Climb skill; Price 2,500 gp." },
  "Climbing, improved": { price: 10000, description: "As climbing, except it grants a +10 competence bonus on its wearer's Climb checks.\n\nFaint transmutation; CL 5th; Forge Ring, creator must have 10 ranks in the Climb skill; Price 10,000 gp." },
  "Jumping": { price: 2500, description: "This ring continually allows the wearer to leap about, providing a +5 competence bonus on all his Jump checks.\n\nFaint transmutation; CL 2nd; Forge Ring, creator must have 5 ranks in the Jump skill; Price 2,500 gp." },
  "Jumping, improved": { price: 10000, description: "As jumping, except it grants a +10 competence bonus on its wearer's Jump check.\n\nModerate transmutation; CL 7th; Forge Ring, creator must have 10 ranks in the Jump skill; Price 10,000 gp." },
  "Swimming": { price: 2500, description: "This silver ring has a wave pattern etched into the band. It continually grants the wearer a +5 competence bonus on Swim checks.\n\nFaint transmutation; CL 2nd; Forge Ring, creator must have 5 ranks in the Swim skill; Price 2,500 gp." },
  "Swimming, improved": { price: 10000, description: "As swimming, except it grants a +10 competence bonus on its wearer's Swim checks.\n\nModerate transmutation; CL 7th; Forge Ring, creator must have 10 ranks in the Swim skill; Price 10,000 gp." },
  "Counterspells": { price: 4000, randomRoll: "1st- through 6th-level spell stored in the ring",
    description: "This ring might seem to be a ring of spell storing upon first examination. However, while it allows a single spell of 1st through 6th level to be cast into it, that spell cannot be cast out of the ring again. Instead, should that spell ever be cast upon the wearer, the spell is immediately countered, as a counterspell action, requiring no action (or even knowledge) on the wearer's part. Once so used, the spell cast within the ring is gone. A new spell (or the same one as before) may be placed in it again.\n\nModerate evocation; CL 11th; Forge Ring, imbue with spell ability; Price 4,000 gp." },
  "Mind shielding": { price: 8000, description: "This ring is usually of fine workmanship and wrought from heavy gold. The wearer is continually immune to detect thoughts, discern lies, and any attempt to magically discern her alignment.\n\nFaint abjuration; CL 3rd; Forge Ring, nondetection; Price 8,000 gp." },
  "Force shield": { price: 8500, description: "An iron band, this simple ring generates a shield-sized (and shield-shaped) wall of force that stays with the ring and can be wielded by the wearer as if it were a heavy shield (+2 AC). This special creation has no armor check penalty or arcane spell failure chance since it is weightless and encumbrance-free. It can be activated and deactivated at will as a free action.\n\nModerate evocation; CL 9th; Forge Ring, wall of force; Price 8,500 gp." },
  "Ram": { price: 8600, charges: "50",
    description: "The wearer can command the ring to give forth a ramlike force that strikes a single target, dealing 1d6 points of damage if 1 charge is expended, 2d6 if 2 charges, or 3d6 if 3 charges (the maximum) are used. Treat this as a ranged attack with a 50-foot maximum range and no penalties for distance. Those struck are subject to a bull rush if within 30 feet (the ram has Strength 25 and is Large), gaining +1 on the bull rush at 2 charges or +2 at 3 charges. The ring can also open doors as if it were a character with Strength 25 (Strength 27 at 2 charges, Strength 29 at 3 charges).\n\nA newly created ring has 50 charges. When all the charges are expended, the ring becomes a nonmagical item.\n\nModerate transmutation; CL 9th; Forge Ring, bull's strength, telekinesis; Price 8,600 gp." },
  "Animal friendship": { price: 10800, description: "On command, this ring affects an animal as if the wearer had cast charm animal.\n\nFaint enchantment; CL 3rd; Forge Ring, charm animal; Price 10,800 gp." },
  "Energy resistance, minor": { price: 12000, randomRoll: "energy type (acid, cold, electricity, fire, or sonic)",
    description: "This reddish iron ring continually protects the wearer from damage from one type of energy—acid, cold, electricity, fire, or sonic (chosen by the creator of the item; determine randomly if found as part of a treasure hoard). Each time the wearer would normally take such damage, subtract the ring's resistance value from the damage dealt. A minor ring of energy resistance grants 10 points of resistance.\n\nFaint abjuration; CL 3rd; Forge Ring, resist energy; Price 12,000 gp." },
  "Energy resistance, major": { price: 28000, randomRoll: "energy type (acid, cold, electricity, fire, or sonic)",
    description: "This reddish iron ring continually protects the wearer from damage from one type of energy—acid, cold, electricity, fire, or sonic (chosen by the creator; determine randomly if found as treasure). A major ring of energy resistance grants 20 points of resistance.\n\nFaint abjuration; CL 7th; Forge Ring, resist energy; Price 28,000 gp." },
  "Energy resistance, greater": { price: 44000, randomRoll: "energy type (acid, cold, electricity, fire, or sonic)",
    description: "This reddish iron ring continually protects the wearer from damage from one type of energy—acid, cold, electricity, fire, or sonic (chosen by the creator; determine randomly if found as treasure). A greater ring of energy resistance grants 30 points of resistance.\n\nModerate abjuration; CL 11th; Forge Ring, resist energy; Price 44,000 gp." },
  "Chameleon power": { price: 12700, description: "As a free action, the wearer of this ring can gain the ability to magically blend in with the surroundings. This provides a +10 competence bonus on her Hide checks. As a standard action, she can also command the ring to utilize the spell disguise self as often as she wants.\n\nFaint illusion; CL 3rd; Forge Ring, disguise self, invisibility; Price 12,700 gp." },
  "Water walking": { price: 15000, description: "This ring, set with an opal, allows the wearer to continually utilize the effects of the spell water walk.\n\nModerate transmutation; CL 9th; Forge Ring, water walk; Price 15,000 gp." },
  "Spell storing, minor": { price: 18000, randomRoll: "spells stored (treat as a scroll, up to 3 spell levels)",
    description: "A minor ring of spell storing contains up to three levels of spells that the wearer can cast. Each spell has a caster level equal to the minimum level needed to cast that spell. The user need not provide any material components or focus, or pay an XP cost to cast the spell, and there is no arcane spell failure chance for wearing armor. The activation time for the ring is the same as the casting time for the relevant spell, with a minimum of 1 standard action.\n\nFor a randomly generated ring, treat it as a scroll to determine what spells are stored in it. If you roll a spell that would put the ring over the three-level limit, ignore that roll; the ring has no more spells in it. (Not every newly discovered ring need be fully charged.)\n\nFaint evocation; CL 5th; Forge Ring, imbue with spell ability; Price 18,000 gp." },
  "Spell storing": { price: 50000, randomRoll: "spells stored (treat as a scroll, up to 5 spell levels)",
    description: "As the minor ring of spell storing, except it holds up to five levels of spells.\n\nFor a randomly generated ring, treat it as a scroll to determine what spells are stored in it. If you roll a spell that would put the ring over the five-level limit, ignore that roll.\n\nModerate evocation; CL 9th; Forge Ring, imbue with spell ability; Price 50,000 gp." },
  "Spell storing, major": { price: 200000, randomRoll: "spells stored (treat as a scroll, up to 10 spell levels)",
    description: "As the minor ring of spell storing, except it holds up to ten levels of spells.\n\nFor a randomly generated ring, treat it as a scroll to determine what spells are stored in it. If you roll a spell that would put the ring over the ten-level limit, ignore that roll.\n\nStrong evocation; CL 17th; Forge Ring, imbue with spell ability; Price 200,000 gp." },
  "Invisibility": { price: 20000, description: "By activating this simple silver ring, the wearer can benefit from invisibility, as the spell.\n\nFaint illusion; CL 3rd; Forge Ring, invisibility; Price 20,000 gp." },
  "Wizardry I": { price: 20000, description: "This special ring is useful only to arcane spellcasters. The wearer's arcane spells per day are doubled for 1st-level spells. Bonus spells from high ability scores or school specialization are not doubled.\n\nModerate (no school); CL 11th; Forge Ring, limited wish; Price 20,000 gp." },
  "Wizardry II": { price: 40000, description: "This special ring is useful only to arcane spellcasters. The wearer's arcane spells per day are doubled for 2nd-level spells. Bonus spells from high ability scores or school specialization are not doubled.\n\nStrong (no school); CL 14th; Forge Ring, limited wish; Price 40,000 gp." },
  "Wizardry III": { price: 70000, description: "This special ring is useful only to arcane spellcasters. The wearer's arcane spells per day are doubled for 3rd-level spells. Bonus spells from high ability scores or school specialization are not doubled.\n\nStrong (no school); CL 17th; Forge Ring, limited wish; Price 70,000 gp." },
  "Wizardry IV": { price: 100000, description: "This special ring is useful only to arcane spellcasters. The wearer's arcane spells per day are doubled for 4th-level spells. Bonus spells from high ability scores or school specialization are not doubled.\n\nStrong (no school); CL 20th; Forge Ring, limited wish; Price 100,000 gp." },
  "Evasion": { price: 25000, description: "This ring continually grants the wearer the ability to avoid damage as if she had evasion. Whenever she makes a Reflex saving throw to determine whether she takes half damage, a successful save results in no damage.\n\nModerate transmutation; CL 7th; Forge Ring, jump; Price 25,000 gp." },
  "X-ray vision": { price: 25000, description: "On command, this ring gives its possessor the ability to see into and through solid matter. Vision range is 20 feet. X-ray vision can penetrate 1 foot of stone, 1 inch of common metal, or up to 3 feet of wood or dirt. Thicker substances or a thin sheet of lead blocks the vision.\n\nUsing the ring is physically exhausting, causing the wearer 1 point of Constitution damage per minute after the first 10 minutes of use in a single day.\n\nModerate divination; CL 6th; Forge Ring, true seeing; Price 25,000 gp." },
  "Blinking": { price: 27000, description: "On command, this ring makes the wearer blink, as with the blink spell.\n\nModerate transmutation; CL 7th; Forge Ring, blink; Price 27,000 gp." },
  "Meld into stone": { price: 27000, description: "This ring allows the wearer to use the spell meld into stone on command.\n\nFaint enchantment; CL 5th; Forge Ring, meld into stone; Price 27,000 gp." },
  "Freedom of movement": { price: 40000, description: "This gold ring allows the wearer to act as if continually under the effect of a freedom of movement spell.\n\nModerate abjuration; CL 7th; Forge Ring, freedom of movement; Price 40,000 gp." },
  "Friend shield (pair)": { price: 50000, description: "These curious rings always come in pairs. A friend shield ring without its mate is useless. Either wearer of one of a pair of the rings can, at any time, command his or her ring to cast a shield other spell with the wearer of the mated ring as the recipient. This effect has no range limitation.\n\nModerate abjuration; CL 10th; Forge Ring, shield other; Price 50,000 gp (for a pair)." },
  "Shooting stars": { price: 50000, description: "This ring has two modes of operation, one for being in shadowy darkness or outdoors at night and a second one when the wearer is underground or indoors at night.\n\nOutdoors at night or in shadow/darkness: dancing lights (once per hour), light (twice per night), ball lightning (special, once per night; one to four balls of 1d6/2d6/3d6/4d6 electricity each for 4/3/2/1 balls, 120-ft range, 4 rounds, 5-ft radius), and shooting stars (special, three per week; 12 points impact damage plus a 5-ft-radius fire spread for 24 points fire damage, DC 13 Reflex).\n\nIndoors at night or underground: faerie fire (twice per day) and spark shower (special, once per day; a 20-ft arc 10 ft wide dealing 2d8 damage, or 4d8 to those wearing metal armour or carrying a metal weapon).\n\nStrong evocation; CL 12th; Forge Ring, light, faerie fire, fireball, lightning bolt; Price 50,000 gp." },
  "Telekinesis": { price: 75000, description: "This ring allows the wearer to use the spell telekinesis on command.\n\nModerate transmutation; CL 9th; Forge Ring, telekinesis; Price 75,000 gp." },
  "Regeneration": { price: 90000, description: "This white gold ring continually allows a living wearer to heal 1 point of damage per level every hour rather than every day. (This ability cannot be aided by the Heal skill.) Nonlethal damage heals at a rate of 1 point of damage per level every 5 minutes. If the wearer loses a limb, an organ, or any other body part while wearing this ring, the ring regenerates it as the spell. In either case, only damage taken while wearing the ring is regenerated.\n\nStrong conjuration; CL 15th; Forge Ring, regenerate; Price 90,000 gp." },
  "Three wishes": { price: 97950, randomRoll: "1d3 remaining rubies (wishes)",
    description: "This ring is set with three rubies. Each ruby stores a wish spell, activated by the ring. When a wish is used, that ruby disappears. For a randomly generated ring, roll 1d3 to determine the remaining number of rubies. When all the wishes are used, the ring becomes a nonmagical item.\n\nStrong evocation (if miracle is used); CL 20th; Forge Ring, wish or miracle; Price 97,950 gp." },
  "Spell turning": { price: 98280, description: "Up to three times per day on command, this simple platinum band automatically reflects the next nine levels of spells cast at the wearer, exactly as if spell turning had been cast upon the wearer.\n\nStrong abjuration; CL 13th; Forge Ring, spell turning; Price 98,280 gp." },
  "Djinni calling": { price: 125000, description: "One of the many rings of fable, this 'genie' ring is most useful indeed. It serves as a special gate by means of which a specific djinni can be called from the Elemental Plane of Air. When the ring is rubbed (a standard action), the call goes out, and the djinni appears on the next round. The djinni faithfully obeys and serves the wearer of the ring, but never for more than 1 hour per day. If the djinni of the ring is ever killed, the ring becomes nonmagical and worthless.\n\nStrong conjuration; CL 17th; Forge Ring, gate; Price 125,000 gp." },
  "Elemental command (air)": { price: 200000, description: "All four kinds of elemental command rings are very powerful. Each appears to be nothing more than a lesser magic ring until fully activated, but each has certain other powers as well as the following common properties. Elementals of the plane to which the ring is attuned can't attack the wearer, or even approach within 5 feet of him. If the wearer desires, he may forego this protection and instead attempt to charm the elemental (as charm monster, Will DC 17 negates); if the charm attempt fails, absolute protection is lost. Creatures from that plane who attack the wearer take a -1 penalty on attack rolls; the wearer gains a +2 resistance bonus on applicable saves against them, a +4 morale bonus on attack rolls against them, and any weapon he uses bypasses their damage reduction. The wearer is able to converse with creatures from that plane. The possessor takes a -2 saving throw penalty against earth-based effects.\n\nPowers: feather fall (unlimited, wearer only), resist energy (electricity) (unlimited, wearer only), gust of wind (2/day), wind wall (unlimited), air walk (1/day, wearer only), chain lightning (1/week).\n\nThe ring appears to be a ring of feather falling until a certain condition is met to activate its full potential.\n\nStrong conjuration; CL 15th; Forge Ring, summon monster VI, all appropriate spells; Price 200,000 gp." },
  "Elemental command (earth)": { price: 200000, description: "See ring of elemental command (air) for the common properties. The possessor takes a -2 saving throw penalty against air- or electricity-based effects.\n\nPowers: meld into stone (unlimited, wearer only), soften earth and stone (unlimited), stone shape (2/day), stoneskin (1/week, wearer only), passwall (2/week), wall of stone (1/day).\n\nThe ring appears to be a ring of meld into stone until the established condition is met.\n\nStrong conjuration; CL 15th; Forge Ring, summon monster VI, all appropriate spells; Price 200,000 gp." },
  "Elemental command (fire)": { price: 200000, description: "See ring of elemental command (air) for the common properties. The possessor takes a -2 saving throw penalty against water- or cold-based effects.\n\nPowers: resist energy (fire) (as a major ring of energy resistance [fire]), burning hands (unlimited), flaming sphere (2/day), pyrotechnics (2/day), wall of fire (1/day), flame strike (2/week).\n\nThe ring appears to be a major ring of energy resistance (fire) until the established condition is met.\n\nStrong conjuration; CL 15th; Forge Ring, summon monster VI, all appropriate spells; Price 200,000 gp." },
  "Elemental command (water)": { price: 200000, description: "See ring of elemental command (air) for the common properties. The possessor takes a -2 saving throw penalty against fire-based effects.\n\nPowers: water walk (unlimited), create water (unlimited), water breathing (unlimited), wall of ice (1/day), ice storm (2/week), control water (2/week).\n\nThe ring appears to be a ring of water walking until the established condition is met.\n\nStrong conjuration; CL 15th; Forge Ring, summon monster VI, all appropriate spells; Price 200,000 gp." },
};

// SRD: "Special Qualities: Roll d%. A result of 01 indicates the ring is
// intelligent, 02-31 indicates that something (a design, inscription, or the
// like) provides a clue to its function, and 32-100 indicates no special
// qualities." Rings with charges can never be intelligent.
export const ringSpecialQualities: { min: number; max: number; result: string }[] = [
  { min: 1, max: 1, result: "Intelligent" },
  { min: 2, max: 31, result: "A design, inscription, or the like provides a clue to its function" },
  { min: 32, max: 100, result: "No special qualities" },
];

// ============================================================
// RODS — verbatim Table: Rods
// ============================================================
export interface RodEntry {
  min: number;
  max: number;
  name: string;
  price: number;
  charges?: number; // explicit SRD charge count, if any
  chargeRule?: string; // SRD charge rule text
  randomRoll?: string;
  description: string;
}

export const rodTable: Record<"medium" | "major", { min: number; max: number; name: string }[]> = {
  medium: [
    { min: 1, max: 7, name: "Metamagic, Enlarge, lesser" },
    { min: 8, max: 14, name: "Metamagic, Extend, lesser" },
    { min: 15, max: 21, name: "Metamagic, Silent, lesser" },
    { min: 22, max: 28, name: "Immovable" },
    { min: 29, max: 35, name: "Metamagic, Empower, lesser" },
    { min: 36, max: 42, name: "Metal and mineral detection" },
    { min: 43, max: 53, name: "Cancellation" },
    { min: 54, max: 57, name: "Metamagic, Enlarge" },
    { min: 58, max: 61, name: "Metamagic, Extend" },
    { min: 62, max: 65, name: "Metamagic, Silent" },
    { min: 66, max: 71, name: "Wonder" },
    { min: 72, max: 79, name: "Python" },
    { min: 80, max: 83, name: "Metamagic, Maximize, lesser" },
    { min: 84, max: 89, name: "Flame extinguishing" },
    { min: 90, max: 97, name: "Viper" },
    { min: 98, max: 99, name: "Metamagic, Empower" },
    { min: 100, max: 100, name: "Metamagic, Quicken, lesser" },
  ],
  major: [
    { min: 1, max: 4, name: "Cancellation" },
    { min: 5, max: 6, name: "Metamagic, Enlarge" },
    { min: 7, max: 8, name: "Metamagic, Extend" },
    { min: 9, max: 10, name: "Metamagic, Silent" },
    { min: 11, max: 14, name: "Wonder" },
    { min: 15, max: 18, name: "Python" },
    { min: 19, max: 21, name: "Flame extinguishing" },
    { min: 22, max: 25, name: "Viper" },
    { min: 26, max: 30, name: "Enemy detection" },
    { min: 31, max: 36, name: "Metamagic, Enlarge, greater" },
    { min: 37, max: 42, name: "Metamagic, Extend, greater" },
    { min: 43, max: 48, name: "Metamagic, Silent, greater" },
    { min: 49, max: 53, name: "Splendor" },
    { min: 54, max: 58, name: "Withering" },
    { min: 59, max: 64, name: "Metamagic, Empower" },
    { min: 65, max: 69, name: "Thunder and lightning" },
    { min: 70, max: 73, name: "Metamagic, Quicken, lesser" },
    { min: 74, max: 77, name: "Negation" },
    { min: 78, max: 80, name: "Absorption" },
    { min: 81, max: 84, name: "Flailing" },
    { min: 85, max: 86, name: "Metamagic, Maximize" },
    { min: 87, max: 88, name: "Rulership" },
    { min: 89, max: 90, name: "Security" },
    { min: 91, max: 92, name: "Lordly might" },
    { min: 93, max: 94, name: "Metamagic, Empower, greater" },
    { min: 95, max: 96, name: "Metamagic, Quicken" },
    { min: 97, max: 98, name: "Alertness" },
    { min: 99, max: 99, name: "Metamagic, Maximize, greater" },
    { min: 100, max: 100, name: "Metamagic, Quicken, greater" },
  ],
};

const mw = (feat: string, lesser: number, normal: number, greater: number) => ({
  description:
    `The wielder can cast up to three spells per day that are affected as though using the ${feat} feat, without changing the spell slot of the altered spell.\n\nNormal metamagic rods can be used with spells of 6th level or lower. Lesser rods can be used with spells of 3rd level or lower, while greater rods can be used with spells of 9th level or lower.\n\nStrong (no school); CL 17th; Craft Rod, ${feat}; Price ${lesser.toLocaleString()} gp (lesser), ${normal.toLocaleString()} gp (normal), ${greater.toLocaleString()} gp (greater).`,
});

export const rodDetails: Record<string, { price: number; charges?: number; chargeRule?: string; randomRoll?: string; description: string }> = {
  "Metamagic, Enlarge, lesser": { price: 3000, ...mw("Enlarge Spell", 3000, 11000, 24500) },
  "Metamagic, Extend, lesser": { price: 3000, ...mw("Extend Spell", 3000, 11000, 24500) },
  "Metamagic, Silent, lesser": { price: 3000, ...mw("Silent Spell", 3000, 11000, 24500) },
  "Metamagic, Empower, lesser": { price: 9000, ...mw("Empower Spell", 9000, 32500, 73000) },
  "Metamagic, Maximize, lesser": { price: 14000, ...mw("Maximize Spell", 14000, 54000, 121500) },
  "Metamagic, Quicken, lesser": { price: 35000, ...mw("Quicken Spell", 35000, 75500, 170000) },
  "Metamagic, Enlarge": { price: 11000, ...mw("Enlarge Spell", 3000, 11000, 24500) },
  "Metamagic, Extend": { price: 11000, ...mw("Extend Spell", 3000, 11000, 24500) },
  "Metamagic, Silent": { price: 11000, ...mw("Silent Spell", 3000, 11000, 24500) },
  "Metamagic, Empower": { price: 32500, ...mw("Empower Spell", 9000, 32500, 73000) },
  "Metamagic, Maximize": { price: 54000, ...mw("Maximize Spell", 14000, 54000, 121500) },
  "Metamagic, Quicken": { price: 75500, ...mw("Quicken Spell", 35000, 75500, 170000) },
  "Metamagic, Enlarge, greater": { price: 24500, ...mw("Enlarge Spell", 3000, 11000, 24500) },
  "Metamagic, Extend, greater": { price: 24500, ...mw("Extend Spell", 3000, 11000, 24500) },
  "Metamagic, Silent, greater": { price: 24500, ...mw("Silent Spell", 3000, 11000, 24500) },
  "Metamagic, Empower, greater": { price: 73000, ...mw("Empower Spell", 9000, 32500, 73000) },
  "Metamagic, Maximize, greater": { price: 121500, ...mw("Maximize Spell", 14000, 54000, 121500) },
  "Metamagic, Quicken, greater": { price: 170000, ...mw("Quicken Spell", 35000, 75500, 170000) },
  "Immovable": { price: 5000,
    description: "This rod is a flat iron bar with a small button on one end. When the button is pushed (a move action), the rod does not move from where it is, even if staying in place defies gravity. An immovable rod can support up to 8,000 pounds before falling to the ground. If a creature pushes against an immovable rod, it must make a DC 30 Strength check to move the rod up to 10 feet in a single round.\n\nModerate transmutation; CL 10th; Craft Rod, levitate; Price 5,000 gp." },
  "Metal and mineral detection": { price: 10500,
    description: "This rod pulses in the wielder's hand and points to the largest mass of metal within 30 feet. However, the wielder can concentrate on a specific metal or mineral. If the specific mineral is within 30 feet, the rod points to any places it is located, and the rod wielder knows the approximate quantity as well. Each operation requires a full-round action.\n\nModerate divination; CL 9th; Craft Rod, locate object; Price 10,500 gp." },
  "Cancellation": { price: 11000,
    description: "This dreaded rod is a bane to magic items, for its touch drains an item of all magical properties. The item touched must make a DC 23 Will save to prevent the rod from draining it. If a creature is holding it at the time, then the item can use the holder's Will save bonus in place of its own if the holder's is better. In such cases, contact is made by making a melee touch attack roll. Upon draining an item, the rod itself becomes brittle and cannot be used again. Drained items are only restorable by wish or miracle.\n\nStrong abjuration; CL 17th; Craft Rod, mage's disjunction; Price 11,000 gp." },
  "Wonder": { price: 12000, randomRoll: "1d100 Rod of Wonder effect",
    description: "A rod of wonder is a strange and unpredictable device that randomly generates any number of weird effects each time it is used. (Activating the rod is a standard action.) Typical powers: slow creature pointed at for 10 rounds (Will DC 15 negates) 01-05; faerie fire surrounds the target 06-10; deludes wielder for 1 round 11-15; gust of wind at windstorm force (Fort DC 14) 16-20; wielder learns target's surface thoughts for 1d4 rounds 21-25; stinking cloud at 30-ft range (Fort DC 15) 26-30; heavy rain for 1 round in 60-ft radius 31-33; summon an animal—rhino (01-25), elephant (26-50), or mouse (51-100) 34-36; lightning bolt 6d6 (Reflex DC 15 half) 37-46; stream of 600 large butterflies blinding everyone within 25 ft (Reflex DC 14) 47-49; enlarge person (Fort DC 13) 50-53; darkness, 30-ft hemisphere 54-58; grass grows in 160-sq-ft area 59-62; turn ethereal any nonliving object up to 1,000 lb and 30 cu ft 63-65; reduce wielder to 1/12 height (no save) 66-69; fireball 6d6 (Reflex DC 15 half) 70-79; invisibility covers wielder 80-84; leaves grow from target, lasting 24 hours 85-87; 10-40 gems of 1 gp value shoot forth in a 30-ft stream (5d4 hits) 88-90; shimmering colors blind for 1d6 rounds (Fort DC 15) 91-95; wielder or target turns permanently blue, green, or purple (no save) 96-97; flesh to stone / stone to flesh (Fort DC 18) 98-100.\n\nModerate enchantment; CL 10th; Craft Rod, confusion, creator must be chaotic; Price 12,000 gp." },
  "Python": { price: 13000,
    description: "This rod is longer than normal rods. It is about 4 feet long and weighs 10 pounds. It strikes as a +1/+1 quarterstaff. If the user throws the rod to the ground (a standard action), it grows to become a giant constrictor snake by the end of the round. The python obeys all commands of the owner. (In animal form, it retains the +1 enhancement bonus on attacks and damage possessed by the rod form.) The serpent returns to rod form (a full-round action) whenever the wielder desires, or whenever it moves farther than 100 feet from the owner. If the snake form is slain, it returns to rod form and cannot be activated again for three days. A python rod only functions if the possessor is good.\n\nModerate transmutation; CL 10th; Craft Rod, Craft Magic Arms and Armor, baleful polymorph, creator must be good; Price 13,000 gp." },
  "Flame extinguishing": { price: 15000, charges: 10, chargeRule: "has 10 charges when found; spent charges renew every day",
    description: "This rod can extinguish Medium or smaller nonmagical fires with simply a touch (a standard action). Extinguishing a Large or larger nonmagical fire, or a magic fire of Medium or smaller, expends 1 charge. To extinguish an instantaneous fire spell, the rod must be within the area of the effect and the wielder must have used a ready action. Applied to Large or larger magic fires, extinguishing the flames expends 2 charges. If the device is used upon a fire creature (a melee touch attack), it deals 6d6 points of damage; this use requires 3 charges.\n\nA rod of flame extinguishing has 10 charges when found. Spent charges are renewed every day.\n\nStrong transmutation; CL 12th; Craft Rod, pyrotechnics; Price 15,000 gp." },
  "Viper": { price: 19000,
    description: "This rod strikes as a +2 heavy mace. Once per day, upon command, the head of the rod becomes that of an actual serpent for 10 minutes. During this period, any successful strike with the rod deals its usual damage and also poisons the creature hit. The poison deals 1d10 points of Constitution damage immediately (Fortitude DC 14 negates) and another 1d10 points of Constitution damage 1 minute later (Fortitude DC 14 negates). The rod only functions if its possessor is evil.\n\nModerate necromancy; CL 10th; Craft Rod, Craft Magic Arms and Armor, poison, creator must be evil; Price 19,000 gp." },
  "Enemy detection": { price: 23500,
    description: "This device pulses in the wielder's hand and points in the direction of any creature or creatures hostile to the bearer of the device (nearest ones first). These creatures can be invisible, ethereal, hidden, disguised, or in plain sight. Detection range is 60 feet. If the bearer concentrates for a full round, the rod pinpoints the location of the nearest enemy and indicates how many enemies are within range. The rod can be used three times each day, each use lasting up to 10 minutes. Activating the rod is a standard action.\n\nModerate divination; CL 10th; Craft Rod, true seeing; Price 23,500 gp." },
  "Splendor": { price: 25000, randomRoll: "garb value 1d4+6 × 1,000 gp",
    description: "The possessor of this rod gains a +4 enhancement bonus to her Charisma score for as long as she holds or carries the item. Once per day, the rod creates and garbs her in clothing of the finest fabrics, plus adornments of furs and jewels. Apparel created remains for 12 hours. The value of noble garb created ranges from 7,000 to 10,000 gp (1d4+6 × 1,000 gp). Once per week, upon command, it creates a palatial tent—a huge pavilion of silk 60 feet across, sufficient to entertain as many as one hundred persons, lasting one day.\n\nStrong conjuration and transmutation; CL 12th; Craft Rod, eagle's splendor, fabricate, major creation; Price 25,000 gp." },
  "Withering": { price: 25000,
    description: "A rod of withering acts as a +1 light mace that deals no hit point damage. Instead, the wielder deals 1d4 points of Strength damage and 1d4 points of Constitution damage to any creature she touches with the rod (by making a melee touch attack). If she scores a critical hit, the damage from that hit is permanent ability drain. In either case, the defender negates the effect with a DC 17 Fortitude save.\n\nStrong necromancy; CL 13th; Craft Rod, Craft Magic Arms and Armor, contagion; Price 25,000 gp." },
  "Thunder and lightning": { price: 33000,
    description: "Constructed of iron set with silver rivets, this rod has the properties of a +2 light mace. Its other powers: thunder—once per day strike as a +3 light mace and the opponent is stunned from the noise (Fort DC 16 negates); lightning—once per day deal normal +2 light mace damage plus 2d6 electricity on a successful melee touch attack; thunderclap—once per day as a shout spell (Fort DC 16 partial, 2d6 sonic, deafened 2d6 rounds); lightning stroke—once per day a 5-ft-wide lightning bolt, 9d6 electricity (Reflex DC 16 half), range 200 feet; thunder and lightning—once per week combine thunderclap with the lightning stroke (single DC 16 Reflex save for both).\n\nModerate evocation; CL 9th; Craft Rod, Craft Magic Arms and Armor, lightning bolt, shout; Price 33,000 gp." },
  "Negation": { price: 37000,
    description: "This device negates the spell or spell-like function or functions of magic items. The wielder points the rod at the magic item, and a pale gray beam shoots forth to touch the target device, attacking as a ray (a ranged touch attack). The ray functions as a greater dispel magic spell, except it only affects magic items. The dispel check uses the rod's caster level (15th). The target item gets no saving throw, although the rod can't negate artifacts. The rod can function three times per day.\n\nStrong varied; CL 15th; Craft Rod, dispel magic, and limited wish or miracle; Price 37,000 gp." },
  "Absorption": { price: 50000, chargeRule: "roll d% and divide by 2 for remaining absorption potential (max 50); then roll d% again: on 71-100, half the levels already absorbed are still stored within",
    description: "This rod acts as a magnet, drawing spells or spell-like abilities into itself. The magic absorbed must be a single-target spell or a ray directed at either the character possessing the rod or her gear. The rod then nullifies the spell's effect and stores its potential until the wielder releases this energy in the form of spells of her own. A running total of absorbed (and used) spell levels should be kept. The wielder can use captured spell energy to cast any spell she has prepared, without expending the preparation itself. A rod of absorption absorbs a maximum of fifty spell levels and can thereafter only discharge any remaining potential. The rod cannot be recharged.\n\nTo determine the absorption potential remaining in a newly found rod, roll d% and divide the result by 2. Then roll d% again: on a result of 71-100, half the levels already absorbed by the rod are still stored within.\n\nStrong abjuration; CL 15th; Craft Rod, spell turning; Price 50,000 gp." },
  "Flailing": { price: 50000,
    description: "Upon the command of its possessor, the rod activates, changing from a normal-seeming rod to a +3 dire flail. The dire flail is a double weapon. The wielder can gain an extra attack (with the second head) at the cost of making all attacks at a -2 penalty. Once per day the wielder can use a free action to cause the rod to grant her a +4 deflection bonus to Armor Class and a +4 resistance bonus on saving throws for 10 minutes. Transforming it into a weapon or back into a rod is a move action.\n\nModerate enchantment; CL 9th; Craft Rod, Craft Magic Arms and Armor, bless; Price 50,000 gp." },
  "Rulership": { price: 60000,
    description: "This rod looks like a royal scepter worth at least 5,000 gp in materials and workmanship alone. The wielder can command the obedience and fealty of creatures within 120 feet when she activates the device (a standard action). Creatures totaling 300 Hit Dice can be ruled, but creatures with Intelligence scores of 12 or higher are entitled to a DC 16 Will save to negate the effect. Ruled creatures obey the wielder as if she were their absolute sovereign. The rod can be used for 500 total minutes before crumbling to dust. This duration need not be continuous.\n\nStrong enchantment; CL 20th; Craft Rod, mass charm monster; Price 60,000 gp." },
  "Security": { price: 61000,
    description: "This item creates a nondimensional space, a pocket paradise. There the rod's possessor and as many as 199 other creatures can stay in complete safety for a period of time, up to 200 days divided by the number of creatures affected. In this pocket paradise, creatures don't age, and natural healing takes place at twice the normal rate. Fresh water and food are in abundance. Activating the rod (a standard action) causes the wielder and all creatures touching the rod to be transported instantaneously. Unwilling creatures get a DC 17 Will save to negate the effect. The rod can only be activated once per week.\n\nStrong conjuration; CL 20th; Craft Rod, gate; Price 61,000 gp." },
  "Lordly might": { price: 70000,
    description: "This rod has spell-like functions and can also be used as a magic weapon. It is metal, thicker than other rods, with a flanged ball at one end and six studlike buttons. It weighs 10 pounds.\n\nSpell-like functions (each 1/day): hold person upon touch (Will DC 14 negates); fear upon all enemies viewing it (10-ft range, Will DC 16 partial); deal 2d4 hit points of damage on a touch attack (Will DC 17 half) and cure the wielder of a like amount.\n\nWeapon functions (unlimited): +2 light mace in normal form; +1 flaming longsword (button 1); +4 battleaxe (button 2); +3 shortspear or +3 longspear, lengthening to 15 feet for use as a lance (button 3).\n\nOther functions (unlimited): climbing pole/ladder lengthening 5-50 feet, bearing up to 4,000 pounds (button 4); forcing doors with Strength modifier +12; indicating magnetic north and approximate depth or height (button 6).\n\nStrong enchantment, evocation, necromancy, and transmutation; CL 19th; Craft Rod, Craft Magic Arms and Armor, inflict light wounds, bull's strength, flame blade, hold person, fear; Price 70,000 gp." },
  "Alertness": { price: 85000,
    description: "This rod is indistinguishable from a +1 light mace. It has eight flanges on its macelike head. The rod bestows a +1 insight bonus on initiative checks. If grasped firmly, the rod enables the holder to use detect evil, detect good, detect chaos, detect law, detect magic, discern lies, light, or see invisibility (each a standard action).\n\nIf the head is planted in the ground and the possessor wills it to alertness (a standard action), the rod senses any creature within 120 feet who intends to harm the possessor, creates the effect of a prayer spell upon all friendly creatures in a 20-foot radius, and sends forth a mental alert to them. These effects last 10 minutes; usable once per day. The rod can also simulate animate objects using up to eleven Small objects; objects remain animated for 11 rounds; usable once per day.\n\nModerate abjuration, divination, enchantment, and evocation; CL 11th; Craft Rod, alarm, detect chaos, detect evil, detect good, detect law, detect magic, discern lies, light, see invisibility, prayer, animate objects; Price 85,000 gp." },
};

// SRD: "Roll d%. A 01 result indicates the rod is intelligent, 02-31 indicates
// that something (a design, inscription, or the like) provides a clue to its
// function, and 32-100 indicates no special qualities. Rods with charges can
// never be intelligent."
export const rodSpecialQualities: { min: number; max: number; result: string }[] = [
  { min: 1, max: 1, result: "Intelligent" },
  { min: 2, max: 31, result: "A design, inscription, or the like provides a clue to its function" },
  { min: 32, max: 100, result: "No special qualities" },
];
