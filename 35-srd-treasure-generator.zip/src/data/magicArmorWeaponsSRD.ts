// ============================================================================
// VERBATIM transcription of d20srd.org/srd/magicItems/magicArmor.htm
// and d20srd.org/srd/magicItems/magicWeapons.htm
// plus d20srd.org/srd/specialMaterials.htm
//
// These tables SUPERSEDE everything in magicItems.ts (armor/shield abilities)
// and magicWeapons.ts (weapon abilities / specific weapons).
// ============================================================================

export type Tier = "minor" | "medium" | "major";

// ---------------------------------------------------------------------------
// TABLE: ARMOR SPECIAL ABILITIES
// ---------------------------------------------------------------------------
export interface ArmorAbility {
  name: string;
  minor?: [number, number];
  medium?: [number, number];
  major?: [number, number];
  mod: string;        // "+2,700 gp" or "+1 bonus"
  bonusEq?: number;   // set when mod is "+N bonus"
  fixedGP?: number;   // set when mod is "+N gp"
  aura: string;
  cl: number;
  description: string;
  restriction?: string;
}

export const armorAbilitiesSRD: ArmorAbility[] = [
  { name: "Glamered", minor: [1,25], medium: [1,5], major: [1,3], mod: "+2,700 gp", fixedGP: 2700,
    aura: "Moderate illusion", cl: 10,
    description: "A suit of armor with this ability appears normal. Upon command, the armor changes shape and form to assume the appearance of a normal set of clothing. The armor retains all its properties (including weight) when glamered. Only a true seeing spell or similar magic reveals the true nature of the armor when disguised." },
  { name: "Fortification, light", minor: [26,32], medium: [6,8], major: [4,4], mod: "+1 bonus", bonusEq: 1,
    aura: "Strong abjuration", cl: 13,
    description: "This suit of armor produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. LIGHT fortification negates on a 25% chance." },
  { name: "Slick", minor: [33,52], medium: [9,11], mod: "+3,750 gp", fixedGP: 3750,
    aura: "Faint conjuration", cl: 4,
    description: "Slick armor seems coated at all times with a slightly greasy oil. It provides a +5 competence bonus on its wearer's Escape Artist checks. (The armor's armor check penalty still applies normally.)" },
  { name: "Shadow", minor: [53,72], medium: [12,14], mod: "+3,750 gp", fixedGP: 3750,
    aura: "Faint illusion", cl: 5,
    description: "This armor is jet black and blurs the wearer whenever she tries to hide, granting a +5 competence bonus on Hide checks. (The armor's armor check penalty still applies normally.)" },
  { name: "Silent moves", minor: [73,92], medium: [15,17], mod: "+3,750 gp", fixedGP: 3750,
    aura: "Faint illusion", cl: 5,
    description: "This armor is well oiled and magically constructed so that it not only makes little sound, but it dampens sound around it. It provides a +5 competence bonus on its wearer's Move Silently checks. (The armor's armor check penalty still applies normally.)" },
  { name: "Spell resistance (13)", minor: [93,96], medium: [18,19], mod: "+2 bonus", bonusEq: 2,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the armor's wearer spell resistance 13 while the armor is worn." },
  { name: "Slick, improved", minor: [97,97], medium: [20,29], major: [5,7], mod: "+15,000 gp", fixedGP: 15000,
    aura: "Moderate conjuration", cl: 10,
    description: "As slick, except it grants a +10 competence bonus on Escape Artist checks." },
  { name: "Shadow, improved", minor: [98,98], medium: [30,39], major: [8,10], mod: "+15,000 gp", fixedGP: 15000,
    aura: "Moderate illusion", cl: 10,
    description: "As shadow, except it grants a +10 competence bonus on Hide checks." },
  { name: "Silent moves, improved", minor: [99,99], medium: [40,49], major: [11,13], mod: "+15,000 gp", fixedGP: 15000,
    aura: "Moderate illusion", cl: 10,
    description: "As silent moves, except it grants a +10 competence bonus on Move Silently checks." },
  { name: "Acid resistance", medium: [50,54], major: [14,16], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A suit of armor or a shield with this property normally has a dull gray appearance. The armor absorbs the first 10 points of acid damage per attack that the wearer would normally take (similar to the resist energy spell)." },
  { name: "Cold resistance", medium: [55,59], major: [17,19], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A suit of armor or a shield with this property normally has a bluish, icy hue or is adorned with furs and shaggy pelts. The armor absorbs the first 10 points of cold damage per attack that the wearer would normally take." },
  { name: "Electricity resistance", medium: [60,64], major: [20,22], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A suit of armor or a shield with this property normally has a bluish hue and often bears a storm or lightning motif. The armor absorbs the first 10 points of electricity damage per attack." },
  { name: "Fire resistance", medium: [65,69], major: [23,25], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A suit of armor with this ability normally has a reddish hue and often is decorated with a draconic motif. The armor absorbs the first 10 points of fire damage per attack that the wearer would normally take." },
  { name: "Sonic resistance", medium: [70,74], major: [26,28], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A suit of armor or a shield with this property normally has a glistening appearance. The armor absorbs the first 10 points of sonic damage per attack that the wearer would normally take." },
  { name: "Ghost touch", medium: [75,79], major: [29,33], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong transmutation", cl: 15,
    description: "This armor or shield seems almost translucent. Both its enhancement bonus and its armor bonus count against the attacks of incorporeal creatures. It can be picked up, moved, and worn by incorporeal creatures at any time. Incorporeal creatures gain the armor or shield's enhancement bonus against both corporeal and incorporeal attacks, and they can still pass freely through solid objects." },
  { name: "Invulnerability", medium: [80,84], major: [34,35], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong abjuration and perhaps evocation (if miracle is used)", cl: 18,
    description: "This suit of armor grants the wearer damage reduction of 5/magic." },
  { name: "Fortification, moderate", medium: [85,89], major: [36,40], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong abjuration", cl: 13,
    description: "This suit of armor produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. MODERATE fortification negates on a 75% chance." },
  { name: "Spell resistance (15)", medium: [90,94], major: [41,42], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the armor's wearer spell resistance 15 while the armor is worn." },
  { name: "Wild", medium: [95,99], major: [43,43], mod: "+3 bonus", bonusEq: 3,
    aura: "Moderate transmutation", cl: 9,
    description: "The wearer of a suit of armor or a shield with this ability preserves his armor bonus (and any enhancement bonus) while in a wild shape. Armor and shields with this ability usually appear to be covered in leaf patterns. While the wearer is in a wild shape, the armor cannot be seen." },
  { name: "Slick, greater", major: [44,48], mod: "+33,750 gp", fixedGP: 33750,
    aura: "Moderate conjuration", cl: 15,
    description: "As slick, except it grants a +15 competence bonus on Escape Artist checks." },
  { name: "Shadow, greater", major: [49,53], mod: "+33,750 gp", fixedGP: 33750,
    aura: "Moderate illusion", cl: 15,
    description: "As shadow, except it grants a +15 competence bonus on Hide checks." },
  { name: "Silent moves, greater", major: [54,58], mod: "+33,750 gp", fixedGP: 33750,
    aura: "Moderate illusion", cl: 15,
    description: "As silent moves, except it grants a +15 competence bonus on Move Silently checks." },
  { name: "Acid resistance, improved", major: [59,63], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As acid resistance, except it absorbs the first 20 points of acid damage per attack." },
  { name: "Cold resistance, improved", major: [64,68], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As cold resistance, except it absorbs the first 20 points of cold damage per attack." },
  { name: "Electricity resistance, improved", major: [69,73], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As electricity resistance, except it absorbs the first 20 points of electricity damage per attack." },
  { name: "Fire resistance, improved", major: [74,78], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As fire resistance, except it absorbs the first 20 points of fire damage per attack." },
  { name: "Sonic resistance, improved", major: [79,83], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As sonic resistance, except it absorbs the first 20 points of sonic damage per attack." },
  { name: "Spell resistance (17)", major: [84,88], mod: "+4 bonus", bonusEq: 4,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the armor's wearer spell resistance 17 while the armor is worn." },
  { name: "Etherealness", major: [89,89], mod: "+49,000 gp", fixedGP: 49000,
    aura: "Strong transmutation", cl: 13,
    description: "On command, this ability allows the wearer of the armor to become ethereal (as the ethereal jaunt spell) once per day. The character can remain ethereal for as long as desired, but once he returns to normal, he cannot become ethereal again that day." },
  { name: "Undead controlling", major: [90,90], mod: "+49,000 gp", fixedGP: 49000,
    aura: "Strong necromancy", cl: 13,
    description: "The wearer of a suit of armor or a shield with this property may control up to 26 HD of undead per day, as the control undead spell. At dawn each day, the wearer loses control of any undead still under his sway. Armor or a shield with this ability appears to be made of bone; this feature is entirely decorative and has no other effect on the armor." },
  { name: "Fortification, heavy", major: [91,92], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong abjuration", cl: 13,
    description: "This suit of armor produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. HEAVY fortification negates on a 100% chance." },
  { name: "Spell resistance (19)", major: [93,94], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the armor's wearer spell resistance 19 while the armor is worn." },
  { name: "Acid resistance, greater", major: [95,95], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As acid resistance, except it absorbs the first 30 points of acid damage per attack." },
  { name: "Cold resistance, greater", major: [96,96], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As cold resistance, except it absorbs the first 30 points of cold damage per attack." },
  { name: "Electricity resistance, greater", major: [97,97], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As electricity resistance, except it absorbs the first 30 points of electricity damage per attack." },
  { name: "Fire resistance, greater", major: [98,98], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As fire resistance, except it absorbs the first 30 points of fire damage per attack." },
  { name: "Sonic resistance, greater", major: [99,99], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As sonic resistance, except it absorbs the first 30 points of sonic damage per attack." },
  { name: "Roll twice again", minor: [100,100], medium: [100,100], major: [100,100], mod: "—",
    aura: "Varies", cl: 0,
    description: "Roll twice more on this table. If you roll a special ability twice, only one counts. If you roll two versions of the same special ability, use the better." },
];

// ---------------------------------------------------------------------------
// TABLE: SHIELD SPECIAL ABILITIES
// ---------------------------------------------------------------------------
export const shieldAbilitiesSRD: ArmorAbility[] = [
  { name: "Arrow catching", minor: [1,20], medium: [1,10], major: [1,5], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate abjuration", cl: 8,
    description: "A shield with this ability attracts ranged weapons to it. It has a deflection bonus of +1 against ranged weapons because projectiles and thrown weapons veer toward it. Additionally, any projectile or thrown weapon aimed at a target within 5 feet of the shield's wearer diverts from its original target and targets the shield's bearer instead. (If the wielder has total cover relative to the attacker, the projectile or thrown weapon is not diverted.) Additionally, those attacking the wearer with ranged weapons ignore any miss chances that would normally apply. Projectiles and thrown weapons that have an enhancement bonus higher than the shield's base AC bonus are not diverted to the wearer (but the shield's increased AC bonus still applies against these weapons). The wielder can activate or deactivate this ability with a command word." },
  { name: "Bashing", minor: [21,40], medium: [11,20], major: [6,8], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 8,
    description: "A shield with this special ability is designed to perform a shield bash. A bashing shield deals damage as if it were a weapon of two size categories larger (a Medium light shield thus deals 1d6 points of damage and a Medium heavy shield deals 1d8 points of damage). The shield acts as a +1 weapon when used to bash. (Only light and heavy shields can have this ability.)",
    restriction: "Only light and heavy shields can have this ability." },
  { name: "Blinding", minor: [41,50], medium: [21,25], major: [9,10], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 7,
    description: "A shield with this ability flashes with a brilliant light up to twice per day upon command of the wielder. Anyone within 20 feet except the wielder must make a DC 14 Reflex save or be blinded for 1d4 rounds." },
  { name: "Fortification, light", minor: [51,75], medium: [26,40], major: [11,15], mod: "+1 bonus", bonusEq: 1,
    aura: "Strong abjuration", cl: 13,
    description: "This shield produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. LIGHT fortification negates on a 25% chance." },
  { name: "Arrow deflection", minor: [76,92], medium: [41,50], major: [16,20], mod: "+2 bonus", bonusEq: 2,
    aura: "Faint abjuration", cl: 5,
    description: "A shield with this ability protects the wielder from ranged attacks. Once per round when he would normally be struck by a ranged weapon, he can make a DC 20 Reflex save. If the ranged weapon has an enhancement bonus, the DC increases by that amount. If he succeeds, the shield deflects the weapon. He must be aware of the attack and not flat-footed. Attempting to deflect a ranged weapon doesn't count as an action. Exceptional ranged weapons, such as boulders hurled by giants or acid arrows, can't be deflected." },
  { name: "Animated", minor: [93,97], medium: [51,57], major: [21,25], mod: "+2 bonus", bonusEq: 2,
    aura: "Strong transmutation", cl: 12,
    description: "Upon command, an animated shield floats within 2 feet of the wielder, protecting her as if she were using it herself but freeing up both her hands. Only one shield can protect a character at a time. A character with an animated shield still takes any penalties associated with shield use, such as armor check penalty, arcane spell failure chance, and nonproficiency." },
  { name: "Spell resistance (13)", minor: [98,99], medium: [58,59], mod: "+2 bonus", bonusEq: 2,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the shield's wearer spell resistance 13 while the shield is worn." },
  { name: "Acid resistance", medium: [60,63], major: [26,28], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A shield with this property normally has a dull gray appearance. It absorbs the first 10 points of acid damage per attack that the wearer would normally take (similar to the resist energy spell)." },
  { name: "Cold resistance", medium: [64,67], major: [29,31], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A shield with this property normally has a bluish, icy hue or is adorned with furs and shaggy pelts. It absorbs the first 10 points of cold damage per attack that the wearer would normally take." },
  { name: "Electricity resistance", medium: [68,71], major: [32,34], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A shield with this property normally has a bluish hue and often bears a storm or lightning motif. It absorbs the first 10 points of electricity damage per attack." },
  { name: "Fire resistance", medium: [72,75], major: [35,37], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A shield with this property normally has a reddish hue and often is decorated with a draconic motif. It absorbs the first 10 points of fire damage per attack that the wearer would normally take." },
  { name: "Sonic resistance", medium: [76,79], major: [38,40], mod: "+18,000 gp", fixedGP: 18000,
    aura: "Faint abjuration", cl: 3,
    description: "A shield with this property normally has a glistening appearance. It absorbs the first 10 points of sonic damage per attack that the wearer would normally take." },
  { name: "Ghost touch", medium: [80,85], major: [41,46], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong transmutation", cl: 15,
    description: "This shield seems almost translucent. Both its enhancement bonus and its shield bonus count against the attacks of incorporeal creatures. It can be picked up, moved, and worn by incorporeal creatures at any time. Incorporeal creatures gain the shield's enhancement bonus against both corporeal and incorporeal attacks, and they can still pass freely through solid objects." },
  { name: "Fortification, moderate", medium: [86,95], major: [47,56], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong abjuration", cl: 13,
    description: "This shield produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. MODERATE fortification negates on a 75% chance." },
  { name: "Spell resistance (15)", medium: [96,98], major: [57,58], mod: "+3 bonus", bonusEq: 3,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the shield's wearer spell resistance 15 while the shield is worn." },
  { name: "Wild", medium: [99,99], major: [59,59], mod: "+3 bonus", bonusEq: 3,
    aura: "Moderate transmutation", cl: 9,
    description: "The wearer of a suit of armor or a shield with this ability preserves his armor bonus (and any enhancement bonus) while in a wild shape. Armor and shields with this ability usually appear to be covered in leaf patterns. While the wearer is in a wild shape, the armor cannot be seen." },
  { name: "Acid resistance, improved", major: [60,64], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As acid resistance, except it absorbs the first 20 points of acid damage per attack." },
  { name: "Cold resistance, improved", major: [65,69], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As cold resistance, except it absorbs the first 20 points of cold damage per attack." },
  { name: "Electricity resistance, improved", major: [70,74], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As electricity resistance, except it absorbs the first 20 points of electricity damage per attack." },
  { name: "Fire resistance, improved", major: [75,79], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As fire resistance, except it absorbs the first 20 points of fire damage per attack." },
  { name: "Sonic resistance, improved", major: [80,84], mod: "+42,000 gp", fixedGP: 42000,
    aura: "Moderate abjuration", cl: 7,
    description: "As sonic resistance, except it absorbs the first 20 points of sonic damage per attack." },
  { name: "Spell resistance (17)", major: [85,86], mod: "+4 bonus", bonusEq: 4,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the shield's wearer spell resistance 17 while the shield is worn." },
  { name: "Undead controlling", major: [87,87], mod: "+49,000 gp", fixedGP: 49000,
    aura: "Strong necromancy", cl: 13,
    description: "The wearer of a suit of armor or a shield with this property may control up to 26 HD of undead per day, as the control undead spell. At dawn each day, the wearer loses control of any undead still under his sway. Armor or a shield with this ability appears to be made of bone; this feature is entirely decorative and has no other effect on the armor." },
  { name: "Fortification, heavy", major: [88,91], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong abjuration", cl: 13,
    description: "This shield produces a magical force that protects vital areas of the wearer more effectively. When a critical hit or sneak attack is scored on the wearer, there is a chance that the critical hit or sneak attack is negated and damage is instead rolled normally. HEAVY fortification negates on a 100% chance." },
  { name: "Reflecting", major: [92,93], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong abjuration", cl: 14,
    description: "This shield seems like a mirror. Its surface is completely reflective. Once per day, it can be called on to reflect a spell back at its caster exactly like the spell turning spell." },
  { name: "Spell resistance (19)", major: [94,94], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong abjuration", cl: 15,
    description: "This property grants the shield's wearer spell resistance 19 while the shield is worn." },
  { name: "Acid resistance, greater", major: [95,95], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As acid resistance, except it absorbs the first 30 points of acid damage per attack." },
  { name: "Cold resistance, greater", major: [96,96], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As cold resistance, except it absorbs the first 30 points of cold damage per attack." },
  { name: "Electricity resistance, greater", major: [97,97], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As electricity resistance, except it absorbs the first 30 points of electricity damage per attack." },
  { name: "Fire resistance, greater", major: [98,98], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As fire resistance, except it absorbs the first 30 points of fire damage per attack." },
  { name: "Sonic resistance, greater", major: [99,99], mod: "+66,000 gp", fixedGP: 66000,
    aura: "Moderate abjuration", cl: 11,
    description: "As sonic resistance, except it absorbs the first 30 points of sonic damage per attack." },
  { name: "Roll twice again", minor: [100,100], medium: [100,100], major: [100,100], mod: "—",
    aura: "Varies", cl: 0,
    description: "Roll twice more on this table. If you roll a special ability twice, only one counts. If you roll two versions of the same special ability, use the better." },
];

// ---------------------------------------------------------------------------
// TABLE: MELEE WEAPON SPECIAL ABILITIES
// ---------------------------------------------------------------------------
export interface WeaponAbilitySRD {
  name: string;
  minor?: [number, number];
  medium?: [number, number];
  major?: [number, number];
  mod: string;
  bonusEq?: number;
  aura: string;
  cl: number;
  description: string;
  restriction?: string;
}

export const meleeWeaponAbilitiesSRD: WeaponAbilitySRD[] = [
  { name: "Bane", minor: [1,10], medium: [1,6], major: [1,3], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate conjuration", cl: 8,
    description: "A bane weapon excels at attacking one type or subtype of creature. Against its designated foe, its effective enhancement bonus is +2 better than its normal enhancement bonus. It deals an extra 2d6 points of damage against the foe. Bows, crossbows, and slings so crafted bestow the bane quality upon their ammunition. To randomly determine a weapon's designated foe, roll on the Bane designated-foe table (see baneFoeTable).",
    restriction: "Designated foe is rolled on baneFoeTable." },
  { name: "Defending", minor: [11,17], medium: [7,12], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate abjuration", cl: 8,
    description: "A defending weapon allows the wielder to transfer some or all of the sword's enhancement bonus to his AC as a bonus that stacks with all others. As a free action, the wielder chooses how to allocate the weapon's enhancement bonus at the start of his turn before using the weapon, and the effect to AC lasts until his next turn." },
  { name: "Flaming", minor: [18,27], medium: [13,19], major: [4,6], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 10,
    description: "A flaming weapon is sheathed in fire that burns those it strikes. It deals an extra 1d6 points of fire damage on a successful hit. The fire does not harm the wielder. The effect remains until dismissed. If the weapon is not drawn, the power is inactive." },
  { name: "Frost", minor: [28,37], medium: [20,26], major: [7,9], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 8,
    description: "This weapon is sheathed in a terrible, icy cold. It deals an extra 1d6 points of cold damage on a successful hit." },
  { name: "Shock", minor: [38,47], medium: [27,33], major: [10,12], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 8,
    description: "This weapon is sheathed in crackling electricity. It deals an extra 1d6 points of electricity damage on a successful hit." },
  { name: "Ghost touch", minor: [48,56], medium: [34,38], major: [13,15], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 15,
    description: "A ghost touch weapon has a physical existence out of phase with the world around it. It deals damage normally against incorporeal creatures, regardless of any miss chance those creatures may have, and it can be picked up and moved by an incorporeal creature at any time. A ghost touch weapon counts as a corporeal or incorporeal weapon, whichever is more beneficial to the wielder." },
  { name: "Keen", minor: [57,67], medium: [39,44], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 10,
    description: "When used in combat, this property doubles the threat range of the weapon. For example, a longsword usually threatens a critical on a roll of 19-20; with keen it threatens on 17-20. This increase in threat range stacks with Improved Critical, but effects that increase the threat range do not stack with each other.",
    restriction: "Piercing or slashing weapons only. Reroll if randomly generated for a bludgeoning weapon." },
  { name: "Ki focus", minor: [68,71], medium: [45,48], major: [16,19], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 12,
    description: "A ki focus weapon allows a wielder who has the Stunning Fist or Quivering Palm feat to use those attacks with the weapon, and a monk wielding it can use her monk abilities (such as flurry of blows) with the weapon as if it were an unarmed strike." },
  { name: "Merciful", minor: [72,75], medium: [49,50], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate conjuration", cl: 5,
    description: "The weapon deals an extra 1d6 points of nonlethal damage on a successful hit, and all damage it deals is nonlethal damage. The wielder can choose as a free action to suppress this ability, causing the weapon to deal lethal damage as normal." },
  { name: "Mighty cleaving", minor: [76,82], medium: [51,54], major: [20,21], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 8,
    description: "A mighty cleaving weapon allows the wielder to make one extra cleave attempt per round, as though she had the Cleave feat (even if she does not meet the prerequisites)." },
  { name: "Spell storing", minor: [83,87], medium: [55,59], major: [22,24], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 12,
    description: "A spell storing weapon allows a spellcaster to store a single targeted spell of up to 3rd level in the weapon. Any time the weapon strikes a creature and the creature takes damage from it, the weapon can immediately release the stored spell as a free action. The wielder does not need to cast the spell; it is released as if by the original caster. The spell is discharged automatically unless the wielder chooses to hold it." },
  { name: "Throwing", minor: [88,91], medium: [60,63], major: [25,28], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 5,
    description: "This weapon can be thrown at an opponent, dealing normal damage as a thrown weapon. It returns to the wielder after each attack, so she never risks losing it. The weapon has no maximum range increment penalty for being thrown." },
  { name: "Thundering", minor: [92,95], medium: [64,65], major: [29,32], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 10,
    description: "A thundering weapon creates a cacophony of thunder-like sound that can deafen those nearby. On a successful critical hit, the sound deals an extra 1d8 points of sonic damage and the target must make a DC 14 Fortitude save or be permanently deafened." },
  { name: "Vicious", minor: [96,99], medium: [66,69], major: [33,36], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate necromancy", cl: 9,
    description: "When this weapon deals damage to a foe, it also deals 1d6 points of damage to the wielder. The wielder cannot prevent this damage. The damage dealt to the wielder cannot be reduced or negated in any way." },
  { name: "Anarchic", medium: [70,72], major: [37,41], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [chaotic]", cl: 7,
    description: "An anarchic weapon is chaotically aligned and infused with the power of chaos. It makes the weapon chaos-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of lawful alignment. It bestows one negative level on any lawful creature attempting to wield it. The negative level remains as long as the weapon is in hand and disappears when the weapon is no longer wielded. This negative level never results in actual level loss, but it cannot be overcome in any way (including restoration spells) while the weapon is wielded. Bows, crossbows, and slings so crafted bestow the chaotic power upon their ammunition." },
  { name: "Axiomatic", medium: [73,75], major: [42,46], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [lawful]", cl: 7,
    description: "An axiomatic weapon is lawfully aligned and infused with the power of law. It makes the weapon law-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of chaotic alignment. It bestows one negative level on any chaotic creature attempting to wield it. The negative level remains as long as the weapon is in hand and disappears when the weapon is no longer wielded. Bows, crossbows, and slings so crafted bestow the lawful power upon their ammunition." },
  { name: "Disruption", medium: [76,78], major: [47,49], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate conjuration", cl: 14,
    description: "A weapon of disruption is the bane of all undead. Any undead creature struck by it must make a DC 16 Will save or take a -1 penalty on all attack rolls, saves, and checks for 1 round. On a successful critical hit against an undead, the target must make a DC 16 Will save or be destroyed.",
    restriction: "Bludgeoning weapons only. Reroll if randomly generated for a piercing or slashing weapon." },
  { name: "Flaming burst", medium: [79,81], major: [50,54], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 12,
    description: "A flaming burst weapon functions as a flaming weapon, but on a successful critical hit the burst of flame deals an extra 1d10 points of fire damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Icy burst", medium: [82,84], major: [55,59], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 10,
    description: "An icy burst weapon functions as a frost weapon, but on a successful critical hit the burst of cold deals an extra 1d10 points of cold damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Holy", medium: [85,87], major: [60,64], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [good]", cl: 7,
    description: "A holy weapon is good-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of evil alignment. It bestows one negative level on any evil creature attempting to wield it. The negative level remains as long as the weapon is in hand and disappears when the weapon is no longer wielded. Bows, crossbows, and slings so crafted bestow the good power upon their ammunition." },
  { name: "Shocking burst", medium: [88,90], major: [65,69], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 10,
    description: "A shocking burst weapon functions as a shock weapon, but on a successful critical hit the burst of electricity deals an extra 1d10 points of electricity damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Unholy", medium: [91,93], major: [70,74], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [evil]", cl: 7,
    description: "An unholy weapon is evil-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of good alignment. It bestows one negative level on any good creature attempting to wield it. The negative level remains as long as the weapon is in hand and disappears when the weapon is no longer wielded. Bows, crossbows, and slings so crafted bestow the evil power upon their ammunition." },
  { name: "Wounding", medium: [94,95], major: [75,78], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate necromancy", cl: 10,
    description: "A wounding weapon deals 1 point of Constitution damage from blood loss when it hits a creature. A critical hit does not multiply the Constitution damage. Creatures immune to critical hits are immune to the Constitution damage. The damage does not stack with itself on the same creature from the same weapon, but multiple wounding weapons do stack." },
  { name: "Speed", major: [79,83], mod: "+3 bonus", bonusEq: 3,
    aura: "Moderate transmutation", cl: 7,
    description: "When making a full attack action, the wielder of a speed weapon may make one extra attack with it. The attack uses the wielder's full base attack bonus, as normal, and is in addition to any other extra attacks granted by haste or similar effects (these do not stack)." },
  { name: "Brilliant energy", major: [84,86], mod: "+4 bonus", bonusEq: 4,
    aura: "Strong transmutation", cl: 16,
    description: "A brilliant energy weapon has its significant portion transformed into light, although this does not modify the item's weight. It always gives off light as a torch (20-foot radius). A brilliant energy weapon ignores nonliving matter. Armor and shield bonuses to AC (including any enhancement bonuses to that armor) do not count against it because the weapon passes through armor. (Dexterity, deflection, dodge, natural armor, and other such bonuses still apply.) A brilliant energy weapon cannot harm undead, constructs, and objects. This property can only be applied to melee weapons, thrown weapons, and ammunition.",
    restriction: "Cannot be applied to projectile weapons (bows, crossbows, slings)." },
  { name: "Dancing", major: [87,88], mod: "+4 bonus", bonusEq: 4,
    aura: "Strong transmutation", cl: 15,
    description: "As a standard action, a dancing weapon can be loosed to attack on its own. It fights for 4 rounds using the base attack bonus of the one who loosed it and then drops. While dancing, it cannot make attacks of opportunity, and the person who activated it is not considered armed with the weapon. In all other respects, it is considered wielded or attended by the creature for all maneuvers and effects that target items. While dancing, it takes up the same space as the activating character and can attack adjacent foes (weapons with reach can attack opponents up to 10 feet away). The dancing weapon accompanies the person who activated it everywhere. If the wielder who loosed it has an unoccupied hand, she can grasp it while it is attacking on its own as a free action; when so retrieved the weapon can't dance again for 4 rounds." },
  { name: "Vorpal", major: [89,90], mod: "+5 bonus", bonusEq: 5,
    aura: "Strong transmutation", cl: 18,
    description: "This potent and feared ability allows the weapon to sever the heads of those it strikes. On a successful critical hit against a creature with a head, it severs the head, killing the creature instantly. Some creatures, such as many aberrations and all oozes, have no heads. Others, such as golems and undead creatures other than vampires, are not affected by the loss of their heads. Most other creatures die when their heads are severed. Against creatures that are not affected by decapitation, a vorpal weapon functions as a keen weapon.",
    restriction: "Slashing weapons only. Reroll if randomly generated for a piercing or bludgeoning weapon." },
  { name: "Roll again twice", minor: [100,100], medium: [96,100], major: [91,100], mod: "—",
    aura: "Varies", cl: 0,
    description: "Roll twice more on this table, adding two more special abilities. Reroll if you get a duplicate special ability, an ability incompatible with one already rolled, or if the extra ability puts you over the +10 limit." },
];

// ---------------------------------------------------------------------------
// TABLE: RANGED WEAPON SPECIAL ABILITIES
// ---------------------------------------------------------------------------
export const rangedWeaponAbilitiesSRD: WeaponAbilitySRD[] = [
  { name: "Bane", minor: [1,12], medium: [1,8], major: [1,4], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate conjuration", cl: 8,
    description: "A bane weapon excels at attacking one type or subtype of creature. Against its designated foe, its effective enhancement bonus is +2 better than its normal enhancement bonus. It deals an extra 2d6 points of damage against the foe. Bows, crossbows, and slings so crafted bestow the bane quality upon their ammunition. Roll on baneFoeTable for the designated foe." },
  { name: "Distance", minor: [13,25], medium: [9,16], major: [5,8], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate divination", cl: 8,
    description: "This weapon doubles the range increment of the weapon it is applied to. Projectiles fired from it travel twice as far before suffering range penalties." },
  { name: "Flaming", minor: [26,40], medium: [17,28], major: [9,12], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 10,
    description: "Projectiles fired from this weapon are sheathed in fire. They deal an extra 1d6 points of fire damage on a successful hit. The fire does not harm the wielder or the weapon." },
  { name: "Frost", minor: [41,55], medium: [29,40], major: [13,16], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 8,
    description: "Projectiles fired from this weapon are sheathed in terrible, icy cold. They deal an extra 1d6 points of cold damage on a successful hit." },
  { name: "Merciful", minor: [56,60], medium: [41,42], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate conjuration", cl: 5,
    description: "Projectiles fired from this weapon deal an extra 1d6 points of nonlethal damage on a successful hit, and all damage dealt is nonlethal damage. The wielder can choose as a free action to suppress this ability." },
  { name: "Returning", minor: [61,68], medium: [43,47], major: [17,21], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate transmutation", cl: 6,
    description: "This weapon returns to the wielder after it is thrown, allowing it to be used again. It returns just before the wielder's next turn, regardless of whether it hit. (This ability cannot be applied to bows, crossbows, or slings.)",
    restriction: "Thrown weapons only; cannot be applied to bows, crossbows, or slings." },
  { name: "Shock", minor: [69,83], medium: [48,59], major: [22,25], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 8,
    description: "Projectiles fired from this weapon are sheathed in crackling electricity. They deal an extra 1d6 points of electricity damage on a successful hit." },
  { name: "Seeking", minor: [84,93], medium: [60,64], major: [26,27], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate divination", cl: 8,
    description: "A seeking weapon veers toward its intended target, negating any miss chance that would otherwise apply (such as from concealment or blur). It does not negate total concealment." },
  { name: "Thundering", minor: [94,99], medium: [65,68], major: [28,29], mod: "+1 bonus", bonusEq: 1,
    aura: "Moderate evocation", cl: 10,
    description: "Projectiles fired from this weapon create a cacophony of thunder-like sound. On a successful critical hit, the sound deals an extra 1d8 points of sonic damage and the target must make a DC 14 Fortitude save or be permanently deafened." },
  { name: "Anarchic", medium: [69,71], major: [30,34], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [chaotic]", cl: 7,
    description: "An anarchic weapon is chaotically aligned and infused with the power of chaos. It makes the weapon chaos-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of lawful alignment. It bestows one negative level on any lawful creature attempting to wield it. Bows, crossbows, and slings so crafted bestow the chaotic power upon their ammunition." },
  { name: "Axiomatic", medium: [72,74], major: [35,39], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [lawful]", cl: 7,
    description: "An axiomatic weapon is lawfully aligned and infused with the power of law. It makes the weapon law-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of chaotic alignment. It bestows one negative level on any chaotic creature attempting to wield it. Bows, crossbows, and slings so crafted bestow the lawful power upon their ammunition." },
  { name: "Flaming burst", medium: [75,79], major: [40,49], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 12,
    description: "A flaming burst weapon functions as a flaming weapon, but on a successful critical hit the burst of flame deals an extra 1d10 points of fire damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Holy", medium: [80,82], major: [50,54], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [good]", cl: 7,
    description: "A holy weapon is good-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of evil alignment. It bestows one negative level on any evil creature attempting to wield it. Bows, crossbows, and slings so crafted bestow the good power upon their ammunition." },
  { name: "Icy burst", medium: [83,87], major: [55,64], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 10,
    description: "An icy burst weapon functions as a frost weapon, but on a successful critical hit the burst of cold deals an extra 1d10 points of cold damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Shocking burst", medium: [88,92], major: [65,74], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation", cl: 10,
    description: "A shocking burst weapon functions as a shock weapon, but on a successful critical hit the burst of electricity deals an extra 1d10 points of electricity damage (this extra damage is not multiplied on a critical hit)." },
  { name: "Unholy", medium: [93,95], major: [75,79], mod: "+2 bonus", bonusEq: 2,
    aura: "Moderate evocation [evil]", cl: 7,
    description: "An unholy weapon is evil-aligned and thus bypasses the corresponding damage reduction. It deals an extra 2d6 points of damage against all of good alignment. It bestows one negative level on any good creature attempting to wield it. Bows, crossbows, and slings so crafted bestow the evil power upon their ammunition." },
  { name: "Speed", major: [80,84], mod: "+3 bonus", bonusEq: 3,
    aura: "Moderate transmutation", cl: 7,
    description: "When making a full attack action, the wielder of a speed weapon may make one extra attack with it. The attack uses the wielder's full base attack bonus, as normal. This does not stack with haste or similar effects." },
  { name: "Brilliant energy", major: [85,90], mod: "+4 bonus", bonusEq: 4,
    aura: "Strong transmutation", cl: 16,
    description: "A brilliant energy weapon has its significant portion transformed into light. It always gives off light as a torch (20-foot radius). A brilliant energy weapon ignores nonliving matter. Armor and shield bonuses to AC do not count against it. It cannot harm undead, constructs, and objects. This property can be applied to melee weapons, thrown weapons, and ammunition." },
  { name: "Roll again twice", minor: [100,100], medium: [96,100], major: [91,100], mod: "—",
    aura: "Varies", cl: 0,
    description: "Roll twice more on this table, adding two more special abilities. Reroll if you get a duplicate special ability, an ability incompatible with one already rolled, or if the extra ability puts you over the +10 limit." },
];

// ---------------------------------------------------------------------------
// BANE DESIGNATED FOE TABLE (also used for slaying arrows)
// ---------------------------------------------------------------------------
export const baneFoeTable: { min: number; max: number; label: string }[] = [
  { min: 1, max: 5, label: "Aberrations" },
  { min: 6, max: 9, label: "Animals" },
  { min: 10, max: 16, label: "Constructs" },
  { min: 17, max: 22, label: "Dragons" },
  { min: 23, max: 27, label: "Elementals" },
  { min: 28, max: 32, label: "Fey" },
  { min: 33, max: 39, label: "Giants" },
  { min: 40, max: 40, label: "Humanoids (aquatic)" },
  { min: 41, max: 42, label: "Humanoids (dwarf)" },
  { min: 43, max: 44, label: "Humanoids (elf)" },
  { min: 45, max: 45, label: "Humanoids (gnoll)" },
  { min: 46, max: 46, label: "Humanoids (gnome)" },
  { min: 47, max: 49, label: "Humanoids (goblinoid)" },
  { min: 50, max: 50, label: "Humanoids (halfling)" },
  { min: 51, max: 54, label: "Humanoids (human)" },
  { min: 55, max: 57, label: "Humanoids (reptilian)" },
  { min: 58, max: 60, label: "Humanoids (orc)" },
  { min: 61, max: 65, label: "Magical beasts" },
  { min: 66, max: 70, label: "Monstrous humanoids" },
  { min: 71, max: 72, label: "Oozes" },
  { min: 73, max: 73, label: "Outsiders (air)" },
  { min: 74, max: 76, label: "Outsiders (chaotic)" },
  { min: 77, max: 77, label: "Outsiders (earth)" },
  { min: 78, max: 80, label: "Outsiders (evil)" },
  { min: 81, max: 81, label: "Outsiders (fire)" },
  { min: 82, max: 84, label: "Outsiders (good)" },
  { min: 85, max: 87, label: "Outsiders (lawful)" },
  { min: 88, max: 88, label: "Outsiders (water)" },
  { min: 89, max: 90, label: "Plants" },
  { min: 91, max: 98, label: "Undead" },
  { min: 99, max: 100, label: "Vermin" },
];

// ---------------------------------------------------------------------------
// TABLE: COMMON MELEE WEAPONS (masterwork-inclusive cost)
// ---------------------------------------------------------------------------
export const commonMeleeTableSRD: { min: number; max: number; name: string; cost: number; dmgType: string; double?: boolean }[] = [
  { min: 1, max: 4, name: "Dagger", cost: 302, dmgType: "P or S" },
  { min: 5, max: 14, name: "Greataxe", cost: 320, dmgType: "S" },
  { min: 15, max: 24, name: "Greatsword", cost: 350, dmgType: "S" },
  { min: 25, max: 28, name: "Kama", cost: 302, dmgType: "S" },
  { min: 29, max: 41, name: "Longsword", cost: 315, dmgType: "S" },
  { min: 42, max: 45, name: "Light mace", cost: 305, dmgType: "B" },
  { min: 46, max: 50, name: "Heavy mace", cost: 312, dmgType: "B" },
  { min: 51, max: 54, name: "Nunchaku", cost: 302, dmgType: "B" },
  { min: 55, max: 57, name: "Quarterstaff", cost: 600, dmgType: "B", double: true },
  { min: 58, max: 61, name: "Rapier", cost: 320, dmgType: "P" },
  { min: 62, max: 66, name: "Scimitar", cost: 315, dmgType: "S" },
  { min: 67, max: 70, name: "Shortspear", cost: 302, dmgType: "P" },
  { min: 71, max: 74, name: "Siangham", cost: 303, dmgType: "P" },
  { min: 75, max: 84, name: "Bastard sword", cost: 335, dmgType: "S" },
  { min: 85, max: 89, name: "Short sword", cost: 310, dmgType: "P" },
  { min: 90, max: 100, name: "Dwarven waraxe", cost: 330, dmgType: "S" },
];

// ---------------------------------------------------------------------------
// TABLE: UNCOMMON WEAPONS (masterwork-inclusive cost)
// ---------------------------------------------------------------------------
export const uncommonTableSRD: { min: number; max: number; name: string; cost: number; dmgType: string; double?: boolean }[] = [
  { min: 1, max: 3, name: "Orc double axe", cost: 660, dmgType: "S", double: true },
  { min: 4, max: 7, name: "Battleaxe", cost: 310, dmgType: "S" },
  { min: 8, max: 10, name: "Spiked chain", cost: 325, dmgType: "P" },
  { min: 11, max: 12, name: "Club", cost: 300, dmgType: "B" },
  { min: 13, max: 16, name: "Hand crossbow", cost: 400, dmgType: "P" },
  { min: 17, max: 19, name: "Repeating crossbow", cost: 550, dmgType: "P" },
  { min: 20, max: 21, name: "Punching dagger", cost: 302, dmgType: "P" },
  { min: 22, max: 23, name: "Falchion", cost: 375, dmgType: "S" },
  { min: 24, max: 26, name: "Dire flail", cost: 690, dmgType: "B", double: true },
  { min: 27, max: 31, name: "Heavy flail", cost: 315, dmgType: "B" },
  { min: 32, max: 35, name: "Light flail", cost: 308, dmgType: "B" },
  { min: 36, max: 37, name: "Gauntlet", cost: 302, dmgType: "B" },
  { min: 38, max: 39, name: "Spiked gauntlet", cost: 305, dmgType: "P" },
  { min: 40, max: 41, name: "Glaive", cost: 308, dmgType: "S" },
  { min: 42, max: 43, name: "Greatclub", cost: 305, dmgType: "B" },
  { min: 44, max: 45, name: "Guisarme", cost: 309, dmgType: "P" },
  { min: 46, max: 48, name: "Halberd", cost: 310, dmgType: "P or S" },
  { min: 49, max: 51, name: "Spear", cost: 301, dmgType: "P" },
  { min: 52, max: 54, name: "Gnome hooked hammer", cost: 620, dmgType: "B", double: true },
  { min: 55, max: 56, name: "Light hammer", cost: 301, dmgType: "B" },
  { min: 57, max: 58, name: "Handaxe", cost: 306, dmgType: "S" },
  { min: 59, max: 61, name: "Kukri", cost: 308, dmgType: "S" },
  { min: 62, max: 64, name: "Lance", cost: 310, dmgType: "P" },
  { min: 65, max: 67, name: "Longspear", cost: 305, dmgType: "P" },
  { min: 68, max: 70, name: "Morningstar", cost: 308, dmgType: "B or P" },
  { min: 71, max: 72, name: "Net", cost: 320, dmgType: "P" },
  { min: 73, max: 74, name: "Heavy pick", cost: 308, dmgType: "P" },
  { min: 75, max: 76, name: "Light pick", cost: 304, dmgType: "P" },
  { min: 77, max: 78, name: "Ranseur", cost: 310, dmgType: "P" },
  { min: 79, max: 80, name: "Sap", cost: 301, dmgType: "B" },
  { min: 81, max: 82, name: "Scythe", cost: 318, dmgType: "P or S" },
  { min: 83, max: 84, name: "Shuriken (50)", cost: 310, dmgType: "P" },
  { min: 85, max: 86, name: "Sickle", cost: 306, dmgType: "S" },
  { min: 87, max: 89, name: "Two-bladed sword", cost: 700, dmgType: "P or S", double: true },
  { min: 90, max: 91, name: "Trident", cost: 315, dmgType: "P" },
  { min: 92, max: 94, name: "Dwarven urgrosh", cost: 650, dmgType: "P or S", double: true },
  { min: 95, max: 97, name: "Warhammer", cost: 312, dmgType: "B" },
  { min: 98, max: 100, name: "Whip", cost: 301, dmgType: "S" },
];

// ---------------------------------------------------------------------------
// TABLE: COMMON RANGED WEAPONS (masterwork-inclusive cost)
// Includes the ammunition sub-table.
// ---------------------------------------------------------------------------
export const commonRangedTableSRD: { min: number; max: number; name: string; cost: number; dmgType: string; ammo?: boolean }[] = [
  { min: 1, max: 10, name: "Ammunition (roll again)", cost: 0, dmgType: "P", ammo: true },
  { min: 11, max: 15, name: "Throwing axe", cost: 308, dmgType: "S" },
  { min: 16, max: 25, name: "Heavy crossbow", cost: 350, dmgType: "P" },
  { min: 26, max: 35, name: "Light crossbow", cost: 335, dmgType: "P" },
  { min: 36, max: 39, name: "Dart", cost: 300.5, dmgType: "P" },
  { min: 40, max: 41, name: "Javelin", cost: 301, dmgType: "P" },
  { min: 42, max: 46, name: "Shortbow", cost: 330, dmgType: "P" },
  { min: 47, max: 51, name: "Composite shortbow (+0 Str bonus)", cost: 375, dmgType: "P" },
  { min: 52, max: 56, name: "Composite shortbow (+1 Str bonus)", cost: 450, dmgType: "P" },
  { min: 57, max: 61, name: "Composite shortbow (+2 Str bonus)", cost: 525, dmgType: "P" },
  { min: 62, max: 65, name: "Sling", cost: 300, dmgType: "B" },
  { min: 66, max: 75, name: "Longbow", cost: 375, dmgType: "P" },
  { min: 76, max: 80, name: "Composite longbow (+0 Str bonus)", cost: 400, dmgType: "P" },
  { min: 81, max: 85, name: "Composite longbow (+1 Str bonus)", cost: 500, dmgType: "P" },
  { min: 86, max: 90, name: "Composite longbow (+2 Str bonus)", cost: 600, dmgType: "P" },
  { min: 91, max: 95, name: "Composite longbow (+3 Str bonus)", cost: 700, dmgType: "P" },
  { min: 96, max: 100, name: "Composite longbow (+4 Str bonus)", cost: 800, dmgType: "P" },
];

// Ammunition sub-table (rolled when the ranged table gives "Ammunition")
export const ammunitionTableSRD: { min: number; max: number; name: string; cost: number; dmgType: string }[] = [
  { min: 1, max: 50, name: "Arrows (50)", cost: 302.5, dmgType: "P" },
  { min: 51, max: 75, name: "Crossbow bolts (50)", cost: 305, dmgType: "P" },
  { min: 76, max: 80, name: "Repeating crossbow bolts (50)", cost: 310, dmgType: "P" },
  { min: 81, max: 100, name: "Sling bullets (50)", cost: 300.5, dmgType: "B" },
];

// ---------------------------------------------------------------------------
// TABLE: SPECIFIC WEAPONS
// ---------------------------------------------------------------------------
export interface SpecificWeaponEntry {
  name: string;
  minor?: [number, number];
  medium?: [number, number];
  major?: [number, number];
  price: number;
  aura: string;
  cl: number;
  description: string;
}

export const specificWeaponsTableSRD: SpecificWeaponEntry[] = [
  { name: "Sleep arrow", minor: [1, 20], price: 132, aura: "Faint enchantment", cl: 5,
    description: "This +1 arrow is painted white and has white fletching. If it strikes a foe so that it would normally deal damage, it instead bursts into magical energy that deals nonlethal damage (in the same amount as would be lethal damage) and forces the target to make a DC 11 Will save or fall asleep." },
  { name: "Screaming bolt", minor: [21, 25], price: 267, aura: "Faint enchantment", cl: 5,
    description: "One of these +2 bolts screams when fired, forcing all enemies of the wielder within 20 feet of the path of the bolt to succeed on a DC 14 Will save or become shaken. This is a mind-affecting fear effect." },
  { name: "Silver dagger, masterwork", minor: [26, 45], price: 322, aura: "No aura (nonmagical)", cl: 0,
    description: "This masterwork alchemical silver dagger is nonmagical. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls." },
  { name: "Cold iron longsword, masterwork", minor: [46, 65], price: 330, aura: "No aura (nonmagical)", cl: 0,
    description: "This nonmagical longsword is crafted out of cold iron. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls." },
  { name: "Javelin of lightning", minor: [66, 75], medium: [1, 9], price: 1500, aura: "Faint evocation", cl: 5,
    description: "This javelin becomes a 5d6 lightning bolt when thrown (Reflex DC 14 half). It is consumed in the attack." },
  { name: "Slaying arrow", minor: [76, 80], medium: [10, 15], price: 2282, aura: "Strong necromancy", cl: 13,
    description: "This +1 arrow is keyed to a particular type or subtype of creature. If it strikes such a creature, the target must make a DC 20 Fortitude save or die (or, in the case of unliving targets, be destroyed) instantly. Note that even creatures normally exempt from Fortitude saves (undead and constructs) are subject to this attack. When keyed to a living creature, this is a death effect (and thus death ward protects a target). To determine the type or subtype of creature the arrow is keyed to, roll on the slaying arrow designated-type table." },
  { name: "Adamantine dagger", minor: [81, 90], medium: [16, 24], price: 3002, aura: "No aura (nonmagical)", cl: 0,
    description: "This nonmagical dagger is made out of adamantine. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls." },
  { name: "Adamantine battleaxe", minor: [91, 100], medium: [25, 33], price: 3010, aura: "No aura (nonmagical)", cl: 0,
    description: "This nonmagical axe is made out of adamantine. As a masterwork weapon, it has a +1 enhancement bonus on attack rolls." },
  { name: "Slaying arrow (greater)", medium: [34, 37], price: 4057, aura: "Strong necromancy", cl: 13,
    description: "A greater slaying arrow functions just like a normal slaying arrow, but the DC to avoid the death effect is 23. It is keyed to a particular type or subtype of creature; roll on the slaying arrow designated-type table." },
  { name: "Shatterspike", medium: [38, 40], price: 4315, aura: "Strong evocation", cl: 13,
    description: "Wielders without the Improved Sunder feat use Shatterspike as a +1 longsword only; wielders with the Improved Sunder feat add a +4 bonus (including the sword's +1 enhancement bonus) to the opposed roll when attempting to strike a foe's weapon. If successful, Shatterspike deals 1d8+4 points of damage plus the wielder's Strength modifier to the target weapon (the target weapon's hardness must still be overcome with each hit). Shatterspike can damage weapons with an enhancement bonus of +4 or lower." },
  { name: "Dagger of venom", medium: [41, 46], price: 8302, aura: "Faint necromancy", cl: 5,
    description: "This black +1 dagger has a serrated edge. It allows the wielder to use a poison effect (as the spell, save DC 14) upon a creature struck by the blade once per day. The wielder can decide to use the power after he has struck. Doing so is a free action, but the poison effect must be invoked in the same round that the dagger strikes." },
  { name: "Trident of warning", medium: [47, 51], price: 10115, aura: "Moderate divination", cl: 7,
    description: "A weapon of this type enables its wielder to determine the location, depth, kind, and number of aquatic predators within 680 feet. A trident of warning must be grasped and pointed in order for the character using it to gain such information, and it requires 1 round to scan a hemisphere with a radius of 680 feet. The weapon is otherwise a +2 trident." },
  { name: "Assassin's dagger", medium: [52, 57], major: [1, 4], price: 10302, aura: "Moderate necromancy", cl: 9,
    description: "This wicked-looking, curved +2 dagger provides a +1 bonus to the DC of a Fortitude save forced by the death attack of an assassin. [NOTE: the SRD's Table: Specific Weapons lists this at 10,302 gp but its own description gives Price 18,302 gp — an internal SRD inconsistency. The table figure is used here.]" },
  { name: "Shifter's sorrow", medium: [58, 62], major: [5, 7], price: 12780, aura: "Strong transmutation", cl: 15,
    description: "This +1/+1 two-bladed sword has blades of alchemical silver. The weapon deals an extra 2d6 points of damage against any creature with the shapechanger subtype. When a shapechanger or a creature in an alternate form (such as a druid using wild shape) is struck by the weapon, it must make a DC 15 Will save or return to its natural form." },
  { name: "Trident of fish command", medium: [63, 66], major: [8, 9], price: 18650, aura: "Moderate enchantment", cl: 7,
    description: "The magical properties of this +1 trident with a 6-foot-long haft enable its wielder to charm up to 14 HD of aquatic animals (Will DC 16 negates, animals get a +5 bonus if currently under attack by the wielder or his allies), no two of which can be more than 30 feet apart. The wielder can use this effect up to three times per day. The wielder can communicate with the animals as if using a speak with animals spell. Animals making their saving throw are free of control, but they will not approach within 10 feet of the trident." },
  { name: "Flame tongue", medium: [67, 74], major: [10, 13], price: 20715, aura: "Moderate evocation", cl: 12,
    description: "This is a +1 flaming burst longsword. Once per day, the sword can blast forth a fiery ray at any target within 30 feet as a ranged touch attack. The ray deals 4d6 points of fire damage on a successful hit." },
  { name: "Luck blade (0 wishes)", medium: [75, 79], major: [14, 17], price: 22060, aura: "Strong evocation", cl: 17,
    description: "This +2 short sword gives its possessor a +1 luck bonus on all saving throws. Its possessor also gains the power of good fortune, usable once per day. This extraordinary ability allows its possessor to reroll one roll that she just made. She must take the result of the reroll, even if it's worse than the original roll. This blade currently holds no wishes. When the last wish is used, the sword remains a +2 short sword, still grants the +1 luck bonus, and still grants its reroll power." },
  { name: "Sword of subtlety", medium: [80, 86], major: [18, 24], price: 22310, aura: "Moderate illusion", cl: 7,
    description: "A +1 short sword with a thin, dull gray blade, this weapon provides a +4 bonus on its wielder's attack and damage rolls when he is making a sneak attack with it." },
  { name: "Sword of the planes", medium: [87, 91], major: [25, 31], price: 22315, aura: "Strong evocation", cl: 15,
    description: "This longsword has an enhancement bonus of +1 on the Material Plane, but on any Elemental Plane its enhancement bonus increases to +2. (The +2 enhancement bonus also applies on the Material Plane when the weapon is used against elementals.) It operates as a +3 longsword on the Astral Plane or the Ethereal Plane or when used against opponents native to either of those planes. On any other plane, or against any outsider, it functions as a +4 longsword." },
  { name: "Nine lives stealer", medium: [92, 95], major: [32, 37], price: 23057, aura: "Strong necromancy [evil]", cl: 13,
    description: "This longsword always performs as a +2 longsword, but it also has the power to draw the life force from an opponent. It can do this nine times before the ability is lost. At that point, the sword becomes a simple +2 longsword (with a hint of evil about it). A critical hit must be dealt for the sword's death-dealing ability to function, and this weapon has no effect on creatures not subject to critical hits. The victim is entitled to a DC 20 Fortitude save to avoid death. If the save is successful, the sword's death-dealing ability does not function, no use of the ability is expended, and normal critical damage is determined. This sword is evil, and any good character attempting to wield it gains two negative levels." },
  { name: "Sword of life stealing", medium: [96, 98], major: [38, 42], price: 25715, aura: "Strong necromancy", cl: 17,
    description: "This black iron +2 longsword bestows a negative level when it deals a critical hit. The sword wielder gains 1d6 temporary hit points each time a negative level is bestowed on another. These temporary hit points last for 24 hours. One day after being struck, subjects must make a DC 16 Fortitude save for each negative level or lose a character level." },
  { name: "Oathbow", medium: [99, 100], major: [43, 46], price: 25600, aura: "Strong evocation", cl: 15,
    description: "Of elven make, this white +2 composite longbow (+2 Str bonus) whispers \"Swift defeat to my enemies\" in Elven when nocked and pulled. Once per day, if the firer swears aloud to slay her target (a free action), the bow's whisper becomes the low shout \"Swift death to those who have wronged me.\" Against such a sworn enemy, the bow has a +5 enhancement bonus, and arrows launched from it deal an additional 2d6 points of damage (and x4 on a critical hit instead of the normal x3). However, the bow is treated as only a masterwork weapon against all foes other than the sworn enemy, and the wielder takes a -1 penalty on attack rolls with any weapon other than the oathbow. These bonuses and penalties last for seven days or until the sworn enemy is slain or destroyed by the wielder of the oathbow, whichever comes first. The oathbow may only have one sworn enemy at a time." },
  { name: "Mace of terror", major: [47, 51], price: 38552, aura: "Strong necromancy", cl: 13,
    description: "On command, this +2 heavy mace causes the wielder's clothes and appearance to transform into an illusion of darkest horror such that living creatures in a 30-foot cone become panicked as if by a fear spell (Will DC 16 partial). They take a -2 morale penalty on saving throws, and they flee from the wielder. The wielder may use this ability up to three times per day." },
  { name: "Life-drinker", major: [52, 57], price: 40320, aura: "Strong necromancy", cl: 13,
    description: "This +1 greataxe is favored by undead and constructs, who do not suffer its drawback. A life-drinker bestows two negative levels on its target whenever it deals damage, just as if its target had been struck by an undead creature. One day after being struck, subjects must make a DC 16 Fortitude save for each negative level or lose a character level. Each time a life-drinker deals damage to a foe, it also bestows one negative level on the wielder. Any negative level gained by the wielder in this fashion lasts for 1 hour." },
  { name: "Sylvan scimitar", major: [58, 62], price: 47315, aura: "Moderate evocation", cl: 11,
    description: "This +3 scimitar, when used outdoors in a temperate climate, grants its wielder the use of the Cleave feat and deals an extra 1d6 points of damage." },
  { name: "Rapier of puncturing", major: [63, 67], price: 50320, aura: "Strong necromancy", cl: 13,
    description: "Three times per day, this +2 wounding rapier allows the wielder to make a touch attack with the weapon that deals 1d6 points of Constitution damage by draining blood. Creatures immune to critical hits are immune to the Constitution damage dealt by this weapon." },
  { name: "Sun blade", major: [68, 73], price: 50335, aura: "Moderate evocation", cl: 10,
    description: "This sword is the size of a bastard sword. However, a sun blade is wielded as if it were a short sword with respect to weight and ease of use. In normal combat, the glowing golden blade of the weapon is equal to a +2 bastard sword. Against evil creatures, its enhancement bonus is +4. Against Negative Energy Plane creatures or undead creatures, the sword deals double damage (and x3 on a critical hit instead of the usual x2). Once per day, the wielder can swing the blade vigorously above her head while speaking a command word; the sun blade then sheds a bright yellow radiance like full daylight, starting in a 10-foot radius and extending outward at 5 feet per round for 10 rounds to create a globe of light with a 60-foot radius. All sun blades are of good alignment, and any evil creature attempting to wield one gains one negative level." },
  { name: "Frost brand", major: [74, 79], price: 54475, aura: "Strong evocation", cl: 14,
    description: "This +3 frost greatsword sheds light as a torch when the temperature drops below 0F. At such times it cannot be concealed when drawn, nor can its light be shut off. Its wielder is protected from fire; the sword absorbs the first 10 points of fire damage each round that the wielder would otherwise take. A frost brand extinguishes all nonmagical fires in its area. As a standard action, it can also dispel lasting fire spells, but not instantaneous effects, though you must succeed on a dispel check (1d20 + 14) against each spell to dispel it. The DC to dispel such spells is 11 + the caster level of the fire spell." },
  { name: "Dwarven thrower", major: [80, 84], price: 60312, aura: "Moderate evocation", cl: 10,
    description: "This weapon commonly functions as a +2 warhammer. In the hands of a dwarf, the warhammer gains an additional +1 enhancement bonus (for a total enhancement bonus of +3) and gains the returning special ability. It can be hurled with a 30-foot range increment. When hurled, it deals an extra 2d8 points of damage against giants or an extra 1d8 points of damage against any other target." },
  { name: "Luck blade (1 wish)", major: [85, 91], price: 62360, aura: "Strong evocation", cl: 17,
    description: "This +2 short sword gives its possessor a +1 luck bonus on all saving throws. Its possessor also gains the power of good fortune, usable once per day, allowing her to reroll one roll that she just made (she must take the reroll result). In addition, this blade holds one wish. When the last wish is used, the sword remains a +2 short sword, still grants the +1 luck bonus, and still grants its reroll power." },
  { name: "Mace of smiting", major: [92, 95], price: 75312, aura: "Moderate transmutation", cl: 11,
    description: "This +3 adamantine heavy mace has a +5 enhancement bonus against constructs, and any critical hit dealt to a construct completely destroys it (no saving throw). A critical hit dealt to an outsider deals x4 damage rather than x2." },
  { name: "Luck blade (2 wishes)", major: [96, 97], price: 102660, aura: "Strong evocation", cl: 17,
    description: "This +2 short sword gives its possessor a +1 luck bonus on all saving throws and the power of good fortune once per day (reroll one roll just made; take the reroll result). In addition, this blade holds two wishes." },
  { name: "Holy avenger", major: [98, 99], price: 120630, aura: "Strong abjuration", cl: 18,
    description: "This +2 cold iron longsword becomes a +5 holy cold iron longsword in the hands of a paladin. It provides spell resistance of 5 + the paladin's level to the wielder and anyone adjacent to her. It also enables the wielder to use greater dispel magic (once per round as a standard action) at the class level of the paladin. (Only the area dispel is possible, not the targeted dispel or counterspell versions of greater dispel magic.)" },
  { name: "Luck blade (3 wishes)", major: [100, 100], price: 142960, aura: "Strong evocation", cl: 17,
    description: "This +2 short sword gives its possessor a +1 luck bonus on all saving throws and the power of good fortune once per day (reroll one roll just made; take the reroll result). In addition, this blade holds three wishes." },
];

// ---------------------------------------------------------------------------
// SPECIAL MATERIALS — exact SRD cost modifiers
// ---------------------------------------------------------------------------
export const specialMaterialRoll = [
  { min: 1, max: 95, material: null },
  { min: 96, max: 100, material: "special" },
];

export interface SpecialMaterial {
  name: string;
  appliesTo: ("weapon" | "armor" | "shield" | "ammunition")[];
  costNote: string;
  costFor: (kind: "weapon" | "armor" | "shield" | "ammunition", weightClass?: "light" | "medium" | "heavy", baseCost?: number) => number;
  effect: string;
  weightHalved?: boolean;
}

export const specialMaterialsSRD: SpecialMaterial[] = [
  { name: "Adamantine",
    appliesTo: ["weapon", "armor", "shield", "ammunition"],
    costNote: "Ammunition +60 gp; light armor +5,000 gp; medium armor +10,000 gp; heavy armor +15,000 gp; weapon +3,000 gp; shield +2,000 gp. Adamantine is so costly that weapons and armor made from it are always of masterwork quality; the masterwork cost is included in these prices.",
    costFor: (kind, wc) => {
      if (kind === "ammunition") return 60;
      if (kind === "weapon") return 3000;
      if (kind === "shield") return 2000;
      return wc === "light" ? 5000 : wc === "medium" ? 10000 : 15000;
    },
    effect: "This ultrahard metal adds to the quality of a weapon or suit of armor. Weapons fashioned from adamantine have a natural ability to bypass hardness when sundering weapons or attacking objects, ignoring hardness less than 20. Armor made from adamantine grants its wearer damage reduction of 1/- if it's light armor, 2/- if it's medium armor, and 3/- if it's heavy armor. Adamantine is so costly that weapons and armor made from it are always of masterwork quality; the masterwork cost is included in the prices given. Thus, adamantine weapons and ammunition have a +1 enhancement bonus on attack rolls, and the armor check penalty of adamantine armor is lessened by 1 compared to ordinary armor of its type. Items without metal parts cannot be made from adamantine. An arrow could be made of adamantine, but a quarterstaff could not. Only weapons, armor, and shields normally made of metal can be fashioned from adamantine. Weapons, armor and shields normally made of steel that are made of adamantine have one-third more hit points than normal. Adamantine has 40 hit points per inch of thickness and hardness 20." },

  { name: "Mithral",
    appliesTo: ["weapon", "armor", "shield"],
    costNote: "Light armor +1,000 gp; medium armor +4,000 gp; heavy armor +9,000 gp; shield +1,000 gp; other items +500 gp/lb. Weapons or armors fashioned from mithral are always masterwork items as well; the masterwork cost is included in these prices.",
    costFor: (kind, wc) => {
      if (kind === "weapon") return 500;   // "other items +500 gp/lb"; a Medium weapon weighs ~3 lb
      if (kind === "shield") return 1000;
      return wc === "light" ? 1000 : wc === "medium" ? 4000 : 9000;
    },
    effect: "Mithral is a very rare silvery, glistening metal that is lighter than iron but just as hard. Most mithral armors are one category lighter than normal for purposes of movement and other limitations: heavy armors are treated as medium, and medium armors are treated as light, but light armors are still treated as light. Spell failure chances for armors and shields made from mithral are decreased by 10%, maximum Dexterity bonus is increased by 2, and armor check penalties are lessened by 3 (to a minimum of 0). An item made from mithral weighs half as much as the same item made from other metals. In the case of weapons, this lighter weight does not change a weapon's size category or the ease with which it can be wielded. Items not primarily of metal are not meaningfully affected by being partially made of mithral (a longsword can be a mithral weapon, while a scythe cannot be). Mithral has 30 hit points per inch of thickness and hardness 15." },

  { name: "Alchemical silver",
    appliesTo: ["weapon", "ammunition"],
    costNote: "Ammunition +2 gp; light weapon +20 gp; one-handed weapon (or one head of a double weapon) +90 gp; two-handed weapon (or both heads of a double weapon) +180 gp.",
    costFor: (kind, _wc, baseCost) => {
      if (kind === "ammunition") return 2;
      // Distinguish light / one-handed / two-handed by the mundane base cost.
      if (baseCost !== undefined) {
        if (baseCost <= 10) return 20;     // light weapons (dagger, sickle, etc.)
        if (baseCost <= 20) return 90;     // one-handed
        return 180;                        // two-handed
      }
      return 90;
    },
    effect: "A complex process involving metallurgy and alchemy can bond silver to a weapon made of steel so that it bypasses the damage reduction of creatures such as lycanthropes. On a successful attack with a silvered weapon, the wielder takes a -1 penalty on the damage roll (with the usual minimum of 1 point of damage). The alchemical silvering process can't be applied to nonmetal items, and it doesn't work on rare metals such as adamantine, cold iron, and mithral. Alchemical silver has 10 hit points per inch of thickness and hardness 8." },

  { name: "Cold iron",
    appliesTo: ["weapon", "ammunition"],
    costNote: "Weapons made of cold iron cost twice as much to make as their normal counterparts. Also, any magical enhancements cost an additional 2,000 gp.",
    costFor: (kind, _wc, baseCost) => kind === "ammunition" ? (baseCost ?? 0) : (baseCost ?? 0) * 2,
    effect: "This iron, mined deep underground, known for its effectiveness against fey creatures, is forged at a lower temperature to preserve its delicate properties. Weapons made of cold iron cost twice as much to make as their normal counterparts. Also, any magical enhancements cost an additional 2,000 gp. Items without metal parts cannot be made from cold iron. An arrow could be made of cold iron, but a quarterstaff could not. Cold iron has 30 hit points per inch of thickness and hardness 10." },

  { name: "Dragonhide",
    appliesTo: ["armor", "shield"],
    costNote: "Dragonhide armor costs double what masterwork armor of that type ordinarily costs, but it takes no longer to make than ordinary armor of that type.",
    costFor: (_kind, _wc, baseCost) => (baseCost ?? 0) * 2,
    effect: "Armorsmiths can work with the hides of dragons to produce armor or shields of masterwork quality. Because dragonhide armor isn't made of metal, druids can wear it without penalty. Dragonhide armor costs double what masterwork armor of that type ordinarily costs, but it takes no longer to make than ordinary armor of that type. Dragonhide has 10 hit points per inch of thickness and hardness 10." },

  { name: "Darkwood",
    appliesTo: ["weapon", "shield"],
    costNote: "To determine the price of a darkwood item, use the original weight but add 10 gp per pound to the price of a masterwork version of that item.",
    costFor: (_kind, _wc, weight) => (weight ?? 0) * 10,
    effect: "This rare magic wood is as hard as normal wood but very light. Any wooden or mostly wooden item (such as a bow, an arrow, or a spear) made from darkwood is considered a masterwork item and weighs only half as much as a normal wooden item of that type. Items not normally made of wood or only partially of wood (such as a battleaxe or a mace) either cannot be made from darkwood or do not gain any special benefit from being made of darkwood. The armor check penalty of a darkwood shield is lessened by 2 compared to an ordinary shield of its type. Darkwood has 10 hit points per inch of thickness and hardness 5.",
    weightHalved: true,
  },
];

// Weapon Special Qualities — the bands differ between melee and ranged weapons.
export const meleeWeaponSpecialQualities = [
  { min: 1, max: 30, result: "The item sheds light (as a light spell: bright light in a 20-foot radius, shadowy light in a 40-foot radius)" },
  { min: 31, max: 45, result: "A design, inscription, or the like provides a clue to the weapon's function" },
  { min: 46, max: 100, result: "No special qualities" },
];

export const rangedWeaponSpecialQualities = [
  { min: 1, max: 15, result: "A design, inscription, or the like provides a clue to the weapon's function" },
  { min: 16, max: 100, result: "No special qualities" },
];
