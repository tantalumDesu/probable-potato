// Art objects from SRD.

export interface ArtTier {
  min: number;
  max: number;
  valueDie: string;
  average: number;
  examples: string[];
}

export const artTable: ArtTier[] = [
  {
    min: 1, max: 10, valueDie: "1d10x10", average: 55,
    examples: [
      "Silver ewer",
      "Carved bone or ivory statuette",
      "Finely wrought small gold bracelet",
    ],
  },
  {
    min: 11, max: 25, valueDie: "3d6x10", average: 105,
    examples: [
      "Cloth of gold vestments",
      "Black velvet mask with numerous citrines",
      "Silver chalice with lapis lazuli gems",
    ],
  },
  {
    min: 26, max: 40, valueDie: "1d6x100", average: 350,
    examples: [
      "Large well-done wool tapestry",
      "Brass mug with jade inlays",
    ],
  },
  {
    min: 41, max: 50, valueDie: "1d10x100", average: 550,
    examples: [
      "Silver comb with moonstones",
      "Silver-plated steel longsword with jet jewel in hilt",
    ],
  },
  {
    min: 51, max: 60, valueDie: "2d6x100", average: 700,
    examples: [
      "Carved harp of exotic wood with ivory inlay and zircon gems",
      "Solid gold idol (10 lb.)",
    ],
  },
  {
    min: 61, max: 70, valueDie: "3d6x100", average: 1050,
    examples: [
      "Gold dragon comb with red garnet eye",
      "Gold and topaz bottle stopper cork",
      "Ceremonial electrum dagger with a star ruby in the pommel",
    ],
  },
  {
    min: 71, max: 80, valueDie: "4d6x100", average: 1400,
    examples: [
      "Eyepatch with mock eye of sapphire and moonstone",
      "Fire opal pendant on a fine gold chain",
      "Old masterpiece painting",
    ],
  },
  {
    min: 81, max: 85, valueDie: "5d6x100", average: 1750,
    examples: [
      "Embroidered silk and velvet mantle with numerous moonstones",
      "Sapphire pendant on gold chain",
    ],
  },
  {
    min: 86, max: 90, valueDie: "1d4x1000", average: 2500,
    examples: [
      "Embroidered and bejeweled glove",
      "Jeweled anklet",
      "Gold music box",
    ],
  },
  {
    min: 91, max: 95, valueDie: "1d6x1000", average: 3500,
    examples: [
      "Golden circlet with four aquamarines",
      "A string of small pink pearls (necklace)",
    ],
  },
  {
    min: 96, max: 99, valueDie: "2d4x1000", average: 5000,
    examples: [
      "Jeweled gold crown",
      "Jeweled electrum ring",
    ],
  },
  {
    min: 100, max: 100, valueDie: "2d6x1000", average: 7000,
    examples: [
      "Gold and ruby ring",
      "Gold cup set with emeralds",
    ],
  },
];
