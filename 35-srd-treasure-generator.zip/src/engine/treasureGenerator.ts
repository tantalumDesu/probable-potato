import { DiceRoller, RollLogEntry } from "./dice";
import {
  coinTableByLevel,
  CoinType,
  coinNames,
} from "../data/coins";
import { gemTable, goodsTableByLevel, GoodsEntry } from "../data/gems";
import { artTable } from "../data/artObjects";
import {
  mundaneMasterTable,
  MundaneCategory,
  MundaneSubentry,
  darkwoodSubtable,
  masterworkShieldSubtable,
} from "../data/mundaneItems";
import {
  commonMeleeWeapons,
  commonRangedWeapons,
  uncommonWeapons,
  MASTERWORK_COST_BONUS,
  Weapon,
  armorSizeMultipliers,
  weaponSizeMultipliers,
} from "../data/weapons";
import {
  magicItemMasterTable,
  itemsTableByLevel,
  epicBonusMajorItems,
} from "../data/magicItems";
import {
  armorEnhTable,
  weaponEnhTable,
  randomArmorType,
  randomShieldType,
  specificArmorsSRD,
  specificShieldsSRD,
} from "../data/magicGeneration";
import {
  armorAbilitiesSRD,
  shieldAbilitiesSRD,
  meleeWeaponAbilitiesSRD,
  rangedWeaponAbilitiesSRD,
  baneFoeTable as baneFoeTableSRD,
  commonMeleeTableSRD,
  uncommonTableSRD,
  commonRangedTableSRD,
  ammunitionTableSRD,
  specificWeaponsTableSRD,
  specialMaterialsSRD,
  meleeWeaponSpecialQualities,
  rangedWeaponSpecialQualities,
  WeaponAbilitySRD,
  ArmorAbility,
  specialMaterialRoll,
} from "../data/magicArmorWeaponsSRD";
import {
  arcaneScrollSpells,
  divineScrollSpells,
  scrollPriceFootnotes,
  minorWondrousTableSRD,
  mediumWondrousTableSRD,
  majorWondrousTableSRD,
  wondrousDescKeys,
  wondrousDescriptionsSRD,
  lookupWeaponDamage,
} from "../data/scrollsAndWondrous";
import {
  intelligentAlignmentTable,
  intCapabilitiesTable,
  intLesserPowers,
  intGreaterPowers,
  intPurposeTable,
  intDedicatedPowers,
  INTELLIGENT_ITEM_RULES,
  purposeRaces,
  purposeDeities,
} from "../data/intelligentItemsSRD";

// Look up a weapon's Medium damage die and weight by name from the SRD weapon
// tables. Returns an empty damage string for items with no damage entry.
const WEAPON_STATS: Record<string, { dmg: string; weight: number; dmgType: string }> = {
  "Dagger": { dmg: "1d4", weight: 1, dmgType: "P or S" }, "Greataxe": { dmg: "1d12", weight: 12, dmgType: "S" },
  "Greatsword": { dmg: "2d6", weight: 8, dmgType: "S" }, "Kama": { dmg: "1d6", weight: 2, dmgType: "S" },
  "Longsword": { dmg: "1d8", weight: 4, dmgType: "S" }, "Light mace": { dmg: "1d6", weight: 4, dmgType: "B" },
  "Heavy mace": { dmg: "1d8", weight: 8, dmgType: "B" }, "Nunchaku": { dmg: "1d6", weight: 2, dmgType: "B" },
  "Quarterstaff": { dmg: "1d6", weight: 4, dmgType: "B" }, "Rapier": { dmg: "1d6", weight: 2, dmgType: "P" },
  "Scimitar": { dmg: "1d6", weight: 4, dmgType: "S" }, "Shortspear": { dmg: "1d6", weight: 3, dmgType: "P" },
  "Siangham": { dmg: "1d6", weight: 1, dmgType: "P" }, "Bastard sword": { dmg: "1d10", weight: 6, dmgType: "S" },
  "Short sword": { dmg: "1d6", weight: 2, dmgType: "P" }, "Dwarven waraxe": { dmg: "1d10", weight: 8, dmgType: "S" },
  "Orc double axe": { dmg: "1d8", weight: 15, dmgType: "S" }, "Battleaxe": { dmg: "1d8", weight: 6, dmgType: "S" },
  "Spiked chain": { dmg: "2d4", weight: 10, dmgType: "P" }, "Club": { dmg: "1d6", weight: 3, dmgType: "B" },
  "Hand crossbow": { dmg: "1d4", weight: 2, dmgType: "P" }, "Repeating crossbow": { dmg: "1d10", weight: 6, dmgType: "P" },
  "Punching dagger": { dmg: "1d4", weight: 1, dmgType: "P" }, "Falchion": { dmg: "2d4", weight: 8, dmgType: "S" },
  "Dire flail": { dmg: "1d8", weight: 10, dmgType: "B" }, "Heavy flail": { dmg: "1d10", weight: 10, dmgType: "B" },
  "Light flail": { dmg: "1d8", weight: 5, dmgType: "B" }, "Gauntlet": { dmg: "1d3", weight: 1, dmgType: "B" },
  "Spiked gauntlet": { dmg: "1d4", weight: 1, dmgType: "P" }, "Glaive": { dmg: "1d10", weight: 10, dmgType: "S" },
  "Greatclub": { dmg: "1d10", weight: 8, dmgType: "B" }, "Guisarme": { dmg: "2d4", weight: 12, dmgType: "P" },
  "Halberd": { dmg: "1d10", weight: 12, dmgType: "P or S" }, "Spear": { dmg: "1d8", weight: 6, dmgType: "P" },
  "Gnome hooked hammer": { dmg: "1d8", weight: 6, dmgType: "B" }, "Light hammer": { dmg: "1d4", weight: 2, dmgType: "B" },
  "Handaxe": { dmg: "1d6", weight: 3, dmgType: "S" }, "Kukri": { dmg: "1d4", weight: 2, dmgType: "S" },
  "Lance": { dmg: "1d8", weight: 10, dmgType: "P" }, "Longspear": { dmg: "1d8", weight: 9, dmgType: "P" },
  "Morningstar": { dmg: "1d8", weight: 6, dmgType: "B or P" }, "Net": { dmg: "", weight: 6, dmgType: "-" },
  "Heavy pick": { dmg: "1d6", weight: 6, dmgType: "P" }, "Light pick": { dmg: "1d4", weight: 3, dmgType: "P" },
  "Ranseur": { dmg: "2d4", weight: 12, dmgType: "P" }, "Sap": { dmg: "1d6", weight: 2, dmgType: "B" },
  "Scythe": { dmg: "2d4", weight: 10, dmgType: "P or S" }, "Shuriken (50)": { dmg: "1", weight: 0.5, dmgType: "P" },
  "Sickle": { dmg: "1d6", weight: 2, dmgType: "S" }, "Two-bladed sword": { dmg: "1d8", weight: 10, dmgType: "P or S" },
  "Trident": { dmg: "1d8", weight: 4, dmgType: "P" }, "Dwarven urgrosh": { dmg: "1d8", weight: 12, dmgType: "P or S" },
  "Warhammer": { dmg: "1d8", weight: 5, dmgType: "B" }, "Whip": { dmg: "1d3", weight: 2, dmgType: "S" },
  "Throwing axe": { dmg: "1d6", weight: 2, dmgType: "S" }, "Heavy crossbow": { dmg: "1d10", weight: 8, dmgType: "P" },
  "Light crossbow": { dmg: "1d8", weight: 4, dmgType: "P" }, "Dart": { dmg: "1d4", weight: 0.5, dmgType: "P" },
  "Javelin": { dmg: "1d6", weight: 2, dmgType: "P" }, "Shortbow": { dmg: "1d6", weight: 2, dmgType: "P" },
  "Sling": { dmg: "1d4", weight: 0, dmgType: "B" }, "Longbow": { dmg: "1d8", weight: 3, dmgType: "P" },
  "Composite shortbow (+0 Str bonus)": { dmg: "1d6", weight: 2, dmgType: "P" }, "Composite shortbow (+1 Str bonus)": { dmg: "1d6", weight: 2, dmgType: "P" },
  "Composite shortbow (+2 Str bonus)": { dmg: "1d6", weight: 2, dmgType: "P" }, "Composite longbow (+0 Str bonus)": { dmg: "1d8", weight: 3, dmgType: "P" },
  "Composite longbow (+1 Str bonus)": { dmg: "1d8", weight: 3, dmgType: "P" }, "Composite longbow (+2 Str bonus)": { dmg: "1d8", weight: 3, dmgType: "P" },
  "Composite longbow (+3 Str bonus)": { dmg: "1d8", weight: 3, dmgType: "P" }, "Composite longbow (+4 Str bonus)": { dmg: "1d8", weight: 3, dmgType: "P" },
  "Arrows (50)": { dmg: "", weight: 3, dmgType: "P" }, "Crossbow bolts (50)": { dmg: "", weight: 2, dmgType: "P" },
  "Repeating crossbow bolts (50)": { dmg: "", weight: 2, dmgType: "P" }, "Sling bullets (50)": { dmg: "", weight: 5, dmgType: "B" },
};

function lookupDamage(name: string): string {
  const k = Object.keys(WEAPON_STATS).find(n => n.toLowerCase() === name.toLowerCase());
  return k ? WEAPON_STATS[k].dmg : "";
}

function lookupDmgType(name: string): string | undefined {
  const k = Object.keys(WEAPON_STATS).find(n => n.toLowerCase() === name.toLowerCase());
  return k ? WEAPON_STATS[k].dmgType : undefined;
}

function lookupWeight(name: string): number {
  const k = Object.keys(WEAPON_STATS).find(n => n.toLowerCase() === name.toLowerCase());
  return k ? WEAPON_STATS[k].weight : 2;
}
import {
  weaponTypeTable,
} from "../data/magicWeapons";
import { findSRDSpell } from "../data/spellsSRD";
import {
  wandSpellTable,
  wandPrice,
  scrollPrice,
} from "../data/otherMagicItems";
import {
  ringTable as srdRingTable,
  ringDetails,
  ringSpecialQualities,
  rodSpecialQualities,
  rodTable as srdRodTable,
  rodDetails,
} from "../data/ringsRodsSRD";
import {
  potionTables,
  alignments,
  energyTypes,
  staffTable,
  staffDetails,
  staffSpecialQualities,
  scrollTypeTable,
  scrollSpellCount,
  scrollSpellLevels,
  scrollMishaps,
  wondrousSpecialQualities,
  WonderEntry,
  cursedItemsFull,
} from "../data/srdTables2";

// -------- Types --------
export type TreasureCategory = "coins" | "goods" | "items";

export interface TreasureResult {
  level: number;
  coins?: CoinResult[];
  goods?: GoodResult[];
  items?: MagicItemResult[];
  log: RollLogEntry[];
  totalValueGP: number;
  sublogs: TreasureItem[];
}

export interface CoinResult {
  denomination: CoinType;
  amount: number;
  label: string;
  valueGP: number;
}

export interface GoodResult {
  type: "gem" | "art";
  name: string;
  valueGP: number;
  description?: string;
}

export type TreasureItem = CoinResult | GoodResult | MagicItemResult;

export interface MagicItemResult {
  id: string;
  category: string;
  name: string;
  price?: number;
  description?: string;
  subtable?: string;
  cursed?: boolean;
  charges?: number;
  size?: string;
  log: RollLogEntry[];
  intelligent?: IntelligentItem;
}

export interface IntelligentItem {
  alignment: string;
  alignmentNote?: string;
  mental: string;
  intScore: number; wisScore: number; chaScore: number;
  communication: string;
  capabilities: string;
  senses: string;
  lesserPowers: string[];
  greaterPowers: string[];
  specialPurpose?: string;
  dedicatedPower?: string;
  ego: number;
  egoBreakdown: { attribute: string; points: number }[];
  priceModifier: number;
  languages: string;
}

// -------- Helpers --------
function pick<T>(arr: T[], roller: DiceRoller, tableName?: string): T {
  const r = roller.roll(1, arr.length, 0, tableName ?? "pick");
  return arr[r - 1];
}

function coinValueInGP(denom: CoinType, amount: number): number {
  const v: Record<CoinType, number> = {
    cp: 0.01, sp: 0.1, gp: 1, pp: 10,
  };
  return Math.floor(amount * v[denom]);
}

function parseCoinDie(die: string, roller: DiceRoller, table: string): number {
  if (die === "0") return 0;
  // Parse NdXxMult: pattern like 1d6x1000
  const m = die.match(/^(\d+)d(\d+)x(\d+)$/);
  if (m) {
    const n = parseInt(m[1]);
    const s = parseInt(m[2]);
    const mult = parseInt(m[3]);
    const r = roller.roll(n, s, 0, table);
    return r * mult;
  }
  return roller.parseAndRoll(die, table);
}

// -------- Main generator --------
export function generateTreasure(
  level: number,
  seed?: number,
): TreasureResult {
  const effectiveLevel = Math.max(1, Math.min(30, level));
  const roller = new DiceRoller(seed);
  const baseLevel = Math.min(effectiveLevel, 20);
  const epicLevel = effectiveLevel > 20 ? effectiveLevel : 0;

  const result: TreasureResult = {
    level: effectiveLevel,
    log: [],
    totalValueGP: 0,
    sublogs: [],
    coins: [],
    goods: [],
    items: [],
  };

  // Main table: coins roll
  const coinRow = roller.rollOnTable(
    `Treasure (coins) Level ${baseLevel}`,
    coinTableByLevel[baseLevel],
  );
  if (coinRow.die !== "0") {
    const match = coinRow.die.match(/x(\d+)\s*(cp|sp|gp|pp)$/i);
    const denom = (match?.[2] as CoinType) ?? "gp";
    const amount = parseCoinDie(coinRow.die, roller, `Coins roll L${baseLevel}`);
    const coinRes: CoinResult = {
      denomination: denom,
      amount,
      label: `${amount.toLocaleString()} ${coinNames[denom]} (${coinRow.label})`,
      valueGP: coinValueInGP(denom, amount),
    };
    result.coins!.push(coinRes);
    result.sublogs.push(coinRes);
    result.totalValueGP += coinRes.valueGP;
  }

  // Goods roll
  const goodsRow: GoodsEntry = roller.rollOnTable(
    `Treasure (goods) Level ${baseLevel}`,
    goodsTableByLevel[baseLevel],
  );
  if (goodsRow.kind !== "none") {
    const qty = roller.parseAndRoll(
      goodsRow.quantity,
      `Goods quantity L${baseLevel}`,
    );
    for (let i = 0; i < qty; i++) {
      if (goodsRow.kind === "gems") {
        const gemRes = generateGem(roller);
        result.goods!.push(gemRes);
        result.sublogs.push(gemRes);
        result.totalValueGP += gemRes.valueGP;
      } else {
        const artRes = generateArt(roller);
        result.goods!.push(artRes);
        result.sublogs.push(artRes);
        result.totalValueGP += artRes.valueGP;
      }
    }
  }

  // Items roll
  const itemRow = roller.rollOnTable(
    `Treasure (items) Level ${baseLevel}`,
    itemsTableByLevel[baseLevel],
  );
  if (itemRow.kind !== "none") {
    let qty = roller.parseAndRoll(
      itemRow.quantity,
      `Items quantity L${baseLevel} (${itemRow.label})`,
    );
    // Epic adds extra major items above 20
    if (epicLevel) {
      const bonus = epicBonusMajorItems[epicLevel] ?? 0;
      for (let i = 0; i < bonus; i++) {
        const extra = generateMagicItem("major", roller);
        result.items!.push(extra);
        result.sublogs.push(extra);
        result.totalValueGP += extra.price ?? 0;
      }
    }
    for (let i = 0; i < qty; i++) {
      let itemRes: MagicItemResult;
      if (itemRow.kind === "mundane") {
        itemRes = generateMundaneItem(roller);
      } else {
        itemRes = generateMagicItem(itemRow.kind as "minor"|"medium"|"major", roller);
      }
      result.items!.push(itemRes);
      result.sublogs.push(itemRes);
      result.totalValueGP += itemRes.price ?? 0;
    }
  }

  result.log = [...roller.log];
  return result;
}

// -------- Gems --------
export function generateGem(roller: DiceRoller): GoodResult {
  const tier = roller.rollOnTable("Gems", gemTable);
  const value = roller.parseAndRoll(tier.valueDie, "Gem value roll");
  const name = pick(tier.examples, roller, "Gem type");
  return {
    type: "gem",
    name,
    valueGP: value,
    description: `A ${name.toLowerCase()} worth approximately ${value} gp. ${tier.average} gp average for this tier.`,
  };
}

// -------- Art --------
export function generateArt(roller: DiceRoller): GoodResult {
  const tier = roller.rollOnTable("Art objects", artTable);
  const value = roller.parseAndRoll(tier.valueDie, "Art value roll");
  const name = pick(tier.examples, roller, "Art example");
  return {
    type: "art",
    name,
    valueGP: value,
    description: `${name}. Valued at approximately ${value.toLocaleString()} gp (average ${tier.average} gp).`,
  };
}

// -------- Random weapon pick --------
function randomWeapon(type: "commonMelee"|"uncommon"|"commonRanged", roller: DiceRoller): Weapon {
  let list: Weapon[];
  if (type === "commonMelee") list = commonMeleeWeapons;
  else if (type === "uncommon") list = uncommonWeapons;
  else list = commonRangedWeapons;
  return pick(list, roller, `Weapon: ${type}`);
}

// -------- Random armor (non-shield) --------



// Roll size category for armor/weapons:
// 30% Small, 60% Medium, 10% other (d%: 1-40 Tiny, 41-85 Large, 86-100 Huge)
function rollSize(roller: DiceRoller): { size: string; armorCostMult: number; armorWeightMult: number; weaponCostMult: number; weaponWeightMult: number; damageLabel?: string } {
  const r = roller.rollPercent("Size roll");
  let key: string;
  if (r <= 30) key = "Small";
  else if (r <= 90) key = "Medium";
  else {
    const other = roller.roll(1, 100, 0, "Other size breakdown");
    if (other <= 40) key = "Tiny";
    else if (other <= 85) key = "Large";
    else key = "Huge";
  }
  return {
    size: key,
    armorCostMult: armorSizeMultipliers[key].costMult,
    armorWeightMult: armorSizeMultipliers[key].weightMult,
    weaponCostMult: weaponSizeMultipliers[key].costMult,
    weaponWeightMult: weaponSizeMultipliers[key].weightMult,
  };
}

// Weapon damage step up/down by size (roughly per SRD table; d4→d3, d6→d4, etc.)
const damageStep: Record<string, string> = {
  "1": "1", "1d2": "1d3", "1d3": "1d4", "1d4": "1d6", "1d6": "1d8", "1d8": "2d6",
  "2d4": "2d6", "2d6": "3d6", "3d6": "3d8", "1d10": "2d8", "2d8": "3d8", "1d12": "3d6", "2d10": "4d8"
};
const damageStepDown: Record<string, string> = {
  "1d3": "1d2", "1d4": "1d3", "1d6": "1d4", "1d8": "1d6", "2d6": "1d8", "2d4": "1d8",
  "1d10": "1d8", "2d8": "2d6", "1d12": "1d10", "2d10": "2d8", "3d6": "2d6", "3d8": "3d6", "4d8": "3d8"
};

function adjustDamageForSize(baseDmg: string, size: string): string {
  if (size === "Medium") return baseDmg;
  let dmg = baseDmg;
  const steps = size === "Tiny" ? -2 : size === "Small" ? -1 : size === "Large" ? 1 : size === "Huge" ? 2 : 0;
  if (steps === 0) return baseDmg;
  for (let i = 0; i < Math.abs(steps); i++) {
    const table = steps > 0 ? damageStep : damageStepDown;
    dmg = table[dmg] ?? dmg;
  }
  return dmg;
}

// -------- Magic item generation --------
export function generateMagicItem(
  tier: "minor" | "medium" | "major",
  roller: DiceRoller,
): MagicItemResult {
  const startLog = roller.log.length;

  // 5% cursed check
  const cursedRoll = roller.roll(1, 100, 0, "Cursed item check");
  const isCursed = cursedRoll <= 5;

  // Pick category
  const catRoll = roller.rollPercent("Magic item category");
  const catEntry = magicItemMasterTable.find((c) => {
    const range = c[tier];
    return range && catRoll >= range[0] && catRoll <= range[1];
  });
  const category = catEntry?.category ?? "Wondrous items";

  // Roll size BEFORE generating weapons/armor so price multipliers are applied
  let sizeInfo: ReturnType<typeof rollSize> | undefined;
  if (category === "Armor/shields" || category === "Weapons") {
    sizeInfo = rollSize(roller);
  }

  let item: MagicItemResult;
  switch (category) {
    case "Armor/shields":
      item = rollArmorOrShield(tier, roller, sizeInfo);
      break;
    case "Weapons":
      item = rollWeapon(tier, roller, sizeInfo);
      break;
    case "Potions":
      item = rollPotion(tier, roller);
      break;
    case "Rings":
      item = rollRing(tier, roller);
      break;
    case "Rods":
      item = rollRod(tier, roller);
      break;
    case "Scrolls":
      item = rollScroll(tier, roller);
      break;
    case "Staffs":
      item = rollStaff(tier, roller);
      break;
    case "Wands":
      item = rollWand(tier, roller);
      break;
    case "Wondrous items":
    default:
      item = rollWondrous(tier, roller);
      break;
  }

  // Attach size label (already priced in)
  if (sizeInfo) {
    item.size = sizeInfo.size;
  }

  if (isCursed) {
    item.cursed = true;
    // Roll on the full cursed-item list, which supplies the apparent form,
    // complete mechanics and the detection condition, and use those to replace
    // the ordinary item we generated.
    const c = pick(cursedItemsFull, roller, "Table: Cursed Items");
    const apparent = item.name;
    item.name = "CURSED: " + c.name + " (appears to be: " + apparent + ")";
    item.description =
      "**This item is CURSED.**\n\n" +
      "*Apparent form:* it reads as " + apparent + " and radiates magic like the genuine article. detect magic by itself does NOT reveal the curse.\n\n" +
      "*Apparent item description (FALSE):*\n" + (item.description ?? "") + "\n\n" +
      "---\n\n**True identity: " + c.name + "**\n\n" +
      "*What it appears to be:* " + c.appears + "\n\n" +
      "**Mechanics:** " + c.mechanics + "\n\n" +
      "**When the curse is detected:** " + c.detected + "\n\n" +
      "*Removal:* curses on items are not removed by dispel magic. They require remove curse, break enchantment, or stronger magic (wish or miracle). Several cursed items listed above (cursed armor, cursed weapon, cursed shield, necklace of strangulation, periapt of foul rotting, ring of clumsiness, ring of contrariness, robe of powerlessness, stone of weight) cannot be discarded until the curse is broken." +
      "\n\n*Cursed roll:* the 5% cursed-item check came up cursed (rolled " + cursedRoll + " on d%).\n";
  }

  // ---- INTELLIGENT ITEM CHECK (0.5% of eligible items) ----
  // The SRD's own figure is "in general, less than 1% of magic items have
  // intelligence". Only permanent items without charges can be intelligent, and
  // a cursed item is excluded because it is a distinct kind of thing.
  const enhBonusForEgo = readEnhancementBonus(item);
  const abilityBonusForEgo = readAbilityBonus(item);
  if (isEligibleForIntelligence(item.category, item.charges, item.cursed)) {
    const ii = rollIntelligentItem(roller, enhBonusForEgo, abilityBonusForEgo);
    if (ii) {
      item.intelligent = ii;
      item.price = (item.price ?? 0) + ii.priceModifier;
      item.name = `Intelligent ${item.name}`;
      item.description =
        (item.description ? `*Underlying item (non-intelligent form):*\n${item.description}\n\n---\n\n` : "") +
        renderIntelligence(ii);
    }
  }

  const itemLog = roller.log.slice(startLog);
  item.log = itemLog;
  return item;
}

// -------- Armor/Shields --------
// -------- Armor/Shields (full SRD flow, verbatim tables) --------
// One d% on Table: Armor and Shields gives an enhancement bonus, a specific
// armor, a specific shield, or "special ability and roll again".
function rollArmorOrShield(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  sizeInfo?: ReturnType<typeof rollSize>,
): MagicItemResult {
  const costMult = sizeInfo?.armorCostMult ?? 1;
  const sizeLabel = sizeInfo?.size ?? "Medium";
  const sizeNote = sizeLabel !== "Medium" ? ` (${sizeLabel} size)` : "";

  const entry = roller.rollOnTable(`Table: Armor and Shields (${tier} column)`, armorEnhTable[tier]);

  if (entry.kind === "specificArmor") return rollSpecificArmor(tier, roller, sizeInfo);
  if (entry.kind === "specificShield") return rollSpecificShield(tier, roller, sizeInfo);

  const isShield = entry.kind === "enhShield";
  const abilities: ArmorAbility[] = [];
  let enhBonus = entry.bonus ?? 0;

  // "Special ability and roll again": roll one ability, then re-roll this table
  // for the item's actual enhancement bonus.
  if (entry.kind === "abilityRollAgain") {
    const first = rollArmorShieldAbility(tier, roller, isShield, []);
    if (first) abilities.push(first);
    const again = roller.rollOnTable(`Table: Armor and Shields re-roll (${tier})`, armorEnhTable[tier]);
    if (again.kind === "enhShield" || again.kind === "enhArmor") {
      enhBonus = again.bonus ?? 0;
    } else if (again.kind === "specificArmor") {
      const r = rollSpecificArmor(tier, roller, sizeInfo);
      return prependAbilities(r, abilities);
    } else if (again.kind === "specificShield") {
      const r = rollSpecificShield(tier, roller, sizeInfo);
      return prependAbilities(r, abilities);
    } else {
      // "special ability and roll again" again. The SRD resolves this by rolling
      // again; we settle on +1 base (an item with a special ability must have at
      // least +1 enhancement bonus) and stop.
      enhBonus = 1;
      const more = rollArmorShieldAbility(tier, roller, isShield, abilities);
      if (more) abilities.push(more);
    }
  }

  // Fill remaining bonus budget with further abilities.
  if (enhBonus >= 2) {
    for (let i = 0; i < 4; i++) {
      if (enhBonus + abilities.reduce((s, a) => s + (a.bonusEq ?? 0), 0) >= Math.min(10, enhBonus + 2)) break;
      const ab = rollArmorShieldAbility(tier, roller, isShield, abilities);
      if (!ab) break;
      abilities.push(ab);
    }
  }

  // Base item from the SRD weighted tables.
  const base = isShield
    ? roller.rollOnTable("Table: Random Shield Type", randomShieldType)
    : roller.rollOnTable("Table: Random Armor Type", randomArmorType as any);
  const kind = isShield ? "shield" : "armor";
  const weightClass = (base as any).category as "light"|"medium"|"heavy"|undefined;

  // SRD special material roll: 01-95 standard, 96-100 special material.
  const mat = rollSpecialMaterial(kind, weightClass, roller, base.mwCost);

  const basePortion = Math.round(base.mwCost * costMult);
  const enhancementCost = enhBonus * enhBonus * 1000;
  const abilityCost = abilities.reduce((s, a) => s + (a.fixedGP ?? bonusEquivalentCost(a.bonusEq ?? 0, enhBonus, 1000)), 0);
  const matCost = Math.round((mat?.cost ?? 0) * (kind === "armor" ? costMult : 1));
  const totalPrice = basePortion + enhancementCost + abilityCost + matCost;

  const abilityNames = abilities.map(a => a.name).join(", ");
  const nameStr =
    `+${enhBonus} ${mat ? mat.name + " " : ""}${base.name}` +
    (abilities.length ? ` of ${abilityNames}` : "") + sizeNote;

  return {
    id: `armor-${Math.random().toString(36).slice(2, 9)}`,
    category: isShield ? "Magic shield" : "Magic armor",
    name: nameStr,
    price: totalPrice,
    description:
      `A ${sizeLabel}${mat ? " " + mat.name.toLowerCase() : ""} ${base.name} with a +${enhBonus} enhancement bonus` +
      (abilities.length ? ` and special abilities: ${abilityNames}.` : ".") +
      `\n\n*Base ${kind}:* ${base.name}${weightClass ? ` (${weightClass} armour)` : ""}, masterwork-inclusive cost ${base.mwCost} gp.` +
      `\n\nAll magic armor and shields are automatically masterwork (armor check penalty 1 lower than normal). Magic armor bonuses never rise above +5. Each +1 of enhancement bonus adds 2 to a shield's hardness and +10 to its hit points.` +
      abilities.map(a => `\n\n**${a.name}** (${a.mod}, ${a.aura}, CL ${a.cl}). ${a.description}${a.restriction ? `\n\n_Restriction:_ ${a.restriction}` : ""}`).join("") +
      (mat ? `\n\n**Special material: ${mat.name}**\n\n${mat.effect}\n\n_Cost:_ ${mat.costNote}` : "") +
      `\n\n*Price breakdown:* base ${basePortion} gp` +
      (sizeLabel !== "Medium" ? ` [${base.mwCost} x${costMult}]` : "") +
      ` + enhancement ${enhancementCost} gp` +
      (abilityCost ? ` + abilities ${abilityCost} gp` : "") +
      (matCost ? ` + material ${matCost} gp` : "") +
      ` = ${totalPrice.toLocaleString()} gp.` +
      `\n\n*Caster level:* ${enhBonus * 3} (three times the enhancement bonus)${abilities.length ? `, or the higher of this and the ability's own CL requirement.` : "."}`,
    log: [],
  };
}

function prependAbilities(item: MagicItemResult, abilities: ArmorAbility[]): MagicItemResult {
  if (!abilities.length) return item;
  return {
    ...item,
    description:
      `*Special ability rolled first, before the re-roll landed on a specific item:* ` +
      abilities.map(a => a.name).join(", ") + " — " +
      abilities.map(a => a.description).join(" ") +
      `\n\n---\n\n` + (item.description ?? ""),
  };
}

// Cost of going from an existing enhancement bonus to a higher one, in gp.
function bonusEquivalentCost(abBonus: number, currentEnh: number, multiplier: number): number {
  if (abBonus <= 0) return 0;
  return (Math.pow(currentEnh + abBonus, 2) - Math.pow(currentEnh, 2)) * multiplier;
}

// Roll one armor/shield special ability from the correct SRD table.
function rollArmorShieldAbility(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  isShield: boolean,
  existing: ArmorAbility[],
): ArmorAbility | undefined {
  const table = isShield ? shieldAbilitiesSRD : armorAbilitiesSRD;
  const used = new Set(existing.map(e => e.name.replace(/, (light|moderate|heavy|improved|greater)$/, "")));
  for (let attempt = 0; attempt < 12; attempt++) {
    const r = roller.rollPercent(`Table: ${isShield ? "Shield" : "Armor"} Special Abilities (${tier})`);
    const found = table.find(a => {
      const range = tier === "minor" ? a.minor : tier === "medium" ? a.medium : a.major;
      return range && r >= range[0] && r <= range[1];
    });
    if (!found) continue;
    if (found.name === "Roll twice again") {
      // SRD: "Roll twice again" — recurse twice.
      const a = rollArmorShieldAbility(tier, roller, isShield, existing);
      const b = rollArmorShieldAbility(tier, roller, isShield, existing);
      return a ?? b;
    }
    // "If you roll a special ability twice, only one counts. If you roll two
    //  versions of the same special ability, use the better."
    const baseName = found.name.replace(/, (light|moderate|heavy|improved|greater)$/, "");
    if (used.has(baseName)) continue;
    return found;
  }
  return undefined;
}

// SRD special material roll, with the exact cost modifiers from specialMaterials.htm.
function rollSpecialMaterial(
  kind: "armor" | "shield" | "weapon" | "ammunition",
  weightClass: "light"|"medium"|"heavy"|undefined,
  roller: DiceRoller,
  baseCost: number,
): { name: string; cost: number; costNote: string; effect: string } | undefined {
  const r = roller.rollOnTable("Special material roll (01-95 standard, 96-100 special)", specialMaterialRoll);
  if (!r.material) return undefined;

  // The SRD lists which materials are legal for which item kinds but gives no
  // distribution among them. We roll uniformly among the LEGAL options.
  const legal = specialMaterialsSRD.filter(m => m.appliesTo.includes(kind as any));
  const mat = pick(legal.length ? legal : specialMaterialsSRD, roller, "Special material (uniform among legal)");

  const cost = mat.costFor(kind as any, weightClass, baseCost);
  return { name: mat.name, cost, costNote: mat.costNote, effect: mat.effect };
}

function rollSpecificArmor(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  sizeInfo?: ReturnType<typeof rollSize>,
): MagicItemResult {
  const costMult = sizeInfo?.armorCostMult ?? 1;
  const sizeLabel = sizeInfo?.size ?? "Medium";
  const pool = specificArmorsSRD.filter(s => (s.tiers as any)[tier]);
  const table = pool.map(s => {
    const [a, b] = (s.tiers as any)[tier] as [number, number];
    return { min: a, max: b, name: s.name };
  });
  const rolled = roller.rollOnTable("Table: Specific Armors", table);
  const spec = specificArmorsSRD.find(s => s.name === rolled.name)!;
  // SRD: "The cost of the masterwork quality and any magical enhancement remains
  // the same" for unusually sized creatures, so only the mundane base is scaled.
  const basePortion = Math.round((spec.baseArmorCost ?? 0) * costMult);
  const price = spec.price - (spec.baseArmorCost ?? 0) + basePortion;
  return {
    id: `spec-armor-${Math.random().toString(36).slice(2, 9)}`,
    category: "Magic armor",
    name: `${spec.name}${sizeLabel !== "Medium" ? ` (${sizeLabel})` : ""}`,
    price,
    description:
      `*Table: Specific Armors (${tier}).*\n\n${spec.description}` +
      (sizeLabel !== "Medium"
        ? `\n\n_Size:_ the mundane base cost (${spec.baseArmorCost ?? 0} gp) is scaled by ${costMult} for ${sizeLabel}; the masterwork quality and any magical enhancement are unchanged. Price ${spec.price.toLocaleString()} gp -> ${price.toLocaleString()} gp.`
        : "") +
      `\n\nPrice: ${price.toLocaleString()} gp.`,
    log: [],
  };
}

function rollSpecificShield(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  sizeInfo?: ReturnType<typeof rollSize>,
): MagicItemResult {
  const costMult = sizeInfo?.armorCostMult ?? 1;
  const sizeLabel = sizeInfo?.size ?? "Medium";
  const pool = specificShieldsSRD.filter(s => (s.tiers as any)[tier]);
  const table = pool.map(s => {
    const [a, b] = (s.tiers as any)[tier] as [number, number];
    return { min: a, max: b, name: s.name };
  });
  const rolled = roller.rollOnTable("Table: Specific Shields", table);
  const spec = specificShieldsSRD.find(s => s.name === rolled.name)!;
  const basePortion = Math.round((spec.baseShieldCost ?? 0) * costMult);
  const price = spec.price - (spec.baseShieldCost ?? 0) + basePortion;

  // Caster's shield: the SRD specifies sub-rolls.
  let casterNote = "";
  if (spec.name === "Caster's shield") {
    const hasScroll = roller.rollPercent("Caster's shield: scribed spell? (50%)") <= 50;
    if (hasScroll) {
      const divine = roller.rollPercent("Caster's shield: divine (01-80) or arcane (81-100)") <= 80;
      const lvl = 1 + Math.floor(Math.random() * 3);
      const tbl = divine ? divineScrollSpells[lvl] : arcaneScrollSpells[lvl];
      const row = roller.rollOnTable(
        `Caster's shield: Table: ${divine ? "Divine" : "Arcane"} Spell Scrolls, level ${lvl}`,
        tbl ?? [],
      );
      const nm = row.name;
      const value = Math.floor(scrollPrice(lvl, Math.max(1, lvl * 2 - 1)) / 2);
      casterNote = `\n\n**Scribed spell (rolled):** ${nm} — a level ${lvl} ${divine ? "divine" : "arcane"} spell is currently scribed on the strip. Its scroll value is ${value.toLocaleString()} gp (half the base raw material cost), which is ADDED to the shield's 3,153 gp price.`;
    } else {
      casterNote = `\n\n**Scribed spell (rolled):** none. The scribing strip is blank.`;
    }
  }

  return {
    id: `spec-shield-${Math.random().toString(36).slice(2, 9)}`,
    category: "Magic shield",
    name: `${spec.name}${sizeLabel !== "Medium" ? ` (${sizeLabel})` : ""}`,
    price,
    description:
      `*Table: Specific Shields (${tier}).*\n\n${spec.description}${casterNote}` +
      (sizeLabel !== "Medium"
        ? `\n\n_Size:_ mundane base cost scaled by ${costMult}; price ${spec.price.toLocaleString()} gp -> ${price.toLocaleString()} gp.`
        : "") +
      `\n\nPrice: ${price.toLocaleString()} gp.`,
    log: [],
  };
}

// -------- Weapons (full SRD flow, verbatim tables) --------
function rollWeapon(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  sizeInfo?: ReturnType<typeof rollSize>,
): MagicItemResult {
  const costMult = sizeInfo?.weaponCostMult ?? 1;
  const weightMult = sizeInfo?.weaponWeightMult ?? 1;
  const sizeLabel = sizeInfo?.size ?? "Medium";
  const sizeNote = sizeLabel !== "Medium" ? ` (${sizeLabel} size)` : "";

  // Table: Weapon Type Determination, then the weighted base-weapon table.
  const typeRoll = roller.rollOnTable("Table: Weapon Type Determination", weaponTypeTable);
  let baseName = "";
  let baseCost = 0;
  let isDouble = false;
  let isAmmunition = false;
  let baseWeight = 1;

  if (typeRoll.type === "commonMelee") {
    const b = roller.rollOnTable("Table: Common Melee Weapons", commonMeleeTableSRD as any);
    baseName = b.name; baseCost = b.cost; isDouble = !!b.double;
    baseWeight = lookupWeight(b.name);
  } else if (typeRoll.type === "uncommon") {
    const b = roller.rollOnTable("Table: Uncommon Weapons", uncommonTableSRD as any);
    baseName = b.name; baseCost = b.cost; isDouble = !!b.double;
    baseWeight = lookupWeight(b.name);
  } else {
    const b = roller.rollOnTable("Table: Common Ranged Weapons", commonRangedTableSRD as any);
    baseName = b.name; baseCost = b.cost;
    baseWeight = lookupWeight(b.name);
    if ((b as any).ammo) {
      const a = roller.rollOnTable("Ammunition sub-table", ammunitionTableSRD as any);
      baseName = a.name; baseCost = a.cost;
      isAmmunition = true;
      baseWeight = 0.1;
    }
  }
  const isRanged = typeRoll.type === "commonRanged";

  const entry = roller.rollOnTable(`Table: Weapons (${tier} column)`, weaponEnhTable[tier]);
  if (entry.kind === "specific") return rollSpecificWeapon(tier, roller, sizeInfo, isRanged);

  // Melee and ranged weapons roll on DIFFERENT ability tables, per the SRD:
  // "See Table: Melee Weapon Special Abilities for melee weapons or Table:
  //  Ranged Weapon Special Abilities for ranged weapons."
  const abilityTable = isRanged ? rangedWeaponAbilitiesSRD : meleeWeaponAbilitiesSRD;
  const dmgType = lookupDmgType(baseName);
  const abilities: WeaponAbilitySRD[] = [];
  const rerollNotes: string[] = [];
  let enhBonus = entry.bonus ?? 0;

  // "Special ability and roll again": roll ONCE on the ability table (which may
  // itself be "Roll again twice", adding two more), then re-roll Table: Weapons
  // for the item's enhancement bonus. The SRD grants no further abilities beyond
  // these, so there is no loop filling the +10 budget.
  if (entry.kind === "abilityRollAgain") {
    const first = rollWeaponAbility(tier, roller, abilityTable, [], 0, isRanged, dmgType, baseName);
    rerollNotes.push(...first.rerolls);
    if (first.ability) abilities.push(first.ability);
    abilities.push(...first.extraAbilities);

    const again = roller.rollOnTable(`Table: Weapons re-roll (${tier})`, weaponEnhTable[tier]);
    if (again.kind === "enh") {
      enhBonus = again.bonus ?? 0;
      // Footnote 5: "if the extra ability puts you over the +10 limit" reroll.
      // Because the ability was rolled before the bonus was known, discard the
      // most recently rolled abilities until the total is within +10.
      while (enhBonus + abilityBonusTotal(abilities) > 10 && abilities.length) {
        const dropped = abilities.pop()!;
        rerollNotes.push(
          `discarded ${dropped.name} (+${dropped.bonusEq}) — with the +${enhBonus} ` +
          `enhancement bonus the total would exceed the +10 limit`
        );
      }
    } else if (again.kind === "specific") {
      const r = rollSpecificWeapon(tier, roller, sizeInfo, isRanged);
      if (abilities.length) {
        r.description = `*Special ability rolled first, before the re-roll landed on a specific weapon:* ` +
          abilities.map(a => a.name).join(", ") + " — " +
          abilities.map(a => a.description).join(" ") +
          `\n\n*Discarded rolls:* ${rerollNotes.length ? rerollNotes.join("; ") : "none"}` +
          `\n\n---\n\n` + (r.description ?? "");
      }
      return r;
    } else {
      // "Special ability and roll again" twice. A weapon with a special ability
      // must have at least a +1 enhancement bonus, so settle on +1 and stop.
      enhBonus = 1;
      const more = rollWeaponAbility(tier, roller, abilityTable, abilities, enhBonus, isRanged, dmgType, baseName);
      rerollNotes.push(...more.rerolls);
      if (more.ability) abilities.push(more.ability);
      abilities.push(...more.extraAbilities);
    }
  }

  // Double weapons: SRD rules for the second head.
  let secondHeadNote = "";
  let doubleCost = 0;
  if (isDouble) {
    const r = roller.rollPercent("Double weapon second head (01-50 same bonus, 51-100 one less)");
    if (r <= 50) {
      doubleCost = enhBonus * enhBonus * 2000;
      secondHeadNote = `\n\n**Second head (rolled ${r}, 01-50):** the same +${enhBonus} enhancement bonus as the main head, doubling the cost of the bonus (+${(enhBonus*enhBonus*2000).toLocaleString()} gp). It has no special abilities.`;
    } else {
      secondHeadNote = `\n\n**Second head (rolled ${r}, 51-100):** an enhancement bonus of +${Math.max(1, enhBonus - 1)}, one less than the main head, and it has no special abilities. The reduced bonus cost is already included in the enhancement figure above.`;
    }
    // Double masterwork cost: +300 gp per head.
  }

  // Ability-specific sub-rolls.
  let extra = "";
  for (const ab of abilities) {
    if (ab.name === "Bane") {
      const foe = roller.rollOnTable("Table: Bane designated foe", baneFoeTableSRD);
      extra += `\n\n**Bane designated foe (rolled):** ${foe.label}. Against this foe the effective enhancement bonus is +2 higher and it deals an extra 2d6 points of damage.`;
    }
    if (ab.name === "Spell storing") {
      const lvl = 1 + Math.floor(Math.random() * 3);
      const row = roller.rollOnTable(
        `Spell storing: Table: Arcane Spell Scrolls, level ${lvl}`,
        arcaneScrollSpells[lvl] ?? [],
      );
      extra += `\n\n**Spell storing (rolled):** a single targeted level ${lvl} spell — **${row.name}** — is currently stored. It is released as a free action the first time the weapon deals damage after being loaded.`;
    }
  }

  // Special material roll (SRD applies this to weapons and ammunition).
  const mat = rollSpecialMaterial(isAmmunition ? "ammunition" : "weapon", undefined, roller, baseCost);

  const dmg = lookupDamage(baseName)
    ? lookupWeaponDamage(lookupDamage(baseName), sizeLabel)
    : "";
  const basePortion = Math.round(baseCost * costMult);
  const weight = Math.round(baseWeight * weightMult * 10) / 10;
  const masterwork = isDouble ? 600 : 300;   // SRD: +300 gp per head for double weapons
  const enhancementCost = enhBonus * enhBonus * 2000 + doubleCost;
  const abilityCost = abilities.reduce((s, a) => s + bonusEquivalentCost(a.bonusEq ?? 0, enhBonus, 2000), 0);
  let matCost = Math.round(mat?.cost ?? 0);
  if (mat?.name === "Cold iron") matCost = Math.round(baseCost * 2) + 2000 * (1 + abilities.length);
  const totalPrice = Math.max(0, Math.round(basePortion + masterwork + enhancementCost + abilityCost + matCost));

  const abilityNames = abilities.map(a => a.name).join(", ");
  return {
    id: `weapon-${Math.random().toString(36).slice(2, 9)}`,
    category: "Magic weapon",
    name: `+${enhBonus} ${mat ? mat.name + " " : ""}${baseName}${abilities.length ? ` of ${abilityNames}` : ""}${sizeNote}`,
    price: totalPrice,
    description:
      `A ${sizeLabel} magic ${mat ? mat.name.toLowerCase() + " " : ""}${baseName}${isDouble ? " (a double weapon)" : ""}${isAmmunition ? " (a kind of ammunition)" : ""} with a +${enhBonus} enhancement bonus` +
      (abilities.length ? ` and special abilities: ${abilityNames}.` : ".") +
      `\n\n*Base weapon:* ${baseName}, masterwork-inclusive cost ${baseCost} gp, weight ${weight} lb${dmg ? `, damage ${dmg}` : ""}${dmgType ? `, damage type ${dmgType}` : ""}.` +
      `\n\n*Ability table rolled:* Table: ${isRanged ? "Ranged" : "Melee"} Weapon Special Abilities, as the SRD directs for ${isRanged ? "ranged" : "melee"} weapons.` +
      `\n\n*Total effective bonus:* +${enhBonus} enhancement + ${abilities.reduce((x,a)=>x+(a.bonusEq??0),0)} from special abilities = +${enhBonus + abilities.reduce((x,a)=>x+(a.bonusEq??0),0)}${enhBonus + abilities.reduce((x,a)=>x+(a.bonusEq??0),0) > 10 ? " — OVER THE +10 LIMIT" : " (within the +10 limit)"}.` +
      (rerollNotes.length ? `\n\n*Discarded rolls (each was rerolled as the SRD directs):*\n${rerollNotes.map(r => "  - " + r).join("\n")}` : `\n\n*Discarded rolls:* none — every ability roll was accepted on its first result.`) +
      `\n\nAll magic weapons are masterwork weapons, but the masterwork +1 on attack rolls does not stack with the enhancement bonus. Enhancement bonuses apply to both attack and damage rolls and never exceed +5. Each +1 of enhancement bonus adds 2 to a weapon's hardness and +10 to its hit points. Additional damage dice from special abilities are NOT multiplied on a critical hit.` +
      `\n\n*Enhancement cost:* ${enhBonus} x ${enhBonus} x 2,000 gp = ${(enhBonus*enhBonus*2000).toLocaleString()} gp (SRD Base Price column).` +
      abilities.map(a => `\n\n**${a.name}** (${a.mod}, ${a.aura}, CL ${a.cl}). ${a.description}${a.restriction ? `\n\n_Restriction:_ ${a.restriction}` : ""}`).join("") +
      extra + secondHeadNote +
      (mat ? `\n\n**Special material: ${mat.name}**\n\n${mat.effect}\n\n_Cost:_ ${mat.costNote}` : "") +
      `\n\n*Price breakdown:* base ${basePortion} gp` +
      (sizeLabel !== "Medium" ? ` [${baseCost} x${costMult}]` : "") +
      ` + masterwork ${masterwork} gp + enhancement ${enhancementCost} gp` +
      (abilityCost ? ` + abilities ${abilityCost} gp` : "") +
      (matCost ? ` + material ${matCost} gp` : "") +
      ` = ${totalPrice.toLocaleString()} gp.` +
      `\n\n*Caster level:* ${enhBonus * 3} (three times the enhancement bonus)${abilities.length ? `, or the higher of this and the abilities' own CL requirements.` : "."}` +
      `\n\n*Special qualities (rolled):* ` +
      (() => {
        const sq = isRanged ? rangedWeaponSpecialQualities : meleeWeaponSpecialQualities;
        return roller.rollOnTable(`Weapon special qualities (${isRanged ? "ranged" : "melee"})`, sq).result;
      })() +
      `\n\n*Light generation:* the SRD states that fully 30% of magic weapons shed light equivalent to a light spell (bright light in a 20-foot radius, shadowy light in a 40-foot radius). Such a weapon cannot be concealed when drawn and its light cannot be shut off.`,
    log: [],
  };
}

// ---------------------------------------------------------------------------
// Special-ability rolling, implementing every footnote of
// Table: Melee Weapon Special Abilities and Table: Ranged Weapon Special
// Abilities.
//
// Melee footnotes:
//   1. Add to enhancement bonus on Table: Weapons to determine total market price.
//   2. Piercing or slashing weapons only. Reroll if randomly generated for a
//      bludgeoning weapon.                                 [-> Keen]
//   3. Bludgeoning weapons only. Reroll if randomly generated for a piercing or
//      slashing weapon.                                    [-> Disruption]
//   4. Slashing weapons only. Reroll if randomly generated for a piercing or
//      bludgeoning weapon.                                 [-> Vorpal]
//   5. Reroll if you get a duplicate special ability, an ability incompatible
//      with an ability that you've already rolled, or if the extra ability puts
//      you over the +10 limit. A weapon's enhancement bonus and special ability
//      bonus equivalents can't total more than +10.
//
// Ranged footnotes:
//   1. Add to enhancement bonus on Table: Weapons to determine total market price.
//   2. Reroll if you get a duplicate special ability, an ability incompatible
//      with an ability that you've already rolled, or if the extra ability puts
//      you over the +10 limit. A weapon's enhancement bonus and special ability
//      bonus equivalents can't total more than +10.
// ---------------------------------------------------------------------------

// Test whether a weapon's damage type permits an ability. A weapon whose type
// is "B or P" counts as capable of both B and P (the wielder chooses), so it
// passes a "piercing only" test and a "bludgeoning only" test alike.
function dmgAllows(dmgType: string | undefined, needed: "P" | "S" | "B"): boolean {
  if (!dmgType || dmgType === "—") return false;
  const parts = dmgType.split(/\s+or\s+/i).map(x => x.trim().toUpperCase());
  return parts.includes(needed);
}

// Footnote 5 of both tables requires a reroll for "an ability incompatible with
// an ability that you've already rolled". The SRD does not enumerate which pairs
// are incompatible; this matrix is derived from the ability descriptions, each of
// which states that it supersedes or builds on another ability:
//   Flaming burst  — "a flaming burst weapon functions as a flaming weapon"
//   Icy burst      — "an icy burst weapon functions as a frost weapon"
//   Shocking burst — "a shocking burst weapon functions as a shock weapon"
//   Vorpal         — "a vorpal weapon functions as a keen weapon" (vs. no heads)
// Throwing and Returning both make the weapon return to the wielder.
const INCOMPATIBLE: Record<string, string[]> = {
  "Flaming burst": ["Flaming"],
  "Icy burst": ["Frost"],
  "Shocking burst": ["Shock"],
  "Flaming": ["Flaming burst"],
  "Frost": ["Icy burst"],
  "Shock": ["Shocking burst"],
  "Vorpal": ["Keen"],
  "Keen": ["Vorpal"],
  "Throwing": ["Returning"],
  "Returning": ["Throwing"],
};

// Total special-ability bonus equivalents already on the weapon.
function abilityBonusTotal(abilities: WeaponAbilitySRD[]): number {
  return abilities.reduce((s, a) => s + (a.bonusEq ?? 0), 0);
}

// Footnote 2/3/4 weapon-type restrictions, plus footnote 5's duplicate,
// incompatibility and +10 checks. Returns a reason string when the roll must be
// rerolled, or null when the ability may be taken.
function abilityRejectionReason(
  found: WeaponAbilitySRD,
  dmgType: string | undefined,
  existing: WeaponAbilitySRD[],
  enhBonus: number,
  isRanged: boolean,
  baseName: string,
): string | null {
  // Melee table footnotes 2, 3 and 4.
  if (found.name === "Keen") {
    // Piercing or slashing only; reroll for a bludgeoning weapon.
    if (!dmgAllows(dmgType, "P") && !dmgAllows(dmgType, "S")) return "Keen requires a piercing or slashing weapon";
  }
  if (found.name === "Disruption") {
    // Bludgeoning only; reroll for a piercing or slashing weapon.
    if (!dmgAllows(dmgType, "B")) return "Disruption requires a bludgeoning weapon";
  }
  if (found.name === "Vorpal") {
    // Slashing only; reroll for a piercing or bludgeoning weapon.
    if (!dmgAllows(dmgType, "S")) return "Vorpal requires a slashing weapon";
  }
  // Both tables' Bane/Brilliant-energy/Returning notes from the descriptions.
  if (/^(bow|crossbow|sling)/i.test(baseName) || /bow|sling/i.test(baseName)) {
    if (found.name === "Returning") return "Returning cannot be applied to bows, crossbows, or slings";
  }
  if (found.name === "Brilliant energy") {
    // "This property can only be applied to melee weapons, thrown weapons, and
    //  ammunition." Projectile launchers are excluded.
    if (isRanged && /bow|crossbow|sling/i.test(baseName)) {
      return "Brilliant energy can only be applied to melee weapons, thrown weapons, and ammunition";
    }
  }
  // Footnote 5, clause 1: duplicates.
  if (existing.some(e => e.name === found.name)) return `duplicate of ${found.name}`;
  // Footnote 5, clause 2: incompatibility.
  const bad = INCOMPATIBLE[found.name] ?? [];
  for (const e of existing) {
    if (bad.includes(e.name)) return `incompatible with ${e.name}`;
    if ((INCOMPATIBLE[e.name] ?? []).includes(found.name)) return `incompatible with ${e.name}`;
  }
  // Footnote 5, clause 3: the +10 limit.
  const total = enhBonus + abilityBonusTotal(existing) + (found.bonusEq ?? 0);
  if (total > 10) return `would put the total at +${total}, over the +10 limit`;
  return null;
}

// Roll one special ability. Every rejection causes a genuine reroll, and the
// discarded rolls are recorded in the dice log with the reason.
function rollWeaponAbility(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  table: WeaponAbilitySRD[],
  existing: WeaponAbilitySRD[],
  enhBonus: number,
  isRanged: boolean,
  dmgType: string | undefined,
  baseName: string,
): { ability?: WeaponAbilitySRD; extraAbilities: WeaponAbilitySRD[]; rerolls: string[] } {
  const rerolls: string[] = [];
  for (let attempt = 0; attempt < 30; attempt++) {
    const r = roller.rollPercent(`Table: ${isRanged ? "Ranged" : "Melee"} Weapon Special Abilities (${tier})`);
    const found = table.find(a => {
      const range = tier === "minor" ? a.minor : tier === "medium" ? a.medium : a.major;
      return range && r >= range[0] && r <= range[1];
    });
    if (!found) { rerolls.push(`d% ${r} matched no band (rerolled)`); continue; }

    // "Roll again twice": roll twice more, adding both results.
    if (found.name === "Roll again twice") {
      const first = rollWeaponAbility(tier, roller, table, existing, enhBonus, isRanged, dmgType, baseName);
      rerolls.push(...first.rerolls);
      const afterFirst = [...existing, first.ability, ...first.extraAbilities]
        .filter((x): x is WeaponAbilitySRD => !!x);
      const second = rollWeaponAbility(tier, roller, table, afterFirst, enhBonus, isRanged, dmgType, baseName);
      rerolls.push(...second.rerolls);
      const extras = [first.ability, second.ability].filter((x): x is WeaponAbilitySRD => !!x);
      return { extraAbilities: extras, rerolls };
    }

    const reason = abilityRejectionReason(found, dmgType, existing, enhBonus, isRanged, baseName);
    if (reason) { rerolls.push(`rolled ${found.name} — ${reason} (rerolled)`); continue; }
    return { ability: found, extraAbilities: [], rerolls };
  }
  return { extraAbilities: [], rerolls };
}


function rollSpecificWeapon(
  tier: "minor"|"medium"|"major",
  roller: DiceRoller,
  sizeInfo: ReturnType<typeof rollSize> | undefined,
  isRanged: boolean,
): MagicItemResult {
  void isRanged;
  const costMult = sizeInfo?.weaponCostMult ?? 1;
  const sizeLabel = sizeInfo?.size ?? "Medium";
  const pool = specificWeaponsTableSRD.filter(s => (s as any)[tier]);
  const table = pool.map(s => {
    const [a, b] = (s as any)[tier] as [number, number];
    return { min: a, max: b, name: s.name };
  });
  const rolled = roller.rollOnTable("Table: Specific Weapons", table);
  const spec = specificWeaponsTableSRD.find(s => s.name === rolled.name)!;
  const price = Math.round(spec.price * costMult);

  // Slaying arrows: roll the designated type/subtype.
  let slayingNote = "";
  if (/slaying arrow/i.test(spec.name)) {
    const foe = roller.rollOnTable("Table: Slaying arrow designated type", baneFoeTableSRD);
    slayingNote = `\n\n**Designated type or subtype (rolled):** ${foe.label}.`;
  }

  return {
    id: `spec-weapon-${Math.random().toString(36).slice(2, 9)}`,
    category: "Magic weapon",
    name: `${spec.name}${sizeLabel !== "Medium" ? ` (${sizeLabel})` : ""}`,
    price,
    description:
      `*Table: Specific Weapons (${tier}).*\n\n${spec.description}${slayingNote}` +
      `\n\n*${spec.aura}${spec.cl ? `; CL ${spec.cl}th` : ""}.*` +
      (sizeLabel !== "Medium"
        ? `\n\n_Size:_ the SRD's weapon table gives no per-size pricing for specific weapons. Only the mundane base portion would normally scale; since the SRD does not decompose these prices, the whole figure is scaled here (${spec.price.toLocaleString()} gp x${costMult} = ${price.toLocaleString()} gp). This is flagged as an interpretation — see EngineLight.txt.`
        : "") +
      `\n\nPrice: ${price.toLocaleString()} gp.`,
    log: [],
  };
}
// -------- Potions and Oils (correct SRD Table: Potions and Oils) --------
function rollPotion(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  const tbl = potionTables[tier];
  const picked = roller.rollOnTable(`Table: Potions and Oils (${tier} column)`, tbl);
  const e = picked.e;
  const price = e.price;

  let resolved = "";
  // SRD sub-rolls for parameterised potions
  if (e.subRoll === "alignment") {
    const a = pick(alignments, roller, "Alignment (protection/magic circle)");
    resolved += `\n\n**Alignment:** ${a}.`;
  }
  if (e.subRoll === "energyTypeResist" || e.subRoll === "energyTypeProt") {
    const t = pick(energyTypes, roller, "Energy type");
    resolved += `\n\n**Energy type:** ${t}.`;
  }

  const kindLabel = e.form === "oil" ? "Oil" : "Potion";
  return {
    id: `potion-${Math.random().toString(36).slice(2, 9)}`,
    category: "Potion/oil",
    name: `${kindLabel} of ${e.spell}${e.note ? ` (${e.note})` : ""}`,
    price,
    description:
      `*${kindLabel} (${tier}).*\n\n` +
      `This ${e.form === "oil" ? "oil is applied externally rather than imbibed" : "potion is a magic liquid that produces its effect when imbibed"}. A potion or oil can be used only once. It duplicates the effect of a spell of up to 3rd level that has a casting time of less than 1 minute.` +
      `\n\n*Spell:* ${e.spell}${e.note ? ` ${e.note}` : ""} — caster level ${e.cl} (the minimum caster level needed to cast the spell, unless otherwise specified).` +
      `\n\n*Spell description:* ${spellLookup(e.spell)}` +
      resolved +
      `\n\n*Activation:* drinking a potion or using an oil is a standard action and provokes attacks of opportunity. The character taking the potion does not get to make decisions about the effect — the caster who brewed it already did so. The drinker is both the effective target and the caster of the effect. The person applying an oil is the effective caster, but the object is the target. Incorporeal creatures cannot use potions or oils.` +
      `\n\n*Physical description:* 1 ounce of liquid in a ceramic or glass vial with a tight stopper, no more than 1 inch wide and 2 inches high (AC 13, 1 hp, hardness 1, break DC 12).` +
      `\n\nPrice: ${price.toLocaleString()} gp.`,
    log: [],
  };
}

// Look up a spell's description from the complete SRD spell set. Returns the
// verbatim SRD text where the spell exists, and an explicit placeholder naming
// the spell where it does not (which should now be rare).
function spellLookup(name: string): string {
  // Try the raw name first, because some table entries carry a parenthesised
  // placeholder that is itself part of the alias ("Protection from (alignment)").
  // Only then strip the parentheses and retry.
  const sp =
    findSRDSpell(name) ??
    findSRDSpell(name.replace(/\s*\(.*\)\s*$/, "")) ??
    findSRDSpell(name.replace(/\s*\(type\)\s*/, "").trim());
  if (!sp) {
    return `*(Full description in the SRD: ${name}. This spell is not in the engine's spell set.)*`;
  }
  const bits = [
    sp.school ? `*${sp.school}*` : "",
    sp.level ? `Level: ${sp.level}` : "",
    sp.castingTime ? `Casting Time: ${sp.castingTime}` : "",
    sp.range ? `Range: ${sp.range}` : "",
    sp.effect ? `Effect: ${sp.effect}` : "",
    sp.targets ? `Targets: ${sp.targets}` : "",
    sp.area ? `Area: ${sp.area}` : "",
    sp.duration ? `Duration: ${sp.duration}` : "",
    sp.savingThrow ? `Saving Throw: ${sp.savingThrow}` : "",
    sp.spellResistance ? `Spell Resistance: ${sp.spellResistance}` : "",
  ].filter(Boolean);
  return (bits.length ? bits.join("; ") + "\n\n" : "") + sp.description;
}
// -------- Rings (correct SRD Table: Rings) --------
function rollRing(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  // Rings are never minor/medium/major distinct tables in the SRD — one table
  // with three d% columns. We roll on the column for this item's tier.
  const column = srdRingTable[tier];
  const picked = roller.rollOnTable(`Table: Rings (${tier} column)`, column);
  const name = picked.name;
  const ring = ringDetails[name];
  if (!ring) {
    // Should be unreachable; fall back to a plain entry.
    return {
      id: `ring-${Math.random().toString(36).slice(2, 9)}`,
      category: "Ring", name, description: name, log: [],
    };
  }

  // Resolve SRD-mandated random sub-rolls.
  let resolved = "";
  let charges: number | undefined;

  // Ring of the ram: 50 charges; SRD says charged items found in treasure have
  // d%/2 charges (round down, minimum 1).
  if (ring.charges === "50") {
    const d = roller.roll(1, 100, 0, "Ring of the ram charges (d%/2)");
    charges = Math.max(1, Math.floor(d / 2));
    resolved += `\n\n**Charges remaining:** ${charges} of 50.`;
  }

  // Three wishes: "roll 1d3 to determine the remaining number of rubies."
  if (ring.randomRoll?.includes("1d3 remaining rubies")) {
    const rubies = roller.roll(1, 3, 0, "Three wishes rubies remaining (1d3)");
    resolved += `\n\n**Rubies (wishes) remaining:** ${rubies} of 3.`;
  }

  // Energy resistance: energy type is rolled.
  if (ring.randomRoll?.startsWith("energy type")) {
    const t = ["acid", "cold", "electricity", "fire", "sonic"];
    const el = pick(t, roller, "Energy resistance type");
    resolved += `\n\n**Energy type:** ${el}.`;
  }

  // Spell storing rings: "treat it as a scroll to determine what spells are
  // stored in it." We roll spells until the level budget is filled, ignoring
  // rolls that would exceed it (per SRD).
  const storeMatch = ring.randomRoll?.match(/up to (\d+) spell levels/);
  if (storeMatch) {
    const budget = parseInt(storeMatch[1], 10);
    const stored: string[] = [];
    let used = 0;
    for (let guard = 0; guard < 40 && used < budget; guard++) {
      const lvl = 1 + Math.floor(Math.random() * Math.min(6, budget));
      if (used + lvl > budget) continue; // ignore rolls that overflow, per SRD
      const row = roller.rollOnTable(
        `Ring of spell storing: Table: Arcane Spell Scrolls, level ${lvl}`,
        arcaneScrollSpells[lvl] ?? [],
      );
      stored.push(`${row.name} (${lvl})`);
      used += lvl;
    }
    resolved += stored.length
      ? `\n\n**Spells stored:** ${stored.join(", ")} (${used} of ${budget} spell levels).`
      : `\n\n**Spells stored:** none (the ring need not be fully charged).`;
  }

  // Ring Special Qualities roll (SRD: 01 intelligent, 02-31 clue, 32-100 none).
  const sq = roller.rollOnTable("Ring special qualities", ringSpecialQualities);
  const sqNote = `\n\n**Special qualities roll:** ${sq.result}${sq.result === "Intelligent" ? " (intelligent rings cannot have charges — reroll charges if applicable)." : "."}`;

  return {
    id: `ring-${Math.random().toString(36).slice(2, 9)}`,
    category: "Ring",
    name: `${name}${name.includes("Friend shield") ? " (pair)" : ""}`,
    price: ring.price,
    charges,
    description:
      `*Ring (${tier}).*\n\n${ring.description}${resolved}${sqNote}` +
      `\n\nPrice: ${ring.price.toLocaleString()} gp.`,
    log: [],
  };
}

// Legacy implementation retained for reference; not called.
// -------- Rods (correct SRD Table: Rods) --------
function rollRod(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  // The SRD has only Medium and Major columns for rods. A rod that would be
  // "minor" is rolled on the Medium column (rods never appear at minor tier).
  const column = tier === "minor" ? srdRodTable.medium : srdRodTable[tier];
  const picked = roller.rollOnTable(`Table: Rods (${tier === "minor" ? "medium (no minor rods exist)" : tier} column)`, column);
  const rod = rodDetails[picked.name];
  if (!rod) {
    return {
      id: `rod-${Math.random().toString(36).slice(2, 9)}`,
      category: "Rod", name: picked.name, description: picked.name, log: [],
    };
  }

  let resolved = "";
  let charges: number | undefined;

  // Rod of absorption has its own SRD charge rule.
  if (rod.chargeRule?.includes("absorption potential")) {
    const d = roller.roll(1, 100, 0, "Absorption potential (d%/2)");
    const potential = Math.max(1, Math.floor(d / 2));
    const stored = roller.rollPercent("Absorption: levels already stored (71-100 = half)");
    const storedLevels = stored >= 71 ? Math.floor(potential / 2) : 0;
    charges = potential;
    resolved += `\n\n**Remaining absorption potential:** ${potential} of 50 spell levels.` +
      (storedLevels ? `\n\n**Levels already absorbed and still stored:** ${storedLevels}.` : `\n\n**Levels already absorbed and still stored:** none.`);
  }

  // Rod of flame extinguishing: "has 10 charges when found."
  else if (rod.charges === 10) {
    charges = 10;
    resolved += `\n\n**Charges:** 10 when found (spent charges renew every day).`;
  }

  // Rod of splendor garb value: 1d4+6 × 1,000 gp.
  if (rod.randomRoll?.includes("garb value")) {
    const v = roller.roll(1, 4, 6, "Splendor garb value (1d4+6 × 1,000 gp)");
    resolved += `\n\n**Garb created (this day):** worth ${v.toLocaleString()} gp.`;
  }

  // Rod special qualities roll (SRD: 01 intelligent, 02-31 clue, 32-100 none).
  const sq = roller.rollOnTable("Rod special qualities", rodSpecialQualities);
  const sqNote = `\n\n**Special qualities roll:** ${sq.result}.`;

  return {
    id: `rod-${Math.random().toString(36).slice(2, 9)}`,
    category: "Rod",
    name: picked.name,
    price: rod.price,
    charges,
    description:
      `*Rod (${tier === "minor" ? "medium" : tier}).*\n\n${rod.description}${resolved}${sqNote}` +
      `\n\nPrice: ${rod.price.toLocaleString()} gp.`,
    log: [],
  };
}

// -------- Staffs (correct SRD Table: Staffs — Medium/Major only) --------
function rollStaff(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  // The SRD staff table has no minor column. A minor-tier roll falls through to
  // the Medium column (consistent with Table: Random Magic Item Generation,
  // which gives staffs no minor range at all).
  const column = tier === "minor" ? staffTable.medium : staffTable[tier];
  const picked = roller.rollOnTable(`Table: Staffs (${tier === "minor" ? "medium (no minor staffs exist)" : tier} column)`, column);
  const st = staffDetails[picked.name];
  if (!st) {
    return { id: `staff-${Math.random().toString(36).slice(2, 9)}`, category: "Staff", name: picked.name, description: picked.name, log: [] };
  }

  // Charges: "A staff has 50 charges when created."
  const d = roller.roll(1, 100, 0, "Staff charges (d%/2)");
  const charges = Math.max(1, Math.floor(d / 2));

  // SRD Special Qualities (staffs have no "intelligent" result).
  const sq = roller.rollOnTable("Staff special qualities", staffSpecialQualities);

  return {
    id: `staff-${Math.random().toString(36).slice(2, 9)}`,
    category: "Staff",
    name: st.name,
    price: st.price,
    charges,
    description:
      `*Staff (${tier === "minor" ? "medium" : tier}).*\n\n${st.extra}\n\n**Spells stored:** ${st.spells}.` +
      (st.weapon ? `\n\n**Weapon:** This staff may be used as a weapon, functioning as a ${st.weapon}.` : "") +
      (st.extra?.includes("RETRIBUTIVE STRIKE") ? "" : "") +
      `\n\n*Activation:* staffs use the spell trigger method, so casting a spell from a staff is usually a standard action that does not provoke attacks of opportunity. To activate a staff, a character must hold it forth in at least one hand.` +
      `\n\n*Save DCs:* staffs use the wielder's ability score and relevant feats to set the DC for saves against their spells. Unlike other magic items, the wielder can use her own caster level when activating a staff power if it is higher than the staff's caster level. A staff can hold a spell of any level; the minimum caster level of a staff is 8th.` +
      `\n\n*Physical description:* 4 to 7 feet long and 2 to 3 inches thick, weighing about 5 pounds (AC 7, 10 hp, hardness 5, break DC 24).` +
      `\n\n**Charges remaining:** ${charges} of 50.` +
      `\n\n**Special qualities roll:** ${sq.result}.` +
      `\n\n*${st.aura}; CL ${st.cl}th; Craft Staff.* Price: ${st.price.toLocaleString()} gp.`,
    log: [],
  };
}

// -------- Scrolls (correct SRD meta-tables) --------
function rollScroll(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  // Table: Scroll Types
  const typeRoll = roller.rollOnTable("Table: Scroll Types", scrollTypeTable);
  const type = typeRoll.label as "Arcane" | "Divine";

  // Table: Number of Spells on Scroll
  const countDie = scrollSpellCount[tier];
  const count = roller.parseAndRoll(countDie, `Table: Number of Spells on Scroll (${tier})`);

  // Table: Scroll Spell Levels — the SAME level applies to every spell on the scroll.
  const lvlEntry = roller.rollOnTable(`Table: Scroll Spell Levels (${tier})`, scrollSpellLevels[tier]);
  const lvl = lvlEntry.level;
  const cl = lvlEntry.cl;

  // The SRD publishes a separate weighted spell table for every level of both
  // arcane and divine scrolls. Roll on the correct one.
  const spellTable = type === "Arcane" ? arcaneScrollSpells[lvl] : divineScrollSpells[lvl];
  const chosenSpells: { name: string; price: number }[] = [];
  for (let i = 0; i < count; i++) {
    const row = roller.rollOnTable(
      `Table: ${type} Spell Scrolls, level ${lvl}`,
      spellTable ?? [],
    );
    chosenSpells.push({ name: row.name, price: row.price });
  }

  // The SRD prints a market price per spell. A multi-spell scroll sums them.
  const totalPrice = Math.floor(chosenSpells.reduce((t, c) => t + c.price, 0));

  const descs = chosenSpells
    .map(c => `**${c.name}** (${type.toLowerCase()}) — ${spellLookup(c.name)}\n\n*Scroll market price:* ${c.price.toLocaleString()} gp`)
    .join("\n\n");

  return {
    id: `scroll-${Math.random().toString(36).slice(2, 9)}`,
    category: "Scroll",
    name: `${type} scroll: ${chosenSpells.map(c => c.name).join(" / ")}`,
    price: totalPrice,
    description:
      `*Scroll (${tier}).*\n\n` +
      `A scroll is a spell (or collection of spells) stored in written form. A spell on a scroll can be used only once; the writing vanishes when the spell is activated. Using a scroll is basically like casting a spell.` +
      `\n\n**Contents (${count} spell${count > 1 ? "s" : ""}, all level ${lvl}, caster level ${cl}):**\n\n${descs}` +
      `\n\n*Price:* the SRD's own per-scroll figures, summed: ${chosenSpells.map(c => c.price.toLocaleString()).join(" + ")} = ${totalPrice.toLocaleString()} gp.` +
      `\n\n*Price assumptions (SRD footnotes):* ${scrollPriceFootnotes.join(" ")}` +
      `\n\n*Physical description:* heavy fine vellum or high-quality paper, about 8 1/2 inches by 11 inches per spell, reinforced with leather strips (or rods for three or more spells). AC 9, 1 hp, hardness 0, break DC 8. Usually carried in a tube of ivory, jade, leather, metal, or wood.` +
      `\n\n*Activation:* (1) Decipher the writing — requires read magic or a Spellcraft check (DC 20 + spell level). Deciphering does not activate the scroll unless it is a specially prepared cursed scroll. (2) Activate the spell — the user must be able to see and read the writing; the spell must be of the correct type (arcane or divine) for the user's class; the user must have the spell on her class list; and the user must have the requisite ability score. No material components or focus are required. (3) If the user's caster level is at least equal to the scroll's caster level (${cl}), the spell activates automatically. Otherwise she must make a caster level check (DC = ${cl + 1}); on a failure she must make a DC 5 Wisdom check to avoid a mishap. A natural 1 always fails.` +
      `\n\n*Scroll mishaps (1d8):* 1. ${scrollMishaps[0]} 2. ${scrollMishaps[1]} 3. ${scrollMishaps[2]} 4. ${scrollMishaps[3]} 5. ${scrollMishaps[4]} 6. ${scrollMishaps[5]} 7. ${scrollMishaps[6]}` +
      `\n\n*Note:* spells whose level differs between classes appear at the level appropriate to a sorcerer or wizard (arcane) or a cleric (divine), as the default.`,
    log: [],
  };
}


// -------- Wondrous items (correct SRD Minor/Medium tables) --------
function rollWondrous(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  const tbl =
    tier === "minor" ? minorWondrousTableSRD :
    tier === "medium" ? mediumWondrousTableSRD :
    majorWondrousTableSRD;
  // WondrousRow is a single-value d% (one row per value 01-100), so roll d100
  // and index directly rather than using the range-based rollOnTable.
  const d = roller.rollPercent(`Table: ${tier[0].toUpperCase() + tier.slice(1)} Wondrous Items`);
  const picked = tbl.find(r => r.d === d) ?? tbl[0];
  return finishWondrous(picked.name, picked.price, tier, undefined, undefined, undefined, undefined, { name: picked.name, price: picked.price }, roller);
}

function finishWondrous(
  name: string, price: number, tier: string,
  legacyDesc?: string, legacyAura?: string, legacyCL?: number, legacySlot?: string,
  entry?: WonderEntry, roller?: DiceRoller,
): MagicItemResult {
  let resolved = "";
  if (entry?.sub && roller) {
    resolved = resolveWondrousSub(name, entry.sub, roller);
  }
  const sq = roller ? roller.rollOnTable("Wondrous item special qualities", wondrousSpecialQualities) : { result: "not rolled" };

  // Look up the verbatim SRD description. Item families (ioun stones, feather
  // tokens, figurines, pearl of power, etc.) share one description section.
  const descKey = wondrousDescKeys[name];
  const srdDesc = descKey ? wondrousDescriptionsSRD[descKey] : undefined;
  const baseDesc = legacyDesc ?? srdDesc ??
    `*(No description found in the SRD Wondrous Items page for "${name}".)*`;
  return {
    id: `wondrous-${Math.random().toString(36).slice(2, 9)}`,
    category: "Wondrous item",
    name,
    price,
    description:
      `*Wondrous item (${tier}).*\n\n${baseDesc}${resolved}` +
      `\n\n**Special qualities roll:** ${sq.result}.` +
      (legacyAura ? `\n\n*${legacyAura}; CL ${legacyCL}*.` : "") +
      (legacySlot ? `\n\n*Slot:* ${legacySlot}.` : "") +
      `\n\nPrice: ${price.toLocaleString()} gp.`,
    log: [],
  };
}

// SRD-mandated sub-rolls for specific wondrous items.
function resolveWondrousSub(_name: string, sub: string, roller: DiceRoller): string {
  if (sub.includes("1d4+4 pellets")) {
    const n = roller.parseAndRoll("1d4+4", "Dust of dryness pellets (1d4+4)");
    return `\n\n**Quantity:** ${n} pellets.`;
  }
  if (sub.includes("1d4+4 doses")) {
    const n = roller.parseAndRoll("1d4+4", "Salve of slipperiness doses (1d4+4)");
    return `\n\n**Quantity:** ${n} doses.`;
  }
  if (sub.includes("1d4+4 chimes")) {
    const n = roller.parseAndRoll("1d4+4", "Chime of opening chimes (1d4+4)");
    return `\n\n**Quantity:** ${n} chimes.`;
  }
  if (sub.includes("1d8-1 oz")) {
    const n = Math.max(1, roller.roll(1, 8, -1, "Sovereign glue ounces (1d8-1, min 1)"));
    const p = n * 2400;
    return `\n\n**Quantity:** ${n} ounce${n > 1 ? "s" : ""} (the flask's remaining capacity is salve of slipperiness). **Adjusted price:** ${p.toLocaleString()} gp at 2,400 gp per ounce.`;
  }
  if (sub === "2 doses") return `\n\n**Quantity:** 2 doses (per SRD).`;
  if (sub === "4 shrouds") return `\n\n**Quantity:** 4 shrouds.`;
  if (sub === "50 charges") {
    const d = roller.roll(1, 100, 0, "Gem of brightness charges (d%/2)");
    return `\n\n**Charges remaining:** ${Math.max(1, Math.floor(d / 2))} of 50.`;
  }
  if (sub === "roll element") {
    const t = ["Air (air elemental)", "Earth (earth elemental)", "Fire (fire elemental)", "Water (water elemental)"];
    const el = pick(t, roller, "Elemental gem element");
    return `\n\n**Element:** ${el}. Breaking the gem summons that elemental.`;
  }
  if (sub.includes("roll good or evil")) {
    const g = roller.rollPercent("Horn of goodness/evil alignment");
    return `\n\n**Alignment:** ${g <= 50 ? "good" : "evil"}.`;
  }
  if (sub.includes("roll alignment")) {
    const t = ["chaotic evil", "chaotic good", "lawful evil", "lawful good", "neutral evil", "neutral good"];
    const a = pick(t, roller, "Candle of invocation alignment");
    return `\n\n**Alignment:** ${a}.`;
  }
  if (sub.includes("roll patches")) {
    const n = roller.roll(1, 4, 0, "Robe of useful items: number of lower-value patches (1d4)");
    return `\n\n**Lower-value patches:** ${n}. The SRD's robe of useful items table (patch contents) has not been transcribed; roll patches during play.`;
  }
  return "";
}

// -------- Wands --------
function rollWand(tier: "minor"|"medium"|"major", roller: DiceRoller): MagicItemResult {
  const entry = roller.rollOnTable(`Wand spells (${tier})`, wandSpellTable[tier]);
  const price = wandPrice(entry.level, entry.cl);
  const d = roller.roll(1, 100, 0, "Wand charges (d%/2)");
  const charges = Math.max(1, Math.floor(d / 2));
  const spell = findSRDSpell(entry.spell);
  return {
    id: `wand-${Math.random().toString(36).slice(2, 9)}`,
    category: "Wand",
    name: `Wand of ${entry.spell} (${entry.level})`,
    price,
    charges,
    description: `This slim baton contains **${entry.spell}** (${entry.level}${ordinal(entry.level)}-level, CL ${entry.cl}).\n\n${spell ? spell.description : `Activation is spell-trigger, using ${entry.spell} as per the spell description.`}\n\nFully charged price: ${price} gp; currently has ${charges} charges.`,
    log: [],
  };
}

function ordinal(n: number) {
  if (n === 0) return "0";
  if (n === 1) return "st";
  if (n === 2) return "nd";
  if (n === 3) return "rd";
  return "th";
}

// ---------------------------------------------------------------------------
// INTELLIGENT ITEMS — full implementation of
// d20srd.org/srd/magicItems/intelligentItems.htm
//
// The user-specified probability is 0.5%, against the SRD's "in general, less
// than 1% of magic items have intelligence".
//
// ELIGIBILITY (SRD): "Only permanent magic items (as opposed to single-use items
// or those with charges) can be intelligent. (This means that potions, scrolls,
// and wands, among other items, are never intelligent.)" Cursed items are also
// excluded, since a cursed item is a distinct thing from an intelligent one.
// ---------------------------------------------------------------------------
// 0.5% of eligible items, as specified by the user. The SRD says "less than 1%".

function isEligibleForIntelligence(category: string, charges?: number, cursed?: boolean): boolean {
  if (cursed) return false;
  if (charges !== undefined) return false;              // charged items: never
  const never = [
    "Potion/oil",       // single-use
    "Scroll",           // single-use
    "Wand",             // charges
    "Staff",            // charges
  ];
  if (never.includes(category)) return false;
  // Only the permanent categories remain.
  const permanent = [
    "Magic weapon", "Magic armor", "Magic shield",
    "Ring", "Rod", "Wondrous item",
  ];
  return permanent.includes(category);
}

function rollIntelligentItem(
  roller: DiceRoller,
  enhBonus: number,
  abilityBonus: number,
): IntelligentItem | undefined {
  // The 0.5% chance requested by the user, against the SRD's "less than 1%".
  const check = roller.roll(1, 1000, 0, "Intelligent item check (0.5%)");
  if (check !== 1) return undefined;   // exactly 1 in 1000

  // Table: Intelligent Item Alignment
  const align = roller.rollOnTable("Table: Intelligent Item Alignment", intelligentAlignmentTable);

  // Table: Item Intelligence, Wisdom, Charisma, and Capabilities
  const cap = roller.rollOnTable(
    "Table: Item Intelligence, Wisdom, Charisma, and Capabilities",
    intCapabilitiesTable,
  );

  // The SRD gives "Two at N, one at 10" without saying which score gets the low
  // value. We roll for which of the three is the 10, which the SRD leaves open.
  const lowIs = pick(["Intelligence", "Wisdom", "Charisma"], roller, "Which mental score is the 10");
  const hi = cap.intBonus + 10;   // the "two at N" value
  const scores: Record<string, number> = { Intelligence: hi, Wisdom: hi, Charisma: hi };
  scores[lowIs] = 10;

  // Powers. "If the same power is rolled twice, roll again."
  const lesser: string[] = [];
  const greater: string[] = [];
  const taken = new Set<string>();
  for (let i = 0; i < cap.lesserPowers; i++) {
    for (let attempt = 0; attempt < 20; attempt++) {
      const p = roller.rollOnTable("Intelligent Item Lesser Powers", intLesserPowers);
      if (taken.has(p.name)) continue;
      // Knowledge (choose category) needs a category resolved.
      let nm = p.name;
      if (nm.includes("Knowledge (choose category)")) {
        const cats = ["arcana", "history", "religion", "nature", "dungeoneering",
                      "local", "the planes", "architecture and engineering", "nobility and royalty"];
        nm = nm.replace("(choose category)", `(${pick(cats, roller, "Knowledge category")})`);
      }
      taken.add(p.name); lesser.push(nm); break;
    }
  }
  for (let i = 0; i < cap.greaterPowers; i++) {
    for (let attempt = 0; attempt < 20; attempt++) {
      const p = roller.rollOnTable("Intelligent Item Greater Powers", intGreaterPowers);
      if (taken.has(p.name)) continue;
      taken.add(p.name); greater.push(p.name); break;
    }
  }

  // Special purpose. The SRD's footnote 6 on the capabilities table says the
  // item "can have a special purpose (and corresponding dedicated power) rather
  // than a greater power, if appropriate". Roll it for any item whose table row
  // permits it, replacing one greater power when there is one to replace.
  let specialPurpose: string | undefined;
  let dedicatedPower: string | undefined;
  if (cap.mayHaveSpecialPurpose) {
    const purpose = roller.rollOnTable("Intelligent Item Purpose", intPurposeTable);
    let label = purpose.label;
    if (purpose.needsChoice === "baneType") {
      const foe = roller.rollOnTable("Purpose creature type (see the bane special ability)", baneFoeTableSRD);
      label = label.replace("(see the bane special ability for choices)", `— ${foe.label}`);
    } else if (purpose.needsChoice === "race") {
      label += ` — ${pick(purposeRaces, roller, "Purpose race")}`;
    } else if (purpose.needsChoice === "deity") {
      label += ` — the servants of ${pick(purposeDeities, roller, "Purpose deity")}`;
    } else if (purpose.label === "Choose one") {
      // "Choose one": roll again on this table until a concrete purpose appears.
      for (let attempt = 0; attempt < 20; attempt++) {
        const p2 = roller.rollOnTable("Intelligent Item Purpose (choose one re-roll)", intPurposeTable);
        if (p2.label === "Choose one") continue;
        label = p2.label;
        if (p2.needsChoice === "baneType") {
          const foe = roller.rollOnTable("Purpose creature type (see the bane special ability)", baneFoeTableSRD);
          label = label.replace("(see the bane special ability for choices)", `— ${foe.label}`);
        } else if (p2.needsChoice === "race") label += ` — ${pick(purposeRaces, roller, "Purpose race")}`;
        else if (p2.needsChoice === "deity") label += ` — the servants of ${pick(purposeDeities, roller, "Purpose deity")}`;
        break;
      }
    }
    if (label !== "Choose one") {
      specialPurpose = label;
      dedicatedPower = roller.rollOnTable("Special Purpose Item Dedicated Powers", intDedicatedPowers).name;
    }
  }

  // Ego. Only computable once every other aspect has been generated.
  const egoBreakdown: { attribute: string; points: number }[] = [];
  const add = (attribute: string, points: number) => { if (points) egoBreakdown.push({ attribute, points }); };
  add("Each +1 of item's enhancement bonus", enhBonus);
  add("Each +1 of bonus for special abilities", abilityBonus);
  add("Each lesser power", lesser.length);
  add("Each greater power", greater.length * 2);
  if (specialPurpose) add("Special purpose (and dedicated power)", 4);
  if (cap.telepathy) add("Telepathic ability", 1);
  if (cap.readsLanguages) add("Read languages ability", 1);
  if (cap.readsMagic) add("Read magic ability", 1);
  const intMod = Math.floor((scores.Intelligence - 10) / 2);
  const wisMod = Math.floor((scores.Wisdom - 10) / 2);
  const chaMod = Math.floor((scores.Charisma - 10) / 2);
  add("Each +1 of Intelligence bonus", intMod);
  add("Each +1 of Wisdom bonus", wisMod);
  add("Each +1 of Charisma bonus", chaMod);
  const ego = egoBreakdown.reduce((t, e) => t + e.points, 0);

  // Languages: Common plus one per point of Intelligence bonus.
  const langCount = 1 + intMod;
  const langPool = ["Draconic", "Elven", "Dwarven", "Celestial", "Infernal", "Abyssal",
                    "Gnome", "Halfling", "Goblin", "Orc", "Sylvan", "Auran", "Ignan",
                    "Terran", "Aquan", "Undercommon", "Giant", "Gnoll"];
  const langs = ["Common"];
  for (let i = 0; i < Math.max(0, langCount - 1); i++) {
    const l = pick(langPool, roller, "Item language");
    if (!langs.includes(l)) langs.push(l);
  }

  return {
    alignment: align.label,
    alignmentNote: align.note,
    mental: cap.mental,
    intScore: scores.Intelligence, wisScore: scores.Wisdom, chaScore: scores.Charisma,
    communication: cap.communication,
    capabilities: cap.capabilities,
    senses: cap.senses,
    lesserPowers: lesser,
    greaterPowers: greater,
    specialPurpose,
    dedicatedPower,
    ego,
    egoBreakdown,
    priceModifier: cap.priceMod,
    languages: langs.join(", "),
  };
}

function renderIntelligence(ii: IntelligentItem): string {
  const L = INTELLIGENT_ITEM_RULES;
  return [
    `**INTELLIGENT ITEM**`,
    ``,
    `*Alignment:* ${ii.alignment}${ii.alignmentNote ? ` — ${ii.alignmentNote}` : ""}`,
    `*Mental ability scores:* ${ii.mental} — Int ${ii.intScore}, Wis ${ii.wisScore}, Cha ${ii.chaScore}`,
    `*Communication:* ${ii.communication}`,
    `*Capabilities:* ${ii.capabilities}`,
    `*Senses:* ${ii.senses}`,
    `*Languages:* ${ii.languages}`,
    ``,
    `*Lesser powers:* ${ii.lesserPowers.length ? ii.lesserPowers.join("; ") : "none"}`,
    `*Greater powers:* ${ii.greaterPowers.length ? ii.greaterPowers.join("; ") : "none"}`,
    ii.specialPurpose
      ? `\n*Special purpose:* ${ii.specialPurpose}\n*Dedicated power:* ${ii.dedicatedPower}\n\n${L.dedicatedPower}`
      : ``,
    ``,
    `*Ego:* ${ii.ego}`,
    ii.egoBreakdown.map(e => `  - ${e.attribute}: ${e.points}`).join("\n"),
    ``,
    `*Personality conflict:* when one occurs, the possessor makes a Will save (DC = the item's Ego, ${ii.ego}) to remain dominant. ` +
      (ii.ego >= 30 ? `With an Ego of 30 or higher, this item bestows THREE negative levels on a wielder of misaligned alignment and always considers itself superior to any character.`
        : ii.ego >= 20 ? `With an Ego of 20 to 29, this item bestows TWO negative levels on a wielder of misaligned alignment and always considers itself superior to any character.`
        : `This item bestows one negative level on a wielder whose alignment does not correspond to its own.`),
    ``,
    `*Base price modifier for intelligence:* +${ii.priceModifier.toLocaleString()} gp.`,
    ``,
    `_${L.nature}_`,
    `_${L.activation}_`,
    `_${L.powers}_`,
    `_${L.alignmentPenalty}_`,
    `_${L.languages}_`,
    `_${L.rivalry}_`,
  ].filter(x => x !== "").join("\n");
}



// Recover the enhancement bonus of a generated item for Ego calculation. The
// item's name begins "+N ..." for weapons, armour and shields.
function readEnhancementBonus(item: MagicItemResult): number {
  const m = /^\+(\d+)/.exec(item.name.replace(/^Intelligent /, ""));
  return m ? parseInt(m[1], 10) : 0;
}

// Recover the total special-ability bonus equivalent by summing the "+N bonus"
// price modifiers printed in the item's own description.
function readAbilityBonus(item: MagicItemResult): number {
  let total = 0;
  const re = /\((\S+) bonus, /g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(item.description ?? "")) !== null) {
    const v = parseInt(m[1].replace("+", ""), 10);
    if (!isNaN(v)) total += v;
  }
  return total;
}

// Also generate mundane items (not magic) for mundane results
export function generateMundaneItem(roller: DiceRoller): MagicItemResult {
  const cat: MundaneCategory = roller.rollOnTable("Mundane items", mundaneMasterTable);
  const startLog = roller.log.length;
  let label = cat.category;
  let desc = "";
  let price = 0;
  let qty = 1;
  let subtableName = "";
  let size: string | undefined;

  // Mundane armor: SRD says "roll d%: 01-10 Small, 11-100 Medium"
  if (cat.category === "Armor") {
    const sizeRoll = roller.rollPercent("Mundane armor size");
    size = sizeRoll <= 10 ? "Small" : "Medium";
  }
  // Mundane weapons (masterwork): 30/70 Small/Medium (same price per SRD)
  if (cat.category === "Weapons") {
    const sizeRoll = roller.rollPercent("Mundane weapon size");
    size = sizeRoll <= 30 ? "Small" : "Medium";
  }

  if (cat.subtable) {
    const sub = roller.rollOnTable(cat.category, cat.subtable);
    label = sub.name;
    price = sub.value ?? 0;
    desc = sub.description ?? "";
    if (sub.quantity) {
      qty = roller.parseAndRoll(sub.quantity, `Quantity of ${sub.name}`);
    }
    if (sub.subtable) {
      subtableName = sub.subtable;
      // Roll on named subtable
      let subList: MundaneSubentry[] | Weapon[] | undefined;
      if (sub.subtable === "darkwood") {
        subList = darkwoodSubtable;
      } else if (sub.subtable === "masterworkShield") {
        subList = masterworkShieldSubtable;
      } else if (sub.subtable === "commonMeleeMasterwork") {
        const w = randomWeapon("commonMelee", roller);
        label = `Masterwork ${w.name}${size ? ` (${size})` : ""}`;
        const dmg = size === "Small" ? adjustDamageForSize(w.damage, "Small") : w.damage;
        const wt = Math.round((size === "Small" ? 0.5 : 1) * w.weight * 10) / 10;
        price = w.cost + MASTERWORK_COST_BONUS;
        desc = `A masterwork ${size ? size + " " : ""}${w.name} (${dmg} damage, crit ${w.critical}, weight ${wt} lb). Masterwork quality gives a +1 enhancement bonus on attack rolls (but not damage).\n\nPrice: ${price} gp.`;
      } else if (sub.subtable === "uncommonMasterwork") {
        const w = randomWeapon("uncommon", roller);
        label = `Masterwork ${w.name}${size ? ` (${size})` : ""}`;
        const dmg = size === "Small" ? adjustDamageForSize(w.damage, "Small") : w.damage;
        const wt = Math.round((size === "Small" ? 0.5 : 1) * w.weight * 10) / 10;
        price = w.cost + MASTERWORK_COST_BONUS;
        desc = `A masterwork ${size ? size + " " : ""}${w.name} (${dmg} damage, crit ${w.critical}, weight ${wt} lb). +1 masterwork bonus on attacks.\n\nPrice: ${price} gp.`;
      } else if (sub.subtable === "commonRangedMasterwork") {
        const w = randomWeapon("commonRanged", roller);
        label = `Masterwork ${w.name}${size ? ` (${size})` : ""}`;
        const dmg = size === "Small" ? adjustDamageForSize(w.damage, "Small") : w.damage;
        const wt = Math.round((size === "Small" ? 0.5 : 1) * w.weight * 10) / 10;
        price = w.cost + MASTERWORK_COST_BONUS;
        desc = `A masterwork ${size ? size + " " : ""}${w.name} (${dmg} damage, crit ${w.critical}, range ${w.range ?? "—"}, weight ${wt} lb). +1 masterwork bonus on attacks.\n\nPrice: ${price} gp.`;
      }

      if (subList) {
        const sub2 = roller.rollOnTable(`Subtable: ${sub.name}`, subList as MundaneSubentry[]);
        label = sub2.name + (size ? ` (${size})` : "");
        price = sub2.value ?? 0;
        desc = sub2.description ?? "";
        if (sub2.quantity) qty = roller.parseAndRoll(sub2.quantity, `Qty for ${sub2.name}`);
        if (size === "Small") {
          desc += `\n\nSize: Small (weight halved, same price as Medium per SRD).`;
        }
      }
    }
    // Add size label for regular armor entries
    if (cat.category === "Armor" && !sub.subtable) {
      label += size ? ` (${size})` : "";
      if (size === "Small") {
        desc += `\n\nSize: Small (weight halved, same price as Medium).`;
      }
    }
  }

  const totalPrice = price * qty;
  const itemLog = roller.log.slice(startLog);
  return {
    id: `mundane-${Math.random().toString(36).slice(2, 9)}`,
    category: "Mundane/alchemical/gear",
    name: qty > 1 ? `${qty}× ${label}` : label,
    price: totalPrice,
    size,
    description: desc || label,
    subtable: subtableName,
    log: itemLog,
  };
}
