// Dice rolling engine with full logging for the d20 treasure generator.

export interface RollLogEntry {
  readonly table: string;
  readonly die: string; // e.g. "d%", "1d8", "2d6+1"
  readonly rolls: number[]; // individual die results
  readonly modifier: number;
  readonly total: number;
  readonly resultLabel?: string; // human-readable entry selected
}

export type DiceLog = RollLogEntry[];

// Simple mulberry32 seeded RNG so we can (optionally) reproduce results.
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class DiceRoller {
  private rng: () => number;
  public log: DiceLog = [];
  public seed?: number;

  constructor(seed?: number) {
    this.seed = seed;
    this.rng = seed !== undefined ? mulberry32(seed) : Math.random;
  }

  reset(seed?: number): void {
    if (seed !== undefined) this.seed = seed;
    this.rng = this.seed !== undefined ? mulberry32(this.seed) : Math.random;
    this.log = [];
  }

  // Roll a single die of given sides. Inclusive 1..sides.
  private rollOne(sides: number): number {
    return Math.floor(this.rng() * sides) + 1;
  }

  // General dice roller. `d%` is 1d100.
  roll(
    count: number,
    sides: number,
    modifier: number = 0,
    table?: string,
    resultLabel?: string,
    dieLabelOverride?: string,
  ): number {
    const rolls: number[] = [];
    for (let i = 0; i < count; i++) rolls.push(this.rollOne(sides));
    const total = rolls.reduce((a, b) => a + b, 0) + modifier;
    if (table) {
      const dieStr =
        dieLabelOverride ??
        (sides === 100 && count === 1 ? "d%" : `${count}d${sides}${modifier ? (modifier > 0 ? `+${modifier}` : modifier) : ""}`);
      this.log.push({ table, die: dieStr, rolls, modifier, total, resultLabel });
    }
    return total;
  }

  // d% specifically (1-100)
  rollPercent(table?: string, resultLabel?: string): number {
    return this.roll(1, 100, 0, table, resultLabel, "d%");
  }

  // Parse a dice string like "2d6", "1d8×100", "3d4+1", "d%", "1d4 × 10 pp"
  parseAndRoll(dieStr: string, table?: string, resultLabel?: string): number {
    const s = dieStr.toLowerCase().replace(/\s+/g, "");
    if (s === "d%" || s === "d100") return this.rollPercent(table, resultLabel);
    // handle multiplier e.g. 1d6x1000
    const multMatch = s.match(/^(\d*)d(\d+)([+-]\d+)?(?:x|×|\*)(\d+)$/);
    if (multMatch) {
      const count = multMatch[1] ? parseInt(multMatch[1]) : 1;
      const sides = parseInt(multMatch[2]);
      const mod = multMatch[3] ? parseInt(multMatch[3]) : 0;
      const mult = parseInt(multMatch[4]);
      const base = this.roll(count, sides, mod, table, resultLabel, dieStr);
      return base * mult;
    }
    const m = s.match(/^(\d*)d(\d+)([+-]\d+)?$/);
    if (m) {
      const count = m[1] ? parseInt(m[1]) : 1;
      const sides = parseInt(m[2]);
      const mod = m[3] ? parseInt(m[3]) : 0;
      return this.roll(count, sides, mod, table, resultLabel, dieStr);
    }
    // plain number
    const n = parseInt(s);
    if (!isNaN(n)) {
      if (table) this.log.push({ table, die: `(${n})`, rolls: [n], modifier: 0, total: n, resultLabel });
      return n;
    }
    throw new Error(`Unknown die string: ${dieStr}`);
  }

  // Roll on a table expressed as ranges: [{min, max, entry, subtable?}]
  // Returns the entry and appends the % roll to the log.
  rollOnTable<T extends TableEntry>(
    tableName: string,
    table: T[],
    dieValue?: number,
  ): T {
    const roll = dieValue ?? this.rollPercent(tableName);
    const entry = table.find(
      (e) => roll >= e.min && roll <= e.max,
    );
    if (!entry) {
      throw new Error(
        `Roll ${roll} did not match any entry on table ${tableName}`,
      );
    }
    // Replace the log entry label with the matched entry label
    const last = this.log[this.log.length - 1];
    if (last && last.table === tableName) {
      (last as any).resultLabel = entry.label ?? entry.result ?? "(see subtable)";
    }
    return entry;
  }
}

export interface TableEntry {
  min: number;
  max: number;
  label?: string; // human readable label
  result?: string; // simple string result
  subtable?: any; // named subtable or subtable array
  subtableKey?: string; // dynamic key
  value?: string | number; // for coin/gem die string or fixed value
  quantity?: string; // die string for quantity e.g. "1d4"
  amount?: string; // die string for multiplier
  note?: string;
  category?: string;
  [key: string]: any;
}
