import { useMemo, useState } from "react";
import { generateTreasure, TreasureResult, MagicItemResult, CoinResult, GoodResult } from "./engine/treasureGenerator";
import { RollLogEntry } from "./engine/dice";
import { cn } from "./utils/cn";

function formatGold(gp: number): string {
  if (gp >= 1000) return `${(gp / 1000).toFixed(2)}k gp`;
  return `${Math.floor(gp).toLocaleString()} gp`;
}

function CoinDisplay({ coin }: { coin: CoinResult }) {
  const colorClass =
    coin.denomination === "pp" ? "coin-pp" :
    coin.denomination === "gp" ? "coin-gp" :
    coin.denomination === "sp" ? "coin-sp" : "coin-cp";
  const sym = { cp: "¢", sp: "s", gp: "g", pp: "p" }[coin.denomination];
  return (
    <div className={cn("item-card rarity-coins")}>
      <div className="flex items-start justify-between">
        <div>
          <div className="font-title text-lg">{coin.amount.toLocaleString()} <span className={colorClass}>{sym}</span></div>
          <div className="font-script text-sm opacity-75">{coin.label}</div>
        </div>
        <div className="coin-gp text-right font-title text-lg">{formatGold(coin.valueGP)}</div>
      </div>
    </div>
  );
}

function GoodDisplay({ good }: { good: GoodResult }) {
  const icon = good.type === "gem" ? "💎" : "🏺";
  return (
    <div className={cn("item-card rarity-goods")}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1">
          <div className="font-title text-base flex items-center gap-2">
            <span className="text-xl">{icon}</span>
            <span>{good.name}</span>
          </div>
          <div className="font-script text-sm opacity-80 mt-1">{good.description}</div>
        </div>
        <div className="coin-gp font-title whitespace-nowrap text-lg">{good.valueGP} gp</div>
      </div>
    </div>
  );
}

function DiceLog({ entries, title }: { entries: RollLogEntry[]; title?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-2 text-sm">
      <button
        onClick={() => setOpen(v => !v)}
        className="flex items-center gap-1 text-[#5a2e1c] hover:text-[#8b1a1a] font-script text-[0.95em]"
      >
        <span className={cn("chev", open && "open")}>▸</span>
        <span className="underline decoration-dotted underline-offset-2">
          {title ?? `Dice log (${entries.length} rolls)`}
        </span>
      </button>
      {open && (
        <div className="mt-2 pl-4 border-l-2 border-[rgba(184,134,11,0.4)] custom-scroll max-h-64 overflow-y-auto">
          {entries.length === 0 && <div className="font-script opacity-60 italic">No rolls recorded.</div>}
          {entries.map((e, i) => (
            <div key={i} className="log-entry mb-1">
              <span className="dice-chip">{e.die}</span>
              <span className="font-semibold">→ {e.total}</span>
              {" on "}
              <em>{e.table}</em>
              {e.resultLabel && <span className="opacity-80"> — {e.resultLabel}</span>}
              {e.rolls.length > 1 && <span className="opacity-60 text-xs"> (rolls: [{e.rolls.join(", ")}]{e.modifier ? e.modifier > 0 ? ` +${e.modifier}` : ` ${e.modifier}` : ""})</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MagicItemDisplay({ item }: { item: MagicItemResult }) {
  const rarityClass =
    /cursed/i.test(item.name) ? "item-cursed" :
    item.category === "Mundane/alchemical/gear" ? "rarity-mundane" :
    /minor|Scroll of .*level [0-2]|Wand of .*\([0-2]\)|Potion/i.test(item.name + item.category) ? "rarity-minor" :
    /medium|Scroll.*level [3-6]|Wand.*\([34]\)|Staff/i.test(item.name + item.category) ? "rarity-medium" :
    "rarity-major";
  const icon = {
    "Magic weapon": "⚔️",
    "Magic armor": "🛡",
    "Magic shield": "🛡",
    "Potion/oil": "⚗️",
    "Ring": "💍",
    "Rod": "🪄",
    "Staff": "🔮",
    "Wand": "🪄",
    "Scroll": "📜",
    "Wondrous item": "✨",
    "Mundane/alchemical/gear": "🎒",
  }[item.category] ?? "✦";

  return (
    <div className={cn("item-card", rarityClass)}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1">
          <div className="font-title text-base flex items-center gap-2 leading-tight">
            <span className="text-xl">{icon}</span>
            <span>{item.name}</span>
          </div>
          <div className="font-script text-xs uppercase tracking-wider opacity-60 mt-0.5">{item.category}{item.size ? ` — size ${item.size}` : ""}{item.charges !== undefined ? ` — ${item.charges} charges` : ""}</div>
        </div>
        {item.price !== undefined && item.price > 0 && (
          <div className="coin-gp font-title text-lg whitespace-nowrap">{item.price.toLocaleString()} gp</div>
        )}
      </div>
      {item.description && (
        <div className="font-script text-[0.95em] mt-2 whitespace-pre-wrap leading-snug opacity-90">
          {item.description}
        </div>
      )}
      {item.log && item.log.length > 0 && <DiceLog entries={item.log} title={`How it was rolled (${item.log.length} rolls)`} />}
    </div>
  );
}

function CollapsibleSection({
  title,
  count,
  totalGP,
  icon,
  children,
  defaultOpen = true,
}: {
  title: string;
  count?: number;
  totalGP?: number;
  icon: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="mb-4">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center gap-2 py-2 px-3 leather-border font-title text-sm tracking-wider text-[#f4e9d0] hover:brightness-110 transition rounded"
      >
        <span className={cn("chev text-[#d4af37]", open && "open")}>▸</span>
        <span className="text-lg leading-none">{icon}</span>
        <span className="flex-1 text-left">{title}</span>
        {count !== undefined && (
          <span className="text-xs opacity-80 font-script normal-case tracking-normal">
            {count} item{count !== 1 ? "s" : ""}
          </span>
        )}
        {totalGP !== undefined && totalGP > 0 && (
          <span className="text-sm font-title text-[#f8e287]">{formatGold(totalGP)}</span>
        )}
      </button>
      {open && <div className="mt-2 pl-2">{children}</div>}
    </div>
  );
}

const LEVELS = Array.from({ length: 20 }, (_, i) => i + 1);
const EPIC_LEVELS = [21,22,23,24,25,26,27,28,29,30];

export default function App() {
  const [level, setLevel] = useState<number>(5);
  const [seedInput, setSeedInput] = useState<string>("");
  const [result, setResult] = useState<TreasureResult | null>(null);
  const [generating, setGenerating] = useState(false);
  const [showConfig, setShowConfig] = useState(true);
  const [showMasterLog, setShowMasterLog] = useState(false);

  const generate = () => {
    setGenerating(true);
    setTimeout(() => {
      const useSeed = seedInput.trim()
        ? parseInt(seedInput.trim()) || Math.floor(Math.random() * 1e9)
        : undefined;
      const res = generateTreasure(level, useSeed);
      setResult(res);
      setGenerating(false);
    }, 50);
  };

  const coinTotal = useMemo(
    () => (result?.coins ?? []).reduce((s, c) => s + c.valueGP, 0),
    [result]
  );
  const goodsTotal = useMemo(
    () => (result?.goods ?? []).reduce((s, g) => s + g.valueGP, 0),
    [result]
  );
  const itemsTotal = useMemo(
    () => (result?.items ?? []).reduce((s, i) => s + (i.price ?? 0), 0),
    [result]
  );

  return (
    <div className="min-h-screen py-6 px-3 sm:px-6">
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-6">
        <div className="leather-border p-4 sm:p-6 rounded-lg text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 pointer-events-none"
               style={{ backgroundImage: "radial-gradient(circle at 20% 20%, #d4af37 0%, transparent 40%), radial-gradient(circle at 80% 80%, #d4af37 0%, transparent 40%)" }} />
          <h1 className="font-title text-2xl sm:text-4xl arcane-glow text-[#f8e287] relative">
            ✦ Arcanum of Treasure ✦
          </h1>
          <p className="font-script italic text-[#e6d5ac] mt-2 text-sm sm:text-base relative">
            A d20 System Reference Document Treasure Generator
          </p>
          <div className="divider-ornament relative">✦ ❦ ✦</div>
        </div>
      </div>

      {/* Main Notebook */}
      <div className="max-w-5xl mx-auto">
        <div className="parchment p-4 sm:p-8 md:p-10">
          {/* Config section */}
          <div className="mb-6">
            <button
              onClick={() => setShowConfig(v => !v)}
              className="w-full flex items-center justify-between font-title text-xl text-[#2a1810] border-b-2 border-[rgba(184,134,11,0.5)] pb-2 mb-3"
            >
              <span><span className="arcane-glow">⚙</span> Configuration</span>
              <span className="text-sm font-script italic text-[#5a2e1c]">
                {showConfig ? "— hide —" : "— show —"}
              </span>
            </button>
            {showConfig && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-script">
                <div>
                  <label className="block font-title text-sm mb-1 text-[#2a1810]">Encounter / Challenge Rating</label>
                  <div className="flex flex-wrap gap-1">
                    {LEVELS.map(l => (
                      <button
                        key={l}
                        onClick={() => setLevel(l)}
                        className={cn(
                          "w-9 h-9 text-sm font-title border rounded transition",
                          level === l ? "gold-gild border-[#8b6914] shadow" : "bg-[rgba(139,90,43,0.08)] border-[rgba(139,90,43,0.3)] hover:bg-[rgba(139,90,43,0.18)]"
                        )}
                      >{l}</button>
                    ))}
                    {EPIC_LEVELS.map(l => (
                      <button
                        key={l}
                        onClick={() => setLevel(l)}
                        className={cn(
                          "w-9 h-9 text-sm font-title border rounded transition",
                          level === l ? "bg-[#8b1a1a] text-[#f8e287] border-[#8b1a1a] shadow" : "bg-[rgba(139,26,26,0.08)] border-[rgba(139,26,26,0.3)] hover:bg-[rgba(139,26,26,0.18)]"
                        )}
                        title="Epic level"
                      >{l > 20 ? `${l}` : l}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block font-title text-sm mb-1 text-[#2a1810]">
                    Optional Seed (for reproducible rolls)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={seedInput}
                      onChange={e => setSeedInput(e.target.value)}
                      placeholder="Leave blank for random"
                      className="flex-1 px-3 py-2 bg-[rgba(139,90,43,0.08)] border border-[rgba(139,90,43,0.4)] rounded font-script text-[#2a1810] placeholder-[rgba(42,24,16,0.4)]"
                    />
                    <button
                      onClick={() => {
                        const s = Math.floor(Math.random() * 1e9);
                        setSeedInput(String(s));
                      }}
                      className="btn-ghost px-3 py-1 rounded text-sm"
                    >
                      🎲
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Persistent generate button */}
          <div className="my-6 text-center sticky bottom-2 z-10">
            <button
              onClick={generate}
              disabled={generating}
              className={cn(
                "btn-primary px-6 sm:px-10 py-3 rounded-lg text-base sm:text-lg font-title shadow-lg",
                generating && "opacity-60 cursor-wait"
              )}
            >
              {generating ? "✨ Consulting the Dice... ✨" : "✨ Generate Treasure Hoard ✨"}
            </button>
            <p className="font-script italic text-xs text-[#5a2e1c] mt-2">
              Click to roll on the SRD treasure tables for CR {level}
              {level > 20 && " (epic)"}.
            </p>
          </div>

          {/* Results */}
          {!result ? (
            <div className="text-center py-12 font-script italic text-[#5a2e1c] opacity-70">
              <div className="text-6xl mb-4 sparkle inline-block">✦</div>
              <p className="text-lg">No treasure yet, adventurer...</p>
              <p className="text-sm mt-1">Set a challenge rating and press the button to roll on the tables.</p>
            </div>
          ) : (
            <div className="mt-4">
              <div className="text-center mb-4 font-script">
                <div className="font-title text-xl arcane-glow text-[#5a2e1c]">
                  Hoard for Encounter Level {result.level}
                </div>
                <div className="text-sm mt-1 opacity-80">
                  Total value: <span className="coin-gp font-title text-lg">{formatGold(result.totalValueGP)}</span>
                </div>
              </div>

              <div className="divider-ornament">❦</div>

              {/* Coins */}
              <CollapsibleSection
                title="Coins"
                icon="🪙"
                count={result.coins?.length ?? 0}
                totalGP={coinTotal}
                defaultOpen={result.coins && result.coins.length > 0}
              >
                {(!result.coins || result.coins.length === 0) ? (
                  <p className="font-script italic opacity-60 pl-2">No coins in this hoard.</p>
                ) : (
                  result.coins.map((c, i) => <CoinDisplay key={i} coin={c} />)
                )}
              </CollapsibleSection>

              {/* Goods */}
              <CollapsibleSection
                title="Gems & Art Objects"
                icon="💎"
                count={result.goods?.length ?? 0}
                totalGP={goodsTotal}
                defaultOpen={result.goods && result.goods.length > 0}
              >
                {(!result.goods || result.goods.length === 0) ? (
                  <p className="font-script italic opacity-60 pl-2">No gems or art objects.</p>
                ) : (
                  result.goods.map((g, i) => <GoodDisplay key={i} good={g} />)
                )}
              </CollapsibleSection>

              {/* Magic / Mundane items */}
              <CollapsibleSection
                title="Magic & Mundane Items"
                icon="✨"
                count={result.items?.length ?? 0}
                totalGP={itemsTotal}
                defaultOpen={result.items && result.items.length > 0}
              >
                {(!result.items || result.items.length === 0) ? (
                  <p className="font-script italic opacity-60 pl-2">No items.</p>
                ) : (
                  result.items.map((it, i) => <MagicItemDisplay key={i} item={it} />)
                )}
              </CollapsibleSection>

              <div className="divider-ornament">✦</div>

              {/* Master dice log */}
              <div className="mt-4">
                <button
                  onClick={() => setShowMasterLog(v => !v)}
                  className="btn-ghost w-full font-title text-sm py-2 rounded"
                >
                  <span className={cn("chev mr-1", showMasterLog && "open")}>▸</span>
                  Master Dice Log ({result.log.length} total rolls)
                </button>
                {showMasterLog && (
                  <div className="mt-2 custom-scroll max-h-96 overflow-y-auto p-3 bg-[rgba(139,90,43,0.05)] rounded border border-[rgba(184,134,11,0.3)]">
                    {result.log.map((e, i) => (
                      <div key={i} className="log-entry mb-1">
                        <span className="dice-chip">{e.die}</span>
                        <span className="font-semibold">{e.total}</span>
                        {" on "}
                        <em>{e.table}</em>
                        {e.resultLabel && <span className="opacity-80"> — {e.resultLabel}</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer note */}
        <div className="text-center mt-4 font-script italic text-xs text-[#e6d5ac] opacity-75">
          <p>Based on the d20 System Reference Document. Use per the terms of the Open Game License.</p>
          <p className="mt-1">Dice rolls, tables, and descriptions are drawn from the SRD. See EngineTrouble.txt for known ambiguities.</p>
        </div>
      </div>
    </div>
  );
}
